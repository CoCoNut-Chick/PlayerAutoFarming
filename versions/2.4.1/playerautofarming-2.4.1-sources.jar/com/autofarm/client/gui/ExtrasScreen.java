package com.autofarm.client.gui;

import com.autofarm.client.config.AutoFarmConfig;
import com.autofarm.client.scan.CropRegistry;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3965;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;

/**
 * 「附加功能」次级面板 —— 仿 Mod Menu 的<b>顶部大类 tab</b>布局。
 *
 * <h2>为什么改成分类 tab</h2>
 * 附加功能越加越多（现在十三个分区、几十个选项），一张无限长的滚动页要找半天。
 * 改成顶部一排大类，点一下只看到那一类的几个开关，和 Mod Menu 的「分类 → 内容」一致。
 *
 * <p>五个大类：
 * <ol>
 *   <li><b>战斗</b> —— 自动打怪（高风险，警示配色 + 风险确认屏）；</li>
 *   <li><b>隐蔽</b> —— 玩家接近停机、防踢模式、行为真实感；</li>
 *   <li><b>范围</b> —— 圈定工作区域、环境与作息；</li>
 *   <li><b>生存</b> —— 危险撤退、受击反制、环境自救、掉线重连、工具维护、容错统计、掉落物；</li>
 *   <li><b>资源</b> —— 瓜类与自定义作物、资源自给、交互便利。</li>
 * </ol>
 *
 * <h2>和主面板的关系</h2>
 * 老规矩：它编辑的是主面板递进来的<b>同一个草稿</b>。点「完成」回主面板，
 * 最终由主面板的「保存并关闭」落盘；点「取消」或 Esc 只把这里的十几项
 * 恢复成进来之前的样子，不碰草稿里的其他设置。
 */
public class ExtrasScreen extends ScrollPanelScreen {

    // ---------------- tab 定义 ----------------
    private static final int TAB_COMBAT = 0;
    private static final int TAB_STEALTH = 1;
    private static final int TAB_AREA = 2;
    private static final int TAB_SURVIVAL = 3;
    private static final int TAB_RESOURCE = 4;
    private static final int TAB_COUNT = 5;

    // ---------------- 内容区布局（相对内容区顶部） ----------------
    /** 分区内第一行相对分区顶部的 y（让开标题那一行） */
    private static final int ROW_FIRST = 18;
    /** 相邻两行的间距 */
    private static final int ROW_GAP = 20;
    /** 两个分区之间的留白 */
    private static final int SECTION_GAP = 6;
    /** 参数行的左缩进，视觉上表示「从属于上一行」 */
    private static final int INDENT = 8;
    /** 攻击间隔行的左侧标签宽度 / 输入框宽度 */
    private static final int INTERVAL_LABEL_W = 60;
    private static final int INTERVAL_FIELD_W = 56;
    /** 「转向时间」输入框右边的「确认」按钮：宽度与左侧留白 */
    private static final int TURN_OK_W = 46;
    private static final int TURN_OK_GAP = 4;

    // ---- 战斗（tab 0）----
    private static final int COMBAT_ROWS = 6;
    private static final int COMBAT_WARN_H = 26;
    private static final int SEC_COMBAT_Y = TAB_BAR_H;
    private static final int SEC_COMBAT_H = ROW_FIRST + COMBAT_ROWS * ROW_GAP + COMBAT_WARN_H;

    // ---- 隐蔽（tab 1）----
    private static final int STEALTH_ROWS = 6;
    private static final int SEC_STEALTH_Y = TAB_BAR_H;
    private static final int SEC_STEALTH_H = ROW_FIRST + STEALTH_ROWS * ROW_GAP + 4;
    private static final int ANTIKICK_ROWS = 2;
    private static final int SEC_ANTIKICK_Y = SEC_STEALTH_Y + SEC_STEALTH_H + SECTION_GAP;
    private static final int SEC_ANTIKICK_H = ROW_FIRST + ANTIKICK_ROWS * ROW_GAP + 4;
    private static final int BEHAVIOR_ROWS = 8;
    private static final int SEC_BEHAVIOR_Y = SEC_ANTIKICK_Y + SEC_ANTIKICK_H + SECTION_GAP;
    /** 底部留一点给「转向时间过小」的警告行 */
    private static final int SEC_BEHAVIOR_H = ROW_FIRST + BEHAVIOR_ROWS * ROW_GAP + 16;

    // ---- 范围（tab 2）----
    private static final int WORKAREA_ROWS = 5;
    private static final int SEC_WORKAREA_Y = TAB_BAR_H;
    private static final int SEC_WORKAREA_H = ROW_FIRST + WORKAREA_ROWS * ROW_GAP + 4;
    private static final int ENV_ROWS = 5;
    private static final int SEC_ENV_Y = SEC_WORKAREA_Y + SEC_WORKAREA_H + SECTION_GAP;
    private static final int SEC_ENV_H = ROW_FIRST + ENV_ROWS * ROW_GAP + 4;

    // ---- 生存（tab 3）----
    private static final int SURVIVAL_ROWS = 9;
    private static final int SEC_SURVIVAL_Y = TAB_BAR_H;
    private static final int SEC_SURVIVAL_H = ROW_FIRST + SURVIVAL_ROWS * ROW_GAP + 4;
    private static final int TOOL_ROWS = 2;
    private static final int SEC_TOOL_Y = SEC_SURVIVAL_Y + SEC_SURVIVAL_H + SECTION_GAP;
    private static final int SEC_TOOL_H = ROW_FIRST + TOOL_ROWS * ROW_GAP + 4;
    private static final int MISC_ROWS = 3;
    private static final int SEC_MISC_Y = SEC_TOOL_Y + SEC_TOOL_H + SECTION_GAP;
    private static final int SEC_MISC_H = ROW_FIRST + MISC_ROWS * ROW_GAP + 4;
    // 纯拾取模式 / 优先拾取掉落物 / 拾取范围 / 拾取对象 / 拾取判定延迟 /
    // 掉落物优先（插队）/ 优先判定时长
    private static final int PICKUP_ROWS = 7;
    private static final int SEC_PICKUP_Y = SEC_MISC_Y + SEC_MISC_H + SECTION_GAP;
    private static final int SEC_PICKUP_H = ROW_FIRST + PICKUP_ROWS * ROW_GAP + 4;

    // ---- 资源（tab 4）----
    private static final int GOURD_ROWS = 4;
    private static final int SEC_GOURD_Y = TAB_BAR_H;
    private static final int SEC_GOURD_H = ROW_FIRST + GOURD_ROWS * ROW_GAP + 4;
    private static final int SUPPLY_ROWS = 5;
    private static final int SEC_SUPPLY_Y = SEC_GOURD_Y + SEC_GOURD_H + SECTION_GAP;
    private static final int SEC_SUPPLY_H = ROW_FIRST + SUPPLY_ROWS * ROW_GAP + 4;
    private static final int NOTIFY_ROWS = 2;
    private static final int SEC_NOTIFY_Y = SEC_SUPPLY_Y + SEC_SUPPLY_H + SECTION_GAP;
    private static final int SEC_NOTIFY_H = ROW_FIRST + NOTIFY_ROWS * ROW_GAP + 4;

    // ---------------- 循环档位（都含出厂默认值，见 AutoFarmConfig） ----------------
    private static final int[] RADIUS_CHOICES = {8, 12, 16, 24, 32};
    private static final int[] REST_INTERVAL_CHOICES = {5, 10, 15, 20, 30};
    private static final int[] REST_DURATION_CHOICES = {10, 20, 30, 60};
    private static final int[] DURABILITY_CHOICES = {5, 10, 15, 20, 30};
    private static final int[] COOLDOWN_CHOICES = {5, 10, 15, 30, 60};
    private static final int[] PICKUP_DELAY_CHOICES = {1, 2, 3, 5};
    /** 「掉落物优先」的插队阈值（秒）：躺够这么久还没进包，就中断手上的活专门跑一趟 */
    private static final int[] PICKUP_PRIORITY_CHOICES = {3, 5, 8, 15, 30};
    /** 「拾取范围」档位（格）。掉落物单开一档半径，最大到 48 格 */
    private static final int[] PICKUP_RADIUS_CHOICES = {4, 8, 12, 16, 24, 32, 48};
    private static final double[] ATTACK_RANGE_CHOICES = {2.5, 2.9, 3.5, 4.5, 6.0};
    private static final int[] VIOLENCE_CHOICES = {0, 1, 2};
    private static final int[] ANTIKICK_LEVEL_CHOICES = {0, 1, 2, 3};
    private static final int[] REACTION_CHOICES = {4, 10, 20, 30};
    private static final int[] HOUR_CHOICES = buildHours();
    private static final int[] AREA_MODE_CHOICES = {0, 1};
    private static final int[] WORK_AREA_RADIUS_CHOICES = {8, 12, 16, 24, 32, 48};
    private static final int[] FATIGUE_WORK_CHOICES = {15, 30, 60, 120, 240};
    private static final int[] FATIGUE_REST_CHOICES = {0, 5, 10, 15, 30, 60};
    private static final int[] RETREAT_HEALTH_CHOICES = {3, 4, 5, 6, 8, 10};
    private static final int[] RETREAT_DISTANCE_CHOICES = {8, 12, 16, 24, 32};
    private static final int[] HIT_REACTION_CHOICES = {1, 2, 3, 5};
    private static final int[] RECONNECT_DELAY_CHOICES = {5, 10, 20, 30, 60};
    private static final int[] RECONNECT_ATTEMPT_CHOICES = {0, 3, 5, 10, 20};
    private static final int[] BONE_MEAL_LIMIT_CHOICES = {1, 2, 4, 6, 10};
    private static final int[] BONE_MEAL_THRESHOLD_CHOICES = {8, 16, 32, 64};

    private static int[] buildHours() {
        int[] hours = new int[24];
        for (int i = 0; i < hours.length; i++) {
            hours[i] = i;
        }
        return hours;
    }

    private final AutoFarmConfig draft;
    /** 进来时的快照，「取消」时用它还原附加功能这几项 */
    private final AutoFarmConfig old;

    private int currentTab = TAB_COMBAT;
    private class_4185[] tabButtons = new class_4185[TAB_COUNT];

    private class_4185 combatButton;
    private class_342 attackIntervalField;
    private class_4185 attackRangeButton;
    private class_4185 attackTargetButton;
    private class_4185 violentButton;
    private class_4185 violenceLevelButton;
    private class_4185 pausePlayerButton;
    private class_4185 radiusButton;
    private class_4185 humanizeButton;
    private class_4185 randomRestButton;
    private class_4185 restIntervalButton;
    private class_4185 restDurationButton;
    private class_4185 replaceToolButton;
    private class_4185 durabilityButton;
    private class_4185 failureCooldownButton;
    private class_4185 cooldownButton;
    private class_4185 verboseHudButton;
    private class_4185 pickupOnlyButton;
    private class_4185 pickupDropsButton;
    private class_4185 pickupRadiusButton;
    private class_4185 pickupAllButton;
    private class_4185 pickupDelayButton;
    private class_4185 pickupPriorityButton;
    private class_4185 pickupPriorityTimeButton;
    private class_4185 antiKickButton;
    private class_4185 antiKickLevelButton;
    private class_4185 reactionDelayButton;
    private class_4185 reactionTimeButton;
    private class_4185 idleLookButton;
    private class_342 turnTimeField;
    /** 「转向时间」右边那颗确认按钮 */
    private class_4185 turnTimeOkButton;
    /**
     * 「转向时间」输入框里有没有一个<b>还没确认的危险值</b>（小于安全阈值、含 0）。
     *
     * <p>危险值不会直接写进草稿 —— 必须先按 Enter 或点「确认」，过一次风险提示屏才生效。
     * 这样「填 0 然后保存」就不可能悄悄发生：要么在离页前被拦下来确认，要么根本没写进去。
     */
    private boolean turnTimePending;
    private class_4185 instantActionsButton;
    private class_4185 scheduleButton;
    private class_4185 scheduleStartButton;
    private class_4185 scheduleEndButton;
    private class_4185 workAreaButton;
    private class_4185 workAreaModeButton;
    private class_4185 workAreaRadiusButton;
    private class_4185 workAreaCenterButton;
    private class_4185 workAreaCornerAButton;
    private class_4185 workAreaCornerBButton;
    private class_4185 daylightButton;
    private class_4185 weatherButton;
    private class_4185 fatigueButton;
    private class_4185 fatigueWorkButton;
    private class_4185 fatigueRestButton;
    private class_4185 retreatButton;
    private class_4185 retreatHealthButton;
    private class_4185 retreatDistanceButton;
    private class_4185 hitReactionButton;
    private class_4185 hitReactionTimeButton;
    private class_4185 selfRescueButton;
    private class_4185 reconnectButton;
    private class_4185 reconnectDelayButton;
    private class_4185 reconnectAttemptsButton;
    private class_4185 melonHarvestButton;
    private class_4185 addCustomBlockButton;
    private class_4185 customBlocksButton;
    private class_4185 boneMealBoostButton;
    private class_4185 boneMealLimitButton;
    private class_4185 autoSuppliesButton;
    private class_4185 boneMealThresholdButton;
    private class_4185 autoFetchToolButton;
    private class_4185 notifySoundsButton;
    private class_4185 notifyToastsButton;

    public ExtrasScreen(class_437 parent, AutoFarmConfig sharedDraft) {
        super(parent, class_2561.method_43471("autofarm.extras.title"));
        this.draft = sharedDraft;
        this.old = sharedDraft.copy();
    }

    @Override
    protected int contentHeight() {
        return switch (currentTab) {
            case TAB_COMBAT -> SEC_COMBAT_Y + SEC_COMBAT_H + 8;
            case TAB_STEALTH -> SEC_BEHAVIOR_Y + SEC_BEHAVIOR_H + 8;
            case TAB_AREA -> SEC_ENV_Y + SEC_ENV_H + 8;
            case TAB_SURVIVAL -> SEC_PICKUP_Y + SEC_PICKUP_H + 8;
            case TAB_RESOURCE -> SEC_NOTIFY_Y + SEC_NOTIFY_H + 8;
            default -> TAB_BAR_H + 8;
        };
    }

    // ================= 建控件 =================

    @Override
    protected void buildContent() {
        buildTabBar();
        switch (currentTab) {
            case TAB_COMBAT -> buildCombatTab();
            case TAB_STEALTH -> buildStealthTab();
            case TAB_AREA -> buildAreaTab();
            case TAB_SURVIVAL -> buildSurvivalTab();
            case TAB_RESOURCE -> buildResourceTab();
            default -> {
            }
        }

        int btnW = (contentWidth - 8) / 3;
        addFooter(
                class_4185.method_46430(class_2561.method_43471("autofarm.extras.reset"), b -> resetAllOff())
                        .method_46434(contentX, 0, btnW, ROW_H).method_46431(),
                class_4185.method_46430(class_2561.method_43471("autofarm.button.cancel"), b -> onCancel())
                        .method_46434(contentX + btnW + 4, 0, btnW, ROW_H).method_46431(),
                class_4185.method_46430(class_2561.method_43471("autofarm.highlight.done"), b -> onDone())
                        .method_46434(contentX + 2 * (btnW + 4), 0, btnW, ROW_H).method_46431()
        );
    }

    /** 顶部那条大类 tab 栏 */
    private void buildTabBar() {
        int tabW = (contentWidth - (TAB_COUNT - 1) * 2) / TAB_COUNT;
        for (int i = 0; i < TAB_COUNT; i++) {
            final int tab = i;
            class_4185 btn = class_4185.method_46430(tabLabel(tab), b -> switchTab(tab))
                    .method_46434(contentX + i * (tabW + 2), 0, tabW, ROW_H).method_46431();
            addScrolling(btn);
            tabButtons[i] = btn;
        }
    }

    private void switchTab(int tab) {
        if (tab == currentTab) {
            return;
        }
        // 切 tab = 换一页：重建内容（滚动回到顶部是合理的），草稿原样保留
        if (this.field_22787 != null) {
            ExtrasScreen next = new ExtrasScreen(this.parent, draft);
            next.currentTab = tab;
            this.field_22787.method_1507(next);
        }
    }

    private static class_2561 tabLabel(int tab) {
        return class_2561.method_43471("autofarm.extras.tab." + switch (tab) {
            case TAB_STEALTH -> "stealth";
            case TAB_AREA -> "area";
            case TAB_SURVIVAL -> "survival";
            case TAB_RESOURCE -> "resource";
            default -> "combat";
        });
    }

    // ---- 各 tab 的控件创建 ----

    private void buildCombatTab() {
        int fullW = contentWidth;
        int subX = contentX + INDENT;
        int subW = contentWidth - INDENT;

        this.combatButton = dangerToggle("autofarm.option.auto_attack",
                draft.autoAttack, value -> draft.autoAttack = value,
                "autofarm.auto_attack.tip");
        layout(combatButton, contentX, 0, fullW);

        this.attackIntervalField = intervalField(contentX + INTERVAL_LABEL_W);
        addScrolling(attackIntervalField);

        this.attackRangeButton = class_4185.method_46430(attackRangeLabel(), b -> onRangeClicked())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        attackRangeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_range.tip")));
        addScrolling(attackRangeButton);

        this.attackTargetButton = class_4185.method_46430(attackTargetLabel(), b -> {
            draft.attackHostileOnly = !draft.attackHostileOnly;
            b.method_25355(attackTargetLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        attackTargetButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_target.tip")));
        addScrolling(attackTargetButton);

        this.violentButton = dangerToggle("autofarm.option.auto_attack_violent",
                draft.autoAttackViolent, value -> draft.autoAttackViolent = value,
                "autofarm.auto_attack_violent.tip");
        layout(violentButton, subX, 0, subW);

        this.violenceLevelButton = class_4185.method_46430(violenceLabel(), b -> onViolenceClicked())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        violenceLevelButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_violence.tip")));
        addScrolling(violenceLevelButton);
    }

    private void buildStealthTab() {
        int fullW = contentWidth;
        int subX = contentX + INDENT;
        int subW = contentWidth - INDENT;

        this.pausePlayerButton = toggle("autofarm.option.pause_player",
                draft.pauseWhenPlayerNear, value -> draft.pauseWhenPlayerNear = value,
                "autofarm.pause_player.tip");
        layout(pausePlayerButton, contentX, 0, fullW);

        this.radiusButton = class_4185.method_46430(radiusLabel(), b -> {
            draft.playerNearRadius = nextChoice(RADIUS_CHOICES, draft.playerNearRadius);
            b.method_25355(radiusLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        radiusButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.value_radius.tip")));
        addScrolling(radiusButton);

        this.humanizeButton = toggle("autofarm.option.humanize",
                draft.humanizeTiming, value -> draft.humanizeTiming = value,
                "autofarm.humanize.tip");
        layout(humanizeButton, contentX, 0, fullW);

        this.randomRestButton = toggle("autofarm.option.random_rest",
                draft.randomRest, value -> draft.randomRest = value,
                "autofarm.random_rest.tip");
        layout(randomRestButton, contentX, 0, fullW);

        this.restIntervalButton = class_4185.method_46430(restIntervalLabel(), b -> {
            draft.restIntervalMinutes = nextChoice(REST_INTERVAL_CHOICES, draft.restIntervalMinutes);
            b.method_25355(restIntervalLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        restIntervalButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.rest_interval.tip")));
        addScrolling(restIntervalButton);

        this.restDurationButton = class_4185.method_46430(restDurationLabel(), b -> {
            draft.restDurationSeconds = nextChoice(REST_DURATION_CHOICES, draft.restDurationSeconds);
            b.method_25355(restDurationLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        restDurationButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.rest_duration.tip")));
        addScrolling(restDurationButton);

        this.antiKickButton = toggle("autofarm.option.antikick",
                draft.antiKickMode, value -> draft.antiKickMode = value,
                "autofarm.antikick.tip");
        layout(antiKickButton, contentX, 0, fullW);

        this.antiKickLevelButton = class_4185.method_46430(antiKickLevelLabel(), b -> {
            draft.antiKickLevel = nextChoice(ANTIKICK_LEVEL_CHOICES, draft.antiKickLevel);
            b.method_25355(antiKickLevelLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        antiKickLevelButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.antikick_level.tip")));
        addScrolling(antiKickLevelButton);

        this.reactionDelayButton = toggle("autofarm.option.reaction_delay",
                draft.reactionDelay, value -> draft.reactionDelay = value,
                "autofarm.reaction_delay.tip");
        layout(reactionDelayButton, contentX, 0, fullW);

        this.reactionTimeButton = class_4185.method_46430(reactionTimeLabel(), b -> {
            draft.reactionDelayTicks = nextChoice(REACTION_CHOICES, draft.reactionDelayTicks);
            b.method_25355(reactionTimeLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        reactionTimeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.reaction_time.tip")));
        addScrolling(reactionTimeButton);

        this.idleLookButton = toggle("autofarm.option.idle_look",
                draft.idleLookAround, value -> draft.idleLookAround = value,
                "autofarm.idle_look.tip");
        layout(idleLookButton, contentX, 0, fullW);

        // 「丝滑转向时间」：填空，只收数字（毫秒）。0 = 不缓动。越界由 clamp() 兜底。
        this.turnTimeField = new class_342(this.field_22793,
                subX + INTERVAL_LABEL_W, 0, INTERVAL_FIELD_W, ROW_H, class_2561.method_43473());
        turnTimeField.method_1880(4);
        turnTimeField.method_1890(s -> s.isEmpty() || s.matches("\\d{1,4}"));
        turnTimeField.method_1852(Integer.toString(draft.turnDurationMs));
        turnTimeField.method_1863(text -> onTurnTimeEdited(text));
        turnTimeField.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.turn_time.tip")));
        addScrolling(turnTimeField);

        // 输入框右边的「确认」：把刚填的值定下来。危险的（含 0）会弹一次风险提示屏。
        // 和直接按 Enter 是同一件事，看玩家顺手用哪个。
        this.turnTimeOkButton = class_4185.method_46430(class_2561.method_43471("autofarm.turn_time.ok"),
                        b -> commitTurnTime())
                .method_46434(subX + INTERVAL_LABEL_W + INTERVAL_FIELD_W + TURN_OK_GAP, 0, TURN_OK_W, ROW_H)
                .method_46431();
        turnTimeOkButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.turn_time.ok.tip")));
        addScrolling(turnTimeOkButton);

        this.instantActionsButton = toggle("autofarm.option.instant_actions",
                draft.instantActions, value -> draft.instantActions = value,
                "autofarm.instant_actions.tip");
        layout(instantActionsButton, contentX, 0, fullW);

        this.scheduleButton = toggle("autofarm.option.schedule",
                draft.scheduleEnabled, value -> draft.scheduleEnabled = value,
                "autofarm.schedule.tip");
        layout(scheduleButton, contentX, 0, fullW);

        this.scheduleStartButton = class_4185.method_46430(scheduleStartLabel(), b -> {
            draft.scheduleStartHour = nextChoice(HOUR_CHOICES, draft.scheduleStartHour);
            b.method_25355(scheduleStartLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        scheduleStartButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.schedule_start.tip")));
        addScrolling(scheduleStartButton);

        this.scheduleEndButton = class_4185.method_46430(scheduleEndLabel(), b -> {
            draft.scheduleEndHour = nextChoice(HOUR_CHOICES, draft.scheduleEndHour);
            b.method_25355(scheduleEndLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        scheduleEndButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.schedule_end.tip")));
        addScrolling(scheduleEndButton);
    }

    private void buildAreaTab() {
        int fullW = contentWidth;
        int subX = contentX + INDENT;
        int subW = contentWidth - INDENT;

        this.workAreaButton = toggle("autofarm.option.work_area",
                draft.workAreaEnabled, value -> draft.workAreaEnabled = value,
                "autofarm.work_area.tip");
        layout(workAreaButton, contentX, 0, fullW);

        this.workAreaModeButton = class_4185.method_46430(workAreaModeLabel(), b -> {
            draft.workAreaMode = nextChoice(AREA_MODE_CHOICES, draft.workAreaMode);
            b.method_25355(workAreaModeLabel());
            // 半径/角点行的显隐和标签跟着变，但<b>不重建整页</b>（否则滚动位置会丢回顶部）
            workAreaRadiusButton.method_25355(workAreaRadiusLabel());
            workAreaCenterButton.method_25355(workAreaCenterLabel());
            workAreaCornerAButton.method_25355(workAreaCornerALabel());
            workAreaCornerBButton.method_25355(workAreaCornerBLabel());
            relayout();
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaModeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area_mode.tip")));
        addScrolling(workAreaModeButton);

        this.workAreaRadiusButton = class_4185.method_46430(workAreaRadiusLabel(), b -> {
            draft.workAreaRadius = nextChoice(WORK_AREA_RADIUS_CHOICES, draft.workAreaRadius);
            b.method_25355(workAreaRadiusLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaRadiusButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area_radius.tip")));
        addScrolling(workAreaRadiusButton);

        this.workAreaCenterButton = class_4185.method_46430(workAreaCenterLabel(), b -> {
            recordCurrentPos(false);
            b.method_25355(workAreaCenterLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaCenterButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area.record.tip")));
        addScrolling(workAreaCenterButton);

        this.workAreaCornerAButton = class_4185.method_46430(workAreaCornerALabel(), b -> {
            recordCurrentPos(false);
            b.method_25355(workAreaCornerALabel());
            if (workAreaCornerBButton != null) {
                workAreaCornerBButton.method_25355(workAreaCornerBLabel());
            }
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaCornerAButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area.corner_a.tip")));
        addScrolling(workAreaCornerAButton);

        this.workAreaCornerBButton = class_4185.method_46430(workAreaCornerBLabel(), b -> {
            recordCurrentPos(true);
            b.method_25355(workAreaCornerBLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaCornerBButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area.corner_b.tip")));
        addScrolling(workAreaCornerBButton);

        this.daylightButton = toggle("autofarm.option.daylight",
                draft.workDaylightOnly, value -> draft.workDaylightOnly = value,
                "autofarm.daylight.tip");
        layout(daylightButton, contentX, 0, fullW);

        this.weatherButton = toggle("autofarm.option.clear_weather",
                draft.workClearWeatherOnly, value -> draft.workClearWeatherOnly = value,
                "autofarm.clear_weather.tip");
        layout(weatherButton, contentX, 0, fullW);

        this.fatigueButton = toggle("autofarm.option.fatigue",
                draft.fatigueStop, value -> draft.fatigueStop = value,
                "autofarm.fatigue.tip");
        layout(fatigueButton, contentX, 0, fullW);

        this.fatigueWorkButton = class_4185.method_46430(fatigueWorkLabel(), b -> {
            draft.fatigueWorkMinutes = nextChoice(FATIGUE_WORK_CHOICES, draft.fatigueWorkMinutes);
            b.method_25355(fatigueWorkLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        fatigueWorkButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.fatigue_work.tip")));
        addScrolling(fatigueWorkButton);

        this.fatigueRestButton = class_4185.method_46430(fatigueRestLabel(), b -> {
            draft.fatigueRestMinutes = nextChoice(FATIGUE_REST_CHOICES, draft.fatigueRestMinutes);
            b.method_25355(fatigueRestLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        fatigueRestButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.fatigue_rest.tip")));
        addScrolling(fatigueRestButton);
    }

    private void buildSurvivalTab() {
        int fullW = contentWidth;
        int subX = contentX + INDENT;
        int subW = contentWidth - INDENT;

        this.retreatButton = toggle("autofarm.option.retreat",
                draft.retreatEnabled, value -> draft.retreatEnabled = value,
                "autofarm.retreat.tip");
        layout(retreatButton, contentX, 0, fullW);

        this.retreatHealthButton = class_4185.method_46430(retreatHealthLabel(), b -> {
            draft.retreatHealthHearts = nextChoice(RETREAT_HEALTH_CHOICES, draft.retreatHealthHearts);
            b.method_25355(retreatHealthLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        retreatHealthButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.retreat_health.tip")));
        addScrolling(retreatHealthButton);

        this.retreatDistanceButton = class_4185.method_46430(retreatDistanceLabel(), b -> {
            draft.retreatDistance = nextChoice(RETREAT_DISTANCE_CHOICES, draft.retreatDistance);
            b.method_25355(retreatDistanceLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        retreatDistanceButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.retreat_distance.tip")));
        addScrolling(retreatDistanceButton);

        this.hitReactionButton = toggle("autofarm.option.hit_reaction",
                draft.hitReactionEnabled, value -> draft.hitReactionEnabled = value,
                "autofarm.hit_reaction.tip");
        layout(hitReactionButton, contentX, 0, fullW);

        this.hitReactionTimeButton = class_4185.method_46430(hitReactionTimeLabel(), b -> {
            draft.hitReactionSeconds = nextChoice(HIT_REACTION_CHOICES, draft.hitReactionSeconds);
            b.method_25355(hitReactionTimeLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        hitReactionTimeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.hit_reaction_time.tip")));
        addScrolling(hitReactionTimeButton);

        this.selfRescueButton = toggle("autofarm.option.self_rescue",
                draft.selfRescueEnabled, value -> draft.selfRescueEnabled = value,
                "autofarm.self_rescue.tip");
        layout(selfRescueButton, contentX, 0, fullW);

        this.reconnectButton = toggle("autofarm.option.auto_reconnect",
                draft.autoReconnectEnabled, value -> draft.autoReconnectEnabled = value,
                "autofarm.auto_reconnect.tip");
        layout(reconnectButton, contentX, 0, fullW);

        this.reconnectDelayButton = class_4185.method_46430(reconnectDelayLabel(), b -> {
            draft.reconnectDelaySeconds = nextChoice(RECONNECT_DELAY_CHOICES, draft.reconnectDelaySeconds);
            b.method_25355(reconnectDelayLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        reconnectDelayButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.reconnect_delay.tip")));
        addScrolling(reconnectDelayButton);

        this.reconnectAttemptsButton = class_4185.method_46430(reconnectAttemptsLabel(), b -> {
            draft.reconnectMaxAttempts = nextChoice(RECONNECT_ATTEMPT_CHOICES, draft.reconnectMaxAttempts);
            b.method_25355(reconnectAttemptsLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        reconnectAttemptsButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.reconnect_attempts.tip")));
        addScrolling(reconnectAttemptsButton);

        this.replaceToolButton = toggle("autofarm.option.replace_tool",
                draft.autoReplaceTool, value -> draft.autoReplaceTool = value,
                "autofarm.replace_tool.tip");
        layout(replaceToolButton, contentX, 0, fullW);

        this.durabilityButton = class_4185.method_46430(durabilityLabel(), b -> {
            draft.toolDurabilityPercent = nextChoice(DURABILITY_CHOICES, draft.toolDurabilityPercent);
            b.method_25355(durabilityLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        durabilityButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.durability.tip")));
        addScrolling(durabilityButton);

        this.failureCooldownButton = toggle("autofarm.option.failure_cooldown",
                draft.failureCooldown, value -> draft.failureCooldown = value,
                "autofarm.failure_cooldown.tip");
        layout(failureCooldownButton, contentX, 0, fullW);

        this.cooldownButton = class_4185.method_46430(cooldownLabel(), b -> {
            draft.failureCooldownSeconds = nextChoice(COOLDOWN_CHOICES, draft.failureCooldownSeconds);
            b.method_25355(cooldownLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        cooldownButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.cooldown.tip")));
        addScrolling(cooldownButton);

        this.verboseHudButton = toggle("autofarm.option.verbose_hud",
                draft.verboseHud, value -> draft.verboseHud = value,
                "autofarm.verbose_hud.tip");
        layout(verboseHudButton, contentX, 0, fullW);

        // 「纯拾取模式」：独立于「自动收割」总开关的一道闸 —— 只开它，模组也会干活，
        // 但只捡掉落物（不收菜、不补种、不催熟、不挖瓜、不打怪）。
        this.pickupOnlyButton = class_4185.method_46430(
                toggleLabel("autofarm.option.pickup_only", draft.pickupOnlyMode), b -> {
                    draft.pickupOnlyMode = !draft.pickupOnlyMode;
                    if (draft.pickupOnlyMode) {
                        // 顺手把「拾取对象」默认成全捡：纯拾取还只认农作物产物的话，
                        // 没种过的地上一件都捡不到，这个模式等于白开。
                        draft.pickupAllItems = true;
                        if (pickupAllButton != null) {
                            pickupAllButton.method_25355(pickupAllLabel());
                        }
                    }
                    b.method_25355(toggleLabel("autofarm.option.pickup_only", draft.pickupOnlyMode));
                }).method_46434(contentX, 0, contentWidth, ROW_H).method_46431();
        pickupOnlyButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.pickup_only.tip")));
        addScrolling(pickupOnlyButton);

        this.pickupDropsButton = toggle("autofarm.option.pickup_drops",
                draft.pickupDroppedItems, value -> draft.pickupDroppedItems = value,
                "autofarm.pickup_drops.tip");
        layout(pickupDropsButton, contentX, 0, fullW);

        // 拾取范围：掉落物专用的扫描半径。调大就是「范围拾取」——
        // 注意它是「看得更远、走过去捡」，不是隔空吸取（物品入包由服务端决定，见配置里的说明）。
        this.pickupRadiusButton = class_4185.method_46430(pickupRadiusLabel(), b -> {
            draft.pickupRadius = nextChoice(PICKUP_RADIUS_CHOICES, draft.pickupRadius);
            b.method_25355(pickupRadiusLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        pickupRadiusButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.pickup_radius.tip")));
        addScrolling(pickupRadiusButton);

        // 拾取对象：只捡农作物产物 / 范围内什么都捡
        this.pickupAllButton = class_4185.method_46430(pickupAllLabel(), b -> {
            draft.pickupAllItems = !draft.pickupAllItems;
            b.method_25355(pickupAllLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        pickupAllButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.pickup_all.tip")));
        addScrolling(pickupAllButton);

        this.pickupDelayButton = class_4185.method_46430(pickupDelayLabel(), b -> {
            draft.pickupDelaySeconds = nextChoice(PICKUP_DELAY_CHOICES, draft.pickupDelaySeconds);
            b.method_25355(pickupDelayLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        pickupDelayButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.pickup_delay.tip")));
        addScrolling(pickupDelayButton);

        // 掉落物优先：躺够时长的掉落物直接「插队」—— 中断手上的路线，专门为它跑一趟
        this.pickupPriorityButton = toggle("autofarm.option.pickup_priority",
                draft.pickupPriorityEnabled, value -> draft.pickupPriorityEnabled = value,
                "autofarm.pickup_priority.tip");
        layout(pickupPriorityButton, contentX, 0, fullW);

        this.pickupPriorityTimeButton = class_4185.method_46430(pickupPriorityTimeLabel(), b -> {
            draft.pickupPrioritySeconds = nextChoice(PICKUP_PRIORITY_CHOICES, draft.pickupPrioritySeconds);
            b.method_25355(pickupPriorityTimeLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        pickupPriorityTimeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.pickup_priority_time.tip")));
        addScrolling(pickupPriorityTimeButton);
    }

    private void buildResourceTab() {
        int fullW = contentWidth;
        int subX = contentX + INDENT;
        int subW = contentWidth - INDENT;

        this.melonHarvestButton = toggle("autofarm.option.melon_harvest",
                draft.melonHarvest, value -> draft.melonHarvest = value,
                "autofarm.melon_harvest.tip");
        layout(melonHarvestButton, contentX, 0, fullW);

        this.addCustomBlockButton = class_4185.method_46430(
                        class_2561.method_43471("autofarm.option.add_custom_block"),
                        b -> addLookedBlock())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        addCustomBlockButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.add_custom_block.tip")));
        addScrolling(addCustomBlockButton);

        this.customBlocksButton = class_4185.method_46430(customBlocksLabel(), b -> clearCustomBlocks())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        customBlocksButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.custom_blocks.tip")));
        addScrolling(customBlocksButton);

        this.boneMealBoostButton = toggle("autofarm.option.bone_meal",
                draft.boneMealBoost, value -> draft.boneMealBoost = value,
                "autofarm.bone_meal.tip");
        layout(boneMealBoostButton, contentX, 0, fullW);

        this.boneMealLimitButton = class_4185.method_46430(boneMealLimitLabel(), b -> {
            draft.boneMealLimit = nextChoice(BONE_MEAL_LIMIT_CHOICES, draft.boneMealLimit);
            b.method_25355(boneMealLimitLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        boneMealLimitButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.bone_meal_limit.tip")));
        addScrolling(boneMealLimitButton);

        this.autoSuppliesButton = toggle("autofarm.option.auto_supplies",
                draft.autoFetchSupplies, value -> draft.autoFetchSupplies = value,
                "autofarm.auto_supplies.tip");
        layout(autoSuppliesButton, contentX, 0, fullW);

        this.boneMealThresholdButton = class_4185.method_46430(boneMealThresholdLabel(), b -> {
            draft.boneMealThreshold = nextChoice(BONE_MEAL_THRESHOLD_CHOICES, draft.boneMealThreshold);
            b.method_25355(boneMealThresholdLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        boneMealThresholdButton.method_47400(class_7919.method_47407(
                class_2561.method_43471("autofarm.bone_meal_threshold.tip")));
        addScrolling(boneMealThresholdButton);

        this.autoFetchToolButton = toggle("autofarm.option.auto_fetch_tool",
                draft.autoFetchTool, value -> draft.autoFetchTool = value,
                "autofarm.auto_fetch_tool.tip");
        layout(autoFetchToolButton, contentX, 0, fullW);

        this.notifySoundsButton = toggle("autofarm.option.notify_sounds",
                draft.notifySounds, value -> draft.notifySounds = value,
                "autofarm.notify_sounds.tip");
        layout(notifySoundsButton, contentX, 0, fullW);

        this.notifyToastsButton = toggle("autofarm.option.notify_toasts",
                draft.notifyToasts, value -> draft.notifyToasts = value,
                "autofarm.notify_toasts.tip");
        layout(notifyToastsButton, contentX, 0, fullW);
    }

    /** 一个开关按钮的样板：点一下翻转，标签跟着变 */
    private class_4185 toggle(String optionKey, boolean value,
                                java.util.function.Consumer<Boolean> setter, String tipKey) {
        class_4185 button = class_4185.method_46430(toggleLabel(optionKey, value), b -> {
            boolean next = !currentToggle(optionKey);
            setter.accept(next);
            b.method_25355(toggleLabel(optionKey, next));
        }).method_46434(contentX, 0, contentWidth, ROW_H).method_46431();
        button.method_47400(class_7919.method_47407(class_2561.method_43471(tipKey)));
        return button;
    }

    /** 高风险开关：文字标红，打开要先过风险确认屏 */
    private class_4185 dangerToggle(String optionKey, boolean value,
                                      java.util.function.Consumer<Boolean> setter, String tipKey) {
        class_4185 button = class_4185.method_46430(dangerLabel(optionKey, value), b -> {
            if (currentToggle(optionKey)) {
                setter.accept(false);
                if ("autofarm.option.auto_attack".equals(optionKey)) {
                    draft.autoAttackViolent = false;
                    draft.attackViolence = AutoFarmConfig.VIOLENCE_LIGHT;
                }
                b.method_25355(dangerLabel(optionKey, false));
                return;
            }
            if ("autofarm.option.auto_attack".equals(optionKey) && !draft.enabled) {
                toast("autofarm.combat.warn.master_off");
                return;
            }
            openDangerConfirm(setter);
        }).method_46434(contentX, 0, contentWidth, ROW_H).method_46431();
        button.method_47400(class_7919.method_47407(class_2561.method_43471(tipKey)));
        return button;
    }

    /** 攻击间隔的填空：只收数字，改动实时写进草稿，越界由 clamp() 兜底 */
    private class_342 intervalField(int x) {
        class_342 field = new class_342(this.field_22793, x, 0,
                INTERVAL_FIELD_W, ROW_H, class_2561.method_43473());
        field.method_1880(4);
        field.method_1890(s -> s.isEmpty() || s.matches("\\d{1,4}"));
        field.method_1852(Integer.toString(draft.attackIntervalMs));
        field.method_1863(text -> {
            if (text == null || text.isEmpty()) {
                return;
            }
            try {
                draft.attackIntervalMs = Integer.parseInt(text);
            } catch (NumberFormatException ignored) {
                // 理论上进不来（上面已经限定了只收数字），保险起见吞掉
            }
        });
        field.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_interval.tip")));
        return field;
    }

    private void onRangeClicked() {
        double next = nextChoice(ATTACK_RANGE_CHOICES, draft.attackRange);
        if (next > AutoFarmConfig.ATTACK_RANGE_VANILLA) {
            confirmThen("autofarm.danger.range.subtitle", () -> {
                draft.attackRange = next;
                rebuild();
            }, "autofarm.danger.range.body1", "autofarm.danger.range.body2");
            return;
        }
        draft.attackRange = next;
        attackRangeButton.method_25355(attackRangeLabel());
    }

    private void onViolenceClicked() {
        int next = nextChoice(VIOLENCE_CHOICES, draft.attackViolence);
        if (next > draft.attackViolence) {
            confirmThen("autofarm.danger.violence.subtitle", () -> {
                draft.attackViolence = next;
                rebuild();
            }, "autofarm.danger.violence.body1", "autofarm.danger.violence.body2");
            return;
        }
        draft.attackViolence = next;
        violenceLevelButton.method_25355(violenceLabel());
    }

    private void confirmThen(String subtitleKey, Runnable apply, String... bodyKeys) {
        if (this.field_22787 == null) {
            return;
        }
        this.field_22787.method_1507(new DangerConfirmScreen(this, apply,
                "autofarm.danger.title", subtitleKey, bodyKeys));
    }

    /** 重建本页（草稿原样带过去）。用于需要「整页重排」的动作 */
    private void rebuild() {
        if (this.field_22787 != null) {
            ExtrasScreen next = new ExtrasScreen(this.parent, draft);
            next.currentTab = currentTab; // 重建后还停在原来那一页
            this.field_22787.method_1507(next);
        }
    }

    private List<class_2561> combatWarnings() {
        List<class_2561> out = new ArrayList<>();
        if (!draft.enabled) {
            out.add(class_2561.method_43471("autofarm.combat.warn.master_off"));
        }
        if (draft.autoAttack) {
            if (draft.attackIntervalMs < AutoFarmConfig.ATTACK_INTERVAL_SAFE_MS) {
                out.add(class_2561.method_43471("autofarm.combat.warn.interval_low"));
            }
            if (draft.attackRange > AutoFarmConfig.ATTACK_RANGE_VANILLA) {
                out.add(class_2561.method_43471("autofarm.combat.warn.range_far"));
            }
        }
        return out;
    }

    private void openDangerConfirm(java.util.function.Consumer<Boolean> setter) {
        if (this.field_22787 == null) {
            return;
        }
        this.field_22787.method_1507(new DangerConfirmScreen(this, () -> {
            setter.accept(true);
            this.field_22787.method_1507(new ExtrasScreen(this.parent, draft));
        }));
    }

    private void drawDangerHeader(class_332 context, int originY, int relY) {
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.extras.section.combat"),
                contentX + 6, originY + relY + 4, COLOR_DANGER);
    }

    private void drawCombatExtras(class_332 context, int originY) {
        int combat = originY + SEC_COMBAT_Y;

        int intervalRow = combat + ROW_FIRST + ROW_GAP;
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.option.attack_interval"),
                contentX + 4, intervalRow + 5, COLOR_DANGER);
        context.method_27535(this.field_22793,
                class_2561.method_43469("autofarm.attack_interval.hint",
                        AutoFarmConfig.ATTACK_INTERVAL_MIN_MS, AutoFarmConfig.ATTACK_INTERVAL_MAX_MS),
                contentX + INTERVAL_LABEL_W + INTERVAL_FIELD_W + 8, intervalRow + 5, COLOR_HINT);

        if (!draft.autoAttack) {
            context.method_27535(this.field_22793,
                    class_2561.method_43471("autofarm.extras.violent_locked"),
                    contentX + INDENT + 4, combat + ROW_FIRST + 4 * ROW_GAP + 5, COLOR_HINT);
        }

        List<class_2561> warnings = combatWarnings();
        int warnY = combat + ROW_FIRST + COMBAT_ROWS * ROW_GAP + 2;
        for (int i = 0; i < warnings.size() && i < 2; i++) {
            context.method_27535(this.field_22793, warnings.get(i),
                    contentX + 4, warnY + i * 11, COLOR_DANGER);
        }
    }

    private static class_2561 dangerLabel(String optionKey, boolean value) {
        return dangerToggleLabel(optionKey, value);
    }

    private boolean currentToggle(String optionKey) {
        return switch (optionKey) {
            case "autofarm.option.auto_attack" -> draft.autoAttack;
            case "autofarm.option.auto_attack_violent" -> draft.autoAttackViolent;
            case "autofarm.option.pause_player" -> draft.pauseWhenPlayerNear;
            case "autofarm.option.humanize" -> draft.humanizeTiming;
            case "autofarm.option.random_rest" -> draft.randomRest;
            case "autofarm.option.replace_tool" -> draft.autoReplaceTool;
            case "autofarm.option.failure_cooldown" -> draft.failureCooldown;
            case "autofarm.option.verbose_hud" -> draft.verboseHud;
            case "autofarm.option.pickup_only" -> draft.pickupOnlyMode;
            case "autofarm.option.pickup_drops" -> draft.pickupDroppedItems;
            case "autofarm.option.pickup_priority" -> draft.pickupPriorityEnabled;
            case "autofarm.option.antikick" -> draft.antiKickMode;
            case "autofarm.option.reaction_delay" -> draft.reactionDelay;
            case "autofarm.option.idle_look" -> draft.idleLookAround;
            case "autofarm.option.instant_actions" -> draft.instantActions;
            case "autofarm.option.schedule" -> draft.scheduleEnabled;
            case "autofarm.option.work_area" -> draft.workAreaEnabled;
            case "autofarm.option.daylight" -> draft.workDaylightOnly;
            case "autofarm.option.clear_weather" -> draft.workClearWeatherOnly;
            case "autofarm.option.fatigue" -> draft.fatigueStop;
            case "autofarm.option.retreat" -> draft.retreatEnabled;
            case "autofarm.option.hit_reaction" -> draft.hitReactionEnabled;
            case "autofarm.option.self_rescue" -> draft.selfRescueEnabled;
            case "autofarm.option.auto_reconnect" -> draft.autoReconnectEnabled;
            case "autofarm.option.melon_harvest" -> draft.melonHarvest;
            case "autofarm.option.bone_meal" -> draft.boneMealBoost;
            case "autofarm.option.auto_supplies" -> draft.autoFetchSupplies;
            case "autofarm.option.auto_fetch_tool" -> draft.autoFetchTool;
            case "autofarm.option.notify_sounds" -> draft.notifySounds;
            case "autofarm.option.notify_toasts" -> draft.notifyToasts;
            default -> false;
        };
    }

    private void layout(class_4185 widget, int x, int y, int width) {
        widget.method_46421(x);
        widget.method_46419(y);
        widget.method_25358(width);
        addScrolling(widget);
    }

    @Override
    protected void relayout() {
        super.relayout();
        if (violentButton != null) {
            violentButton.field_22764 = violentButton.field_22764 && draft.autoAttack;
        }
        if (violenceLevelButton != null) {
            violenceLevelButton.field_22764 = violenceLevelButton.field_22764
                    && draft.autoAttack && draft.autoAttackViolent;
        }
        // 「拾取范围」「拾取对象」是从属于「优先拾取掉落物」的：那一项没开时它俩没意义。
        // 「纯拾取模式」是另一道闸，只开它同样用得上这两项，所以也放行。
        boolean pickupActive = draft.pickupDroppedItems || draft.pickupOnlyMode;
        if (pickupRadiusButton != null) {
            pickupRadiusButton.field_22764 = pickupRadiusButton.field_22764 && pickupActive;
        }
        if (pickupAllButton != null) {
            pickupAllButton.field_22764 = pickupAllButton.field_22764 && pickupActive;
        }
        // 「优先判定时长」从属于「掉落物优先」
        if (pickupPriorityTimeButton != null) {
            pickupPriorityTimeButton.field_22764 = pickupPriorityTimeButton.field_22764
                    && draft.pickupPriorityEnabled;
        }
        boolean box = draft.workAreaMode == AutoFarmConfig.AREA_MODE_BOX;
        if (workAreaRadiusButton != null) {
            workAreaRadiusButton.field_22764 = workAreaRadiusButton.field_22764 && !box;
        }
        if (workAreaCenterButton != null) {
            workAreaCenterButton.field_22764 = workAreaCenterButton.field_22764 && !box;
        }
        if (workAreaCornerAButton != null) {
            workAreaCornerAButton.field_22764 = workAreaCornerAButton.field_22764 && box;
        }
        if (workAreaCornerBButton != null) {
            workAreaCornerBButton.field_22764 = workAreaCornerBButton.field_22764 && box;
        }
        if (boneMealLimitButton != null) {
            boneMealLimitButton.field_22764 = boneMealLimitButton.field_22764 && draft.boneMealBoost;
        }
        if (boneMealThresholdButton != null) {
            boneMealThresholdButton.field_22764 = boneMealThresholdButton.field_22764
                    && draft.autoFetchSupplies;
        }
    }

    @Override
    protected void positionContent(int originY) {
        // tab 栏
        int tabY = 2;
        for (int i = 0; i < TAB_COUNT; i++) {
            setRowY(tabButtons[i], originY + tabY);
        }

        switch (currentTab) {
            case TAB_COMBAT -> positionCombat(originY);
            case TAB_STEALTH -> positionStealth(originY);
            case TAB_AREA -> positionArea(originY);
            case TAB_SURVIVAL -> positionSurvival(originY);
            case TAB_RESOURCE -> positionResource(originY);
            default -> {
            }
        }
    }

    private void positionCombat(int originY) {
        int combat = originY + SEC_COMBAT_Y;
        setRowY(combatButton, combat + ROW_FIRST);
        setRowY(attackIntervalField, combat + ROW_FIRST + ROW_GAP);
        setRowY(attackRangeButton, combat + ROW_FIRST + 2 * ROW_GAP);
        setRowY(attackTargetButton, combat + ROW_FIRST + 3 * ROW_GAP);
        setRowY(violentButton, combat + ROW_FIRST + 4 * ROW_GAP);
        setRowY(violenceLevelButton, combat + ROW_FIRST + 5 * ROW_GAP);
    }

    private void positionStealth(int originY) {
        int stealth = originY + SEC_STEALTH_Y;
        setRowY(pausePlayerButton, stealth + ROW_FIRST);
        setRowY(radiusButton, stealth + ROW_FIRST + ROW_GAP);
        setRowY(humanizeButton, stealth + ROW_FIRST + 2 * ROW_GAP);
        setRowY(randomRestButton, stealth + ROW_FIRST + 3 * ROW_GAP);
        setRowY(restIntervalButton, stealth + ROW_FIRST + 4 * ROW_GAP);
        setRowY(restDurationButton, stealth + ROW_FIRST + 5 * ROW_GAP);

        int antiKick = originY + SEC_ANTIKICK_Y;
        setRowY(antiKickButton, antiKick + ROW_FIRST);
        setRowY(antiKickLevelButton, antiKick + ROW_FIRST + ROW_GAP);

        int behavior = originY + SEC_BEHAVIOR_Y;
        setRowY(reactionDelayButton, behavior + ROW_FIRST);
        setRowY(reactionTimeButton, behavior + ROW_FIRST + ROW_GAP);
        setRowY(idleLookButton, behavior + ROW_FIRST + 2 * ROW_GAP);
        setRowY(turnTimeField, behavior + ROW_FIRST + 3 * ROW_GAP);
        setRowY(turnTimeOkButton, behavior + ROW_FIRST + 3 * ROW_GAP);
        setRowY(instantActionsButton, behavior + ROW_FIRST + 4 * ROW_GAP);
        setRowY(scheduleButton, behavior + ROW_FIRST + 5 * ROW_GAP);
        setRowY(scheduleStartButton, behavior + ROW_FIRST + 6 * ROW_GAP);
        setRowY(scheduleEndButton, behavior + ROW_FIRST + 7 * ROW_GAP);
    }

    private void positionArea(int originY) {
        int work = originY + SEC_WORKAREA_Y;
        setRowY(workAreaButton, work + ROW_FIRST);
        setRowY(workAreaModeButton, work + ROW_FIRST + ROW_GAP);
        setRowY(workAreaRadiusButton, work + ROW_FIRST + 2 * ROW_GAP);
        setRowY(workAreaCornerAButton, work + ROW_FIRST + 2 * ROW_GAP);
        setRowY(workAreaCenterButton, work + ROW_FIRST + 3 * ROW_GAP);
        setRowY(workAreaCornerBButton, work + ROW_FIRST + 3 * ROW_GAP);

        int env = originY + SEC_ENV_Y;
        setRowY(daylightButton, env + ROW_FIRST);
        setRowY(weatherButton, env + ROW_FIRST + ROW_GAP);
        setRowY(fatigueButton, env + ROW_FIRST + 2 * ROW_GAP);
        setRowY(fatigueWorkButton, env + ROW_FIRST + 3 * ROW_GAP);
        setRowY(fatigueRestButton, env + ROW_FIRST + 4 * ROW_GAP);
    }

    private void positionSurvival(int originY) {
        int survival = originY + SEC_SURVIVAL_Y;
        setRowY(retreatButton, survival + ROW_FIRST);
        setRowY(retreatHealthButton, survival + ROW_FIRST + ROW_GAP);
        setRowY(retreatDistanceButton, survival + ROW_FIRST + 2 * ROW_GAP);
        setRowY(hitReactionButton, survival + ROW_FIRST + 3 * ROW_GAP);
        setRowY(hitReactionTimeButton, survival + ROW_FIRST + 4 * ROW_GAP);
        setRowY(selfRescueButton, survival + ROW_FIRST + 5 * ROW_GAP);
        setRowY(reconnectButton, survival + ROW_FIRST + 6 * ROW_GAP);
        setRowY(reconnectDelayButton, survival + ROW_FIRST + 7 * ROW_GAP);
        setRowY(reconnectAttemptsButton, survival + ROW_FIRST + 8 * ROW_GAP);

        int tool = originY + SEC_TOOL_Y;
        setRowY(replaceToolButton, tool + ROW_FIRST);
        setRowY(durabilityButton, tool + ROW_FIRST + ROW_GAP);

        int misc = originY + SEC_MISC_Y;
        setRowY(failureCooldownButton, misc + ROW_FIRST);
        setRowY(cooldownButton, misc + ROW_FIRST + ROW_GAP);
        setRowY(verboseHudButton, misc + ROW_FIRST + 2 * ROW_GAP);

        int pickup = originY + SEC_PICKUP_Y;
        setRowY(pickupOnlyButton, pickup + ROW_FIRST);
        setRowY(pickupDropsButton, pickup + ROW_FIRST + ROW_GAP);
        setRowY(pickupRadiusButton, pickup + ROW_FIRST + 2 * ROW_GAP);
        setRowY(pickupAllButton, pickup + ROW_FIRST + 3 * ROW_GAP);
        setRowY(pickupDelayButton, pickup + ROW_FIRST + 4 * ROW_GAP);
        setRowY(pickupPriorityButton, pickup + ROW_FIRST + 5 * ROW_GAP);
        setRowY(pickupPriorityTimeButton, pickup + ROW_FIRST + 6 * ROW_GAP);
    }

    private void positionResource(int originY) {
        int gourd = originY + SEC_GOURD_Y;
        setRowY(melonHarvestButton, gourd + ROW_FIRST);
        setRowY(addCustomBlockButton, gourd + ROW_FIRST + ROW_GAP);
        setRowY(customBlocksButton, gourd + ROW_FIRST + 2 * ROW_GAP);

        int supply = originY + SEC_SUPPLY_Y;
        setRowY(boneMealBoostButton, supply + ROW_FIRST);
        setRowY(boneMealLimitButton, supply + ROW_FIRST + ROW_GAP);
        setRowY(autoSuppliesButton, supply + ROW_FIRST + 2 * ROW_GAP);
        setRowY(boneMealThresholdButton, supply + ROW_FIRST + 3 * ROW_GAP);
        setRowY(autoFetchToolButton, supply + ROW_FIRST + 4 * ROW_GAP);

        int notify = originY + SEC_NOTIFY_Y;
        setRowY(notifySoundsButton, notify + ROW_FIRST);
        setRowY(notifyToastsButton, notify + ROW_FIRST + ROW_GAP);
    }

    // ================= 自绘 =================

    @Override
    protected void renderContent(class_332 context, int originY, int mouseX, int mouseY, float delta) {
        // tab 栏底下的分隔线 + 当前 tab 高亮（高亮那一套和主面板共用）
        context.method_25294(contentX, originY + TAB_BAR_H, contentX + contentWidth, originY + TAB_BAR_H + 1, 0x30FFFFFF);
        drawTabMarker(context, tabButtons, currentTab);

        switch (currentTab) {
            case TAB_COMBAT -> {
                drawSection(context, originY, SEC_COMBAT_Y, SEC_COMBAT_H);
                drawDangerHeader(context, originY, SEC_COMBAT_Y);
                drawCombatExtras(context, originY);
            }
            case TAB_STEALTH -> {
                drawSection(context, originY, SEC_STEALTH_Y, SEC_STEALTH_H);
                drawHeader(context, originY, SEC_STEALTH_Y, "autofarm.extras.section.stealth");
                drawSection(context, originY, SEC_ANTIKICK_Y, SEC_ANTIKICK_H);
                drawHeader(context, originY, SEC_ANTIKICK_Y, "autofarm.extras.section.antikick");
                drawSection(context, originY, SEC_BEHAVIOR_Y, SEC_BEHAVIOR_H);
                drawHeader(context, originY, SEC_BEHAVIOR_Y, "autofarm.extras.section.behavior");
                drawBehaviorExtras(context, originY);
            }
            case TAB_AREA -> {
                drawSection(context, originY, SEC_WORKAREA_Y, SEC_WORKAREA_H);
                drawHeader(context, originY, SEC_WORKAREA_Y, "autofarm.extras.section.workarea");
                context.method_27535(this.field_22793,
                        class_2561.method_43471("autofarm.work_area.hint"),
                        contentX + INDENT + 4, originY + SEC_WORKAREA_Y + ROW_FIRST + 4 * ROW_GAP + 5, COLOR_HINT);
                drawSection(context, originY, SEC_ENV_Y, SEC_ENV_H);
                drawHeader(context, originY, SEC_ENV_Y, "autofarm.extras.section.environment");
            }
            case TAB_SURVIVAL -> {
                drawSection(context, originY, SEC_SURVIVAL_Y, SEC_SURVIVAL_H);
                drawHeader(context, originY, SEC_SURVIVAL_Y, "autofarm.extras.section.survival");
                drawSection(context, originY, SEC_TOOL_Y, SEC_TOOL_H);
                drawHeader(context, originY, SEC_TOOL_Y, "autofarm.extras.section.tool");
                drawSection(context, originY, SEC_MISC_Y, SEC_MISC_H);
                drawHeader(context, originY, SEC_MISC_Y, "autofarm.extras.section.misc");
                drawSection(context, originY, SEC_PICKUP_Y, SEC_PICKUP_H);
                drawHeader(context, originY, SEC_PICKUP_Y, "autofarm.extras.section.pickup");
            }
            case TAB_RESOURCE -> {
                drawSection(context, originY, SEC_GOURD_Y, SEC_GOURD_H);
                drawHeader(context, originY, SEC_GOURD_Y, "autofarm.extras.section.gourd");
                context.method_27535(this.field_22793,
                        class_2561.method_43471("autofarm.gourd.hint"),
                        contentX + INDENT + 4, originY + SEC_GOURD_Y + ROW_FIRST + 3 * ROW_GAP + 5, COLOR_HINT);
                drawSection(context, originY, SEC_SUPPLY_Y, SEC_SUPPLY_H);
                drawHeader(context, originY, SEC_SUPPLY_Y, "autofarm.extras.section.supply");
                drawSection(context, originY, SEC_NOTIFY_Y, SEC_NOTIFY_H);
                drawHeader(context, originY, SEC_NOTIFY_Y, "autofarm.extras.section.notify");
            }
            default -> {
            }
        }
    }

    // ================= 行为 =================

    private void resetAllOff() {
        draft.autoAttack = false;
        draft.autoAttackViolent = false;
        draft.attackViolence = AutoFarmConfig.VIOLENCE_LIGHT;
        draft.attackIntervalMs = 800;
        draft.attackRange = 2.9;
        draft.attackHostileOnly = true;
        draft.pauseWhenPlayerNear = false;
        draft.playerNearRadius = 16;
        draft.antiKickMode = false;
        draft.antiKickLevel = 2;
        draft.reactionDelay = false;
        draft.reactionDelayTicks = 10;
        draft.idleLookAround = false;
        draft.turnDurationMs = 600;
        draft.instantActions = false;
        draft.scheduleEnabled = false;
        draft.scheduleStartHour = 8;
        draft.scheduleEndHour = 23;
        draft.workAreaEnabled = false;
        draft.workAreaMode = AutoFarmConfig.AREA_MODE_RADIUS;
        draft.workAreaRadius = 24;
        draft.workDaylightOnly = false;
        draft.workClearWeatherOnly = false;
        draft.fatigueStop = false;
        draft.fatigueWorkMinutes = 60;
        draft.fatigueRestMinutes = 15;
        draft.retreatEnabled = false;
        draft.retreatHealthHearts = 6;
        draft.retreatDistance = 16;
        draft.hitReactionEnabled = false;
        draft.hitReactionSeconds = 2;
        draft.selfRescueEnabled = false;
        draft.autoReconnectEnabled = false;
        draft.reconnectDelaySeconds = 10;
        draft.reconnectMaxAttempts = 3;
        draft.humanizeTiming = false;
        draft.randomRest = false;
        draft.restIntervalMinutes = 10;
        draft.restDurationSeconds = 20;
        draft.autoReplaceTool = false;
        draft.toolDurabilityPercent = 10;
        draft.failureCooldown = false;
        draft.failureCooldownSeconds = 15;
        draft.verboseHud = false;
        draft.pickupOnlyMode = false;
        draft.pickupDroppedItems = false;
        draft.pickupRadius = 16;
        draft.pickupAllItems = false;
        draft.pickupDelaySeconds = 1;
        draft.pickupPriorityEnabled = false;
        draft.pickupPrioritySeconds = 8;
        draft.melonHarvest = false;
        draft.customHarvestBlocks = new ArrayList<>();
        draft.boneMealBoost = false;
        draft.boneMealLimit = 4;
        draft.autoFetchSupplies = false;
        draft.boneMealThreshold = 16;
        draft.autoFetchTool = false;
        draft.notifySounds = false;
        draft.notifyToasts = false;
        rebuild();
    }

    @Override
    protected void onCancel() {
        draft.autoAttack = old.autoAttack;
        draft.autoAttackViolent = old.autoAttackViolent;
        draft.attackViolence = old.attackViolence;
        draft.attackIntervalMs = old.attackIntervalMs;
        draft.attackRange = old.attackRange;
        draft.attackHostileOnly = old.attackHostileOnly;
        draft.pauseWhenPlayerNear = old.pauseWhenPlayerNear;
        draft.playerNearRadius = old.playerNearRadius;
        draft.antiKickMode = old.antiKickMode;
        draft.antiKickLevel = old.antiKickLevel;
        draft.reactionDelay = old.reactionDelay;
        draft.reactionDelayTicks = old.reactionDelayTicks;
        draft.idleLookAround = old.idleLookAround;
        draft.turnDurationMs = old.turnDurationMs;
        draft.instantActions = old.instantActions;
        draft.scheduleEnabled = old.scheduleEnabled;
        draft.scheduleStartHour = old.scheduleStartHour;
        draft.scheduleEndHour = old.scheduleEndHour;
        draft.workAreaEnabled = old.workAreaEnabled;
        draft.workAreaMode = old.workAreaMode;
        draft.workAreaX = old.workAreaX;
        draft.workAreaY = old.workAreaY;
        draft.workAreaZ = old.workAreaZ;
        draft.workAreaRadius = old.workAreaRadius;
        draft.workAreaX2 = old.workAreaX2;
        draft.workAreaY2 = old.workAreaY2;
        draft.workAreaZ2 = old.workAreaZ2;
        draft.workDaylightOnly = old.workDaylightOnly;
        draft.workClearWeatherOnly = old.workClearWeatherOnly;
        draft.fatigueStop = old.fatigueStop;
        draft.fatigueWorkMinutes = old.fatigueWorkMinutes;
        draft.fatigueRestMinutes = old.fatigueRestMinutes;
        draft.retreatEnabled = old.retreatEnabled;
        draft.retreatHealthHearts = old.retreatHealthHearts;
        draft.retreatDistance = old.retreatDistance;
        draft.hitReactionEnabled = old.hitReactionEnabled;
        draft.hitReactionSeconds = old.hitReactionSeconds;
        draft.selfRescueEnabled = old.selfRescueEnabled;
        draft.autoReconnectEnabled = old.autoReconnectEnabled;
        draft.reconnectDelaySeconds = old.reconnectDelaySeconds;
        draft.reconnectMaxAttempts = old.reconnectMaxAttempts;
        draft.humanizeTiming = old.humanizeTiming;
        draft.randomRest = old.randomRest;
        draft.restIntervalMinutes = old.restIntervalMinutes;
        draft.restDurationSeconds = old.restDurationSeconds;
        draft.autoReplaceTool = old.autoReplaceTool;
        draft.toolDurabilityPercent = old.toolDurabilityPercent;
        draft.failureCooldown = old.failureCooldown;
        draft.failureCooldownSeconds = old.failureCooldownSeconds;
        draft.verboseHud = old.verboseHud;
        draft.pickupOnlyMode = old.pickupOnlyMode;
        draft.pickupDroppedItems = old.pickupDroppedItems;
        draft.pickupRadius = old.pickupRadius;
        draft.pickupAllItems = old.pickupAllItems;
        draft.pickupDelaySeconds = old.pickupDelaySeconds;
        draft.pickupPriorityEnabled = old.pickupPriorityEnabled;
        draft.pickupPrioritySeconds = old.pickupPrioritySeconds;
        draft.melonHarvest = old.melonHarvest;
        draft.customHarvestBlocks = new ArrayList<>(old.customHarvestBlocks);
        draft.boneMealBoost = old.boneMealBoost;
        draft.boneMealLimit = old.boneMealLimit;
        draft.autoFetchSupplies = old.autoFetchSupplies;
        draft.boneMealThreshold = old.boneMealThreshold;
        draft.autoFetchTool = old.autoFetchTool;
        draft.notifySounds = old.notifySounds;
        draft.notifyToasts = old.notifyToasts;
        backToParent();
    }

    // ================= 文案 =================

    private static int nextChoice(int[] choices, int current) {
        for (int i = 0; i < choices.length; i++) {
            if (choices[i] == current) {
                return choices[(i + 1) % choices.length];
            }
        }
        return choices[0];
    }

    private static double nextChoice(double[] choices, double current) {
        for (int i = 0; i < choices.length; i++) {
            if (Math.abs(choices[i] - current) < 1e-6) {
                return choices[(i + 1) % choices.length];
            }
        }
        return choices[0];
    }

    private static class_2561 optionLabel(String optionKey, class_2561 value) {
        return class_2561.method_43469("autofarm.toggle", class_2561.method_43471(optionKey), value);
    }

    private class_2561 radiusLabel() {
        return optionLabel("autofarm.option.player_radius",
                class_2561.method_43469("autofarm.value.blocks", draft.playerNearRadius));
    }

    private class_2561 restIntervalLabel() {
        return optionLabel("autofarm.option.rest_interval",
                class_2561.method_43469("autofarm.value.minutes", draft.restIntervalMinutes));
    }

    private class_2561 restDurationLabel() {
        return optionLabel("autofarm.option.rest_duration",
                class_2561.method_43469("autofarm.value.seconds", draft.restDurationSeconds));
    }

    private class_2561 durabilityLabel() {
        return optionLabel("autofarm.option.tool_threshold",
                class_2561.method_43469("autofarm.value.percent", draft.toolDurabilityPercent));
    }

    private class_2561 cooldownLabel() {
        return optionLabel("autofarm.option.cooldown_seconds",
                class_2561.method_43469("autofarm.value.seconds", draft.failureCooldownSeconds));
    }

    private class_2561 pickupDelayLabel() {
        return optionLabel("autofarm.option.pickup_delay",
                class_2561.method_43469("autofarm.value.seconds", draft.pickupDelaySeconds));
    }

    private class_2561 pickupPriorityTimeLabel() {
        return optionLabel("autofarm.option.pickup_priority_time",
                class_2561.method_43469("autofarm.value.seconds", draft.pickupPrioritySeconds));
    }

    private class_2561 pickupRadiusLabel() {
        return optionLabel("autofarm.option.pickup_radius",
                class_2561.method_43469("autofarm.value.blocks", draft.pickupRadius));
    }

    private class_2561 pickupAllLabel() {
        return optionLabel("autofarm.option.pickup_all",
                class_2561.method_43471(draft.pickupAllItems
                        ? "autofarm.pickup_all.yes" : "autofarm.pickup_all.no"));
    }

    private class_2561 attackRangeLabel() {
        return optionLabel("autofarm.option.attack_range",
                class_2561.method_43469("autofarm.value.blocks", String.format("%.1f", draft.attackRange)));
    }

    private class_2561 attackTargetLabel() {
        return optionLabel("autofarm.option.attack_target",
                class_2561.method_43471(draft.attackHostileOnly
                        ? "autofarm.attack_target.hostile"
                        : "autofarm.attack_target.all"));
    }

    private class_2561 violenceLabel() {
        return optionLabel("autofarm.option.attack_violence",
                class_2561.method_43471("autofarm.attack_violence.level." + violenceKey(draft.attackViolence)));
    }

    private static String violenceKey(int level) {
        return switch (level) {
            case 1 -> "medium";
            case 2 -> "lifesaver";
            default -> "light";
        };
    }

    private class_2561 antiKickLevelLabel() {
        return optionLabel("autofarm.option.antikick_level",
                class_2561.method_43471("autofarm.antikick.level." + levelKey(draft.antiKickLevel)));
    }

    private class_2561 reactionTimeLabel() {
        return optionLabel("autofarm.option.reaction_time",
                class_2561.method_43469("autofarm.value.seconds",
                        String.format("%.1f", draft.reactionDelayTicks / 20.0)));
    }

    /** 「行为真实感」分区的自绘部分：转向时间的标签、范围提示、待确认 / 过小警告 */
    private void drawBehaviorExtras(class_332 context, int originY) {
        int behavior = originY + SEC_BEHAVIOR_Y;
        int row = behavior + ROW_FIRST + 3 * ROW_GAP;
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.option.turn_time"),
                contentX + 4, row + 5, 0xFFFFFFFF);
        context.method_27535(this.field_22793,
                class_2561.method_43469("autofarm.turn_time.hint",
                        AutoFarmConfig.TURN_DURATION_MIN, AutoFarmConfig.TURN_DURATION_MAX),
                contentX + INDENT + INTERVAL_LABEL_W + INTERVAL_FIELD_W + TURN_OK_GAP
                        + TURN_OK_W + 6,
                row + 5, COLOR_HINT);
        // 分区底部那一行留给了「危险值」的提示。两种情况共用这一行：
        //   · 还没确认 → 暖色：填了但没生效，按 Enter / 点「确认」才应用；
        //   · 已经确认 → 红色：这个值会让转身太突兀，容易被看出是机器在操作。
        //   0 = 完全关掉平滑转向，同样按「危险值」对待。
        int warnY = behavior + ROW_FIRST + BEHAVIOR_ROWS * ROW_GAP + 2;
        if (turnTimePending) {
            context.method_27535(this.field_22793,
                    class_2561.method_43471("autofarm.turn_time.pending"),
                    contentX + 4, warnY, COLOR_NOTICE);
        } else if (draft.turnDurationMs < AutoFarmConfig.TURN_DURATION_SAFE_MS) {
            context.method_27535(this.field_22793,
                    class_2561.method_43469("autofarm.turn_time.warn", AutoFarmConfig.TURN_DURATION_SAFE_MS),
                    contentX + 4, warnY, COLOR_DANGER);
        }
    }

    // ================= 「转向时间」的确认流程 =================

    /**
     * 输入框被改动时：安全值<b>即时生效</b>，危险值（小于安全阈值，含 0）<b>先挂着</b>。
     *
     * <p>挂着的意思是「只在输入框里显示，不写进草稿」—— 于是哪怕玩家转头就去点保存，
     * 存下去的也是上一个安全值，绝不会是那个突兀的 0。
     */
    private void onTurnTimeEdited(String text) {
        Integer typed = parseTurnTime(text);
        if (typed == null) {
            return; // 空着 / 非法 → 不动草稿
        }
        int value = clampInt(typed, AutoFarmConfig.TURN_DURATION_MIN, AutoFarmConfig.TURN_DURATION_MAX);
        if (value >= AutoFarmConfig.TURN_DURATION_SAFE_MS) {
            draft.turnDurationMs = value;
            turnTimePending = false;
        } else {
            // 危险值：先不写。等 Enter / 「确认」/ 离页时统一过一次风险提示屏。
            turnTimePending = value != draft.turnDurationMs;
        }
    }

    /**
     * 把输入框里的值定下来。
     *
     * @return true 表示「弹了风险提示屏、正等着玩家答复」—— 调用方此时别再往下走
     */
    private boolean commitTurnTime() {
        if (turnTimeField == null) {
            return false;
        }
        Integer typed = parseTurnTime(turnTimeField.method_1882());
        if (typed == null) {
            // 空 / 非法：恢复成当前生效值，不用确认
            turnTimeField.method_1852(Integer.toString(draft.turnDurationMs));
            turnTimePending = false;
            return false;
        }
        int value = clampInt(typed, AutoFarmConfig.TURN_DURATION_MIN, AutoFarmConfig.TURN_DURATION_MAX);
        if (value != typed) {
            turnTimeField.method_1852(Integer.toString(value)); // 超出范围：拉回边界并回填
        }

        // 安全值 或 本来就是当前值 → 直接生效
        if (value >= AutoFarmConfig.TURN_DURATION_SAFE_MS || value == draft.turnDurationMs) {
            draft.turnDurationMs = value;
            turnTimePending = false;
            return false;
        }
        if (this.field_22787 == null) {
            draft.turnDurationMs = value;
            turnTimePending = false;
            return false;
        }

        // 危险值：过一次风险提示屏。确认才写进草稿；取消则什么都改（输入框会在重建时回到旧值）。
        turnTimePending = false;
        this.field_22787.method_1507(new DangerConfirmScreen(this, () -> {
            draft.turnDurationMs = value;
            if (turnTimeField != null) {
                turnTimeField.method_1852(Integer.toString(value));
            }
        }, "autofarm.danger.title", "autofarm.turn_time.danger.subtitle",
                "autofarm.turn_time.danger.body1", "autofarm.turn_time.danger.body2"));
        return true;
    }

    /** 输入框里的整数；空 / 非法返回 null */
    private static Integer parseTurnTime(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        try {
            return Integer.valueOf(text.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** 点「完成」：先把转向时间定下来（可能要过一次确认屏），再回上层 */
    private void onDone() {
        if (commitTurnTime()) {
            return; // 弹了确认屏，等玩家答复，先别走
        }
        backToParent();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        // 在「转向时间」输入框里按 Enter = 点「确认」：危险值在这里弹风险提示
        if ((keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)
                && turnTimeField != null && turnTimeField.method_25370()) {
            commitTurnTime();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private class_2561 scheduleStartLabel() {
        return optionLabel("autofarm.option.schedule_start", hourText(draft.scheduleStartHour));
    }

    private class_2561 scheduleEndLabel() {
        return optionLabel("autofarm.option.schedule_end", hourText(draft.scheduleEndHour));
    }

    private static class_2561 hourText(int hour) {
        return class_2561.method_43469("autofarm.value.hour", String.format("%02d", hour));
    }

    private class_2561 workAreaModeLabel() {
        return optionLabel("autofarm.option.work_area_mode",
                class_2561.method_43471(draft.workAreaMode == AutoFarmConfig.AREA_MODE_BOX
                        ? "autofarm.area_mode.box"
                        : "autofarm.area_mode.radius"));
    }

    private class_2561 workAreaRadiusLabel() {
        return optionLabel("autofarm.option.work_area_radius",
                class_2561.method_43469("autofarm.value.blocks", draft.workAreaRadius));
    }

    private class_2561 workAreaCenterLabel() {
        return class_2561.method_43469("autofarm.work_area.record_center", coordText(draft.workAreaText()));
    }

    private class_2561 workAreaCornerALabel() {
        return class_2561.method_43469("autofarm.work_area.record_a", coordText(draft.workAreaText()));
    }

    private class_2561 workAreaCornerBLabel() {
        return class_2561.method_43469("autofarm.work_area.record_b", coordText(draft.workAreaSecondText()));
    }

    private static class_2561 coordText(String text) {
        return text == null ? class_2561.method_43471("autofarm.work_area.none") : class_2561.method_43470(text);
    }

    private class_2561 fatigueWorkLabel() {
        return optionLabel("autofarm.option.fatigue_work",
                class_2561.method_43469("autofarm.value.minutes", draft.fatigueWorkMinutes));
    }

    private class_2561 fatigueRestLabel() {
        return optionLabel("autofarm.option.fatigue_rest",
                draft.fatigueRestMinutes <= 0
                        ? class_2561.method_43471("autofarm.fatigue_rest.manual")
                        : class_2561.method_43469("autofarm.value.minutes", draft.fatigueRestMinutes));
    }

    private class_2561 retreatHealthLabel() {
        return optionLabel("autofarm.option.retreat_health",
                class_2561.method_43469("autofarm.value.hearts", draft.retreatHealthHearts));
    }

    private class_2561 retreatDistanceLabel() {
        return optionLabel("autofarm.option.retreat_distance",
                class_2561.method_43469("autofarm.value.blocks", draft.retreatDistance));
    }

    private class_2561 hitReactionTimeLabel() {
        return optionLabel("autofarm.option.hit_reaction_time",
                class_2561.method_43469("autofarm.value.seconds", draft.hitReactionSeconds));
    }

    private class_2561 reconnectDelayLabel() {
        return optionLabel("autofarm.option.reconnect_delay",
                class_2561.method_43469("autofarm.value.seconds", draft.reconnectDelaySeconds));
    }

    private class_2561 reconnectAttemptsLabel() {
        return optionLabel("autofarm.option.reconnect_attempts",
                draft.reconnectMaxAttempts <= 0
                        ? class_2561.method_43471("autofarm.reconnect_attempts.unlimited")
                        : class_2561.method_43469("autofarm.value.count", draft.reconnectMaxAttempts));
    }

    private class_2561 customBlocksLabel() {
        int n = draft.customHarvestBlocks == null ? 0 : draft.customHarvestBlocks.size();
        return optionLabel("autofarm.option.custom_blocks",
                class_2561.method_43469("autofarm.value.count", n));
    }

    private class_2561 boneMealLimitLabel() {
        return optionLabel("autofarm.option.bone_meal_limit",
                class_2561.method_43469("autofarm.value.count", draft.boneMealLimit));
    }

    private class_2561 boneMealThresholdLabel() {
        return optionLabel("autofarm.option.bone_meal_threshold",
                class_2561.method_43469("autofarm.value.count", draft.boneMealThreshold));
    }

    private void addLookedBlock() {
        if (this.field_22787 == null || this.field_22787.field_1687 == null) {
            return;
        }
        class_239 hit = this.field_22787.field_1765;
        if (hit == null || hit.method_17783() != class_239.class_240.field_1332) {
            toast("autofarm.custom_block.no_target");
            return;
        }
        class_2680 state = this.field_22787.field_1687.method_8320(((class_3965) hit).method_17777());
        class_2248 block = state.method_26204();
        if (block == class_2246.field_10124) {
            toast("autofarm.custom_block.no_target");
            return;
        }
        String id = CropRegistry.idOf(block);
        if (id == null) {
            toast("autofarm.custom_block.no_target");
            return;
        }
        if (draft.customHarvestBlocks == null) {
            draft.customHarvestBlocks = new ArrayList<>();
        }
        if (draft.customHarvestBlocks.contains(id)) {
            toast("autofarm.custom_block.duplicate");
            return;
        }
        confirmThen("autofarm.custom_block.warn.subtitle", () -> {
            draft.customHarvestBlocks.add(id);
            rebuild();
        }, "autofarm.custom_block.warn.body1",
                "autofarm.custom_block.warn.body2", "autofarm.custom_block.warn.body3");
    }

    private void clearCustomBlocks() {
        if (draft.customHarvestBlocks == null || draft.customHarvestBlocks.isEmpty()) {
            toast("autofarm.custom_block.empty");
            return;
        }
        confirmThen("autofarm.custom_block.clear.subtitle", () -> {
            draft.customHarvestBlocks.clear();
            rebuild();
        }, "autofarm.custom_block.clear.body1");
    }

    private void recordCurrentPos(boolean second) {
        if (this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }
        class_2338 pos = this.field_22787.field_1724.method_24515();
        if (second) {
            draft.setWorkAreaSecond(pos.method_10263(), pos.method_10264(), pos.method_10260());
        } else {
            draft.setWorkArea(pos.method_10263(), pos.method_10264(), pos.method_10260());
        }
    }

    private static String levelKey(int level) {
        return switch (level) {
            case 1 -> "light";
            case 2 -> "medium";
            case 3 -> "high";
            default -> "off";
        };
    }
}
