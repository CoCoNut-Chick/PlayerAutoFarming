package com.autofarm.client.interact;

import com.autofarm.client.config.AutoFarmConfig;
import com.autofarm.client.config.ConfigManager;
import com.autofarm.client.human.Humanizer;
import com.autofarm.client.inventory.InventoryScanner;
import com.autofarm.client.path.BlockNavigator;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_746;

/**
 * 「和世界打交道」的公共动作层：转向、挖方块、放方块。
 *
 * <p>走路（{@code PathWalker}）和收割（{@code CropHarvester}）都要做这三件事，
 * 所以抽到一层里，两边共用同一套实现 —— 尤其是挖掘，里面有个必须共用的开关
 * （见下面的 {@link #isDriving()}）。
 *
 * <h2>为什么挖方块需要一个开关</h2>
 * 我们是用 {@code updateBlockBreakingProgress} 一格一格把方块「挖」掉的，
 * 走的是原版交互管理器，和真人按住左键完全同一条路。
 *
 * <p>但原版每 tick 都有一段逻辑：如果<b>攻击键没按着</b>，就调
 * {@code cancelBlockBreaking()} 把当前破坏进度清零。我们本来就没按攻击键
 * （按键是玩家的，我们不去动它），于是每一 tick 我们攒的进度都会被下一 tick 清掉 ——
 * 结果就是「对着方块挥了半天，方块纹丝不动」，硬度 0 的作物能碎，石头永远挖不掉。
 *
 * <p>解决办法是 {@link com.autofarm.client.mixin.MinecraftClientMixin}：
 * 当这一 tick 是<b>我们</b>在挖的时候，把原版那一段整体跳过。
 * 也就是说这个类里维护的 {@link #driving} 标记，就是「这一 tick 让不让我挖」的开关：
 * <ul>
 *   <li>{@link #beginTick()} —— 每 tick 开头先置 false；</li>
 *   <li>{@link #mineTick} —— 哪次真的动了镐子，就置成 true；</li>
 *   <li>原版读它 —— 为 true 时它既不取消我们的进度，也不去挖准星指着的那格。</li>
 * </ul>
 * 不挖的 tick 它自然是 false，原版的挖掘行为一个字都不受影响。
 */
public final class BlockInteractor {

    /** 每 tick 最多转多少度 */
    private static final float MAX_TURN_PER_TICK = 18.0f;

    /**
     * 挖/放之前准星允许偏多少度。
     *
     * <p>不用要求完全对准（那样会因为浮点误差一直「差一点点」），
     * 但这个容差必须够小 —— 服务端看到的方块朝向取自准星方向，
     * 偏太多就变成「面朝着别处挖方块」了。
     */
    private static final float PLACE_AIM_TOLERANCE = 12.0f;

    /** 本 tick 我们是不是自己在挖方块（给 Mixin 看的开关） */
    private static boolean driving;

    private BlockInteractor() {
    }

    // ================= 挖掘开关 =================

    /** 每 tick 开头复位，由 {@code FarmTaskManager} 在 tick 最先调用 */
    public static void beginTick() {
        driving = false;
    }

    /** 立刻关掉（退出世界、停手时用） */
    public static void clearDriving() {
        driving = false;
    }

    /** 原版的挖掘逻辑要不要给我们让路 */
    public static boolean isDriving() {
        return driving;
    }

    // ================= 转向 / 瞄准 =================

    /** 限速转向到某个水平坐标（每 tick 最多 {@value #MAX_TURN_PER_TICK} 度） */
    public static void turnTowards(class_746 player, double targetX, double targetZ) {
        double dx = targetX - player.method_23317();
        double dz = targetZ - player.method_23321();
        if (dx * dx + dz * dz < 1.0e-6) {
            return;
        }
        // Minecraft 的 yaw 0 度朝 +Z，顺时针增加，所以朝向 (dx, dz) 需要的 yaw 是 atan2(-dx, dz)
        float desiredYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        player.method_36456(approach(player.method_36454(), desiredYaw));
    }

    /**
     * 把准星<b>对准</b>一个世界坐标（同时转 yaw 和 pitch）。
     *
     * <p>这是「看起来像真人」的关键一步。只转 yaw 的话角色会面朝目标，
     * 但准星还停在水平线上 —— 挖方块时服务端看到的视角是「低头看着地面却报了个方块」，
     * 很扎眼。瞄准点取目标方块的<b>几何中心</b>，也就是真人会瞄的位置。
     *
     * <p>同样是限速的（每 tick 最多 {@value #MAX_TURN_PER_TICK} 度），
     * 所以视角是「转过去」的，不是瞬间甩过去的。
     */
    public static void aimAt(class_746 player, double x, double y, double z) {
        if (player == null) {
            return;
        }
        class_243 eye = player.method_33571();
        double dx = x - eye.field_1352;
        double dy = y - eye.field_1351;
        double dz = z - eye.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 1.0e-6 && Math.abs(dy) < 1.0e-6) {
            return;
        }

        // 防踢模式：给「该瞄哪儿」叠一点点人手晃动。幅度控制在 1.5 度以内，
        // 远小于 {@value #PLACE_AIM_TOLERANCE} 度的交互容差 —— 视角不再精确压在
        // 方块正中心，但该命中的照样命中。
        float desiredYaw = (float) Math.toDegrees(Math.atan2(-dx, dz)) + Humanizer.aimYawJitter();
        // pitch 正值代表低头：目标在下方（dy < 0）时 -atan2 得到正值
        float desiredPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal)) + Humanizer.aimPitchJitter();

        float limit = Humanizer.turnLimit(MAX_TURN_PER_TICK);
        player.method_36456(approach(player.method_36454(), desiredYaw));
        player.method_36457(class_3532.method_15363(
                player.method_36455() + class_3532.method_15363(
                        desiredPitch - player.method_36455(), -limit, limit),
                -90.0f, 90.0f));
    }

    /** 把准星对准某个方块的中心 */
    public static void aimAt(class_746 player, class_2338 pos) {
        if (pos != null) {
            aimAt(player, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
        }
    }

    /**
     * 准星已经压在目标上了吗（差角小于 {@code tolerance} 度）。
     *
     * <p>挖和放都先过这一关：视角还没转到位就先不动手。否则会出现
     * 「头还在甩，方块先被挖了」，看着就是机器人在操作。
     *
     * <p>目标离眼睛极近时（贴脸）直接算「已经对准」—— 那种情况算角度没有意义，
     * 不特判会让它原地一直转。
     */
    public static boolean isAimedAt(class_746 player, double x, double y, double z,
                                    float tolerance) {
        if (player == null) {
            return false;
        }
        class_243 eye = player.method_33571();
        double dx = x - eye.field_1352;
        double dy = y - eye.field_1351;
        double dz = z - eye.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal < 0.35 && Math.abs(dy) < 0.35) {
            return true;
        }
        if (horizontal < 1.0e-6 && Math.abs(dy) < 1.0e-6) {
            return true;
        }
        float desiredYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float desiredPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        return Math.abs(class_3532.method_15393(desiredYaw - player.method_36454())) <= tolerance
                && Math.abs(desiredPitch - player.method_36455()) <= tolerance;
    }

    /** 准星已经压在某个方块的中心上了吗 */
    public static boolean isAimedAt(class_746 player, class_2338 pos, float tolerance) {
        return pos != null && isAimedAt(player, pos.method_10263() + 0.5, pos.method_10264() + 0.5,
                pos.method_10260() + 0.5, tolerance);
    }

    /**
     * 从当前角度朝目标角度靠近一步。
     *
     * <p>步长是 {@value #MAX_TURN_PER_TICK} 度 —— 但防踢模式开着时，
     * 这个上限本身会随时间小幅起伏（见 {@link Humanizer#turnLimit}），
     * 于是转头速度不再是「每 tick 刚好 18 度」这种一眼假的匀速度。
     */
    private static float approach(float current, float desired) {
        float diff = class_3532.method_15393(desired - current);
        float limit = Humanizer.turnLimit(MAX_TURN_PER_TICK);
        return current + class_3532.method_15363(diff, -limit, limit);
    }

    /** 玩家该朝向方块的哪一面（服务端要拿它校验，随便给一个会掉线） */
    public static class_2350 faceTowards(class_746 player, class_2338 pos) {
        class_2338 feet = player.method_24515();
        int dx = Integer.signum(pos.method_10263() - feet.method_10263());
        int dy = Integer.signum(pos.method_10264() - feet.method_10264());
        int dz = Integer.signum(pos.method_10260() - feet.method_10260());
        class_2350 dir = class_2350.method_50026(-dx, -dy, -dz);
        return dir == null ? class_2350.field_11036 : dir;
    }

    // ================= 挖一格 =================

    /**
     * 挖一 tick。进度由原版累积，所以我们每 tick 调一次就行。
     *
     * <p>两件事：先看要不要换手，再把这一 tick 的破坏进度发出去。
     */
    public static void mineTick(class_310 client, class_2338 pos) {
        class_746 player = client == null ? null : client.field_1724;
        if (player == null || client.field_1687 == null || client.field_1761 == null) {
            return;
        }

        // 换手要抢在开挖之前：挖到一半再换，原版会把进度清零重来。
        // 所以这里切完就返回，等下一 tick 才真正动镐子。
        if (ConfigManager.get().autoSelectTool && switchToBestTool(client, player, pos)) {
            return;
        }

        client.field_1761.method_2902(pos, faceTowards(player, pos));
        player.method_6104(class_1268.field_5808);

        // 告诉 Mixin：这一 tick 的破坏是我们发起的，别让原版把它清掉
        driving = true;
    }

    /**
     * 把快捷栏切到「挖这个方块最合适」的那一格。
     *
     * <p>只改 {@code selectedSlot}：原版客户端每 tick 都会发现手换过了并自动同步给服务端，
     * 所以不用自己发包，服务端看到的就是一次普通的换手。
     *
     * @return true 表示刚刚换过手（这一 tick 先别挖）
     */
    private static boolean switchToBestTool(class_310 client, class_746 player, class_2338 pos) {
        class_2680 state = client.field_1687.method_8320(pos);
        int slot = InventoryScanner.findBestToolSlot(player, state);
        if (slot < 0) {
            return false;
        }
        player.method_31548().field_7545 = slot;
        return true;
    }

    // ================= 放一块 =================

    /**
     * 用快捷栏第 {@code hotbarSlot} 格的物品，在 {@code placePos} 放下去。
     *
     * <p>三步：找一面能「贴着放」的邻居 → 把要用的东西换到主手 → 构造命中结果发出去。
     * 发出去的是 {@code interactBlock}，和真人右键完全同一条路，
     * 服务端看到的就只是一个普通玩家在放方块。
     *
     * @return 有没有真的发出这次交互
     */
    public static boolean placeWith(class_310 client, class_2338 placePos, int hotbarSlot) {
        class_746 player = client == null ? null : client.field_1724;
        if (player == null || client.field_1687 == null || client.field_1761 == null) {
            return false;
        }
        if (hotbarSlot < 0) {
            return false;
        }

        // 1. 方块是「贴着某个实心方块」放上去的，先找一面能贴的
        class_2350 attach = null;
        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbour = placePos.method_10093(dir);
            if (!BlockNavigator.isPassableAt(client.field_1687, neighbour.method_10263(), neighbour.method_10264(), neighbour.method_10260())) {
                attach = dir;
                break;
            }
        }
        if (attach == null) {
            return false;
        }

        // 2. 把要用的东西换到主手。走原版换位包（selectHotbarSlot），
        // 而不是直接改 selectedSlot —— 那样本地换了、服务端还以为你拿着旧东西。
        if (!InventoryScanner.selectHotbarSlot(client, player, hotbarSlot)) {
            return false;
        }

        // 3. 构造命中结果：击中的是那个邻居方块，击中的面朝向要放置的位置
        class_2338 neighbour = placePos.method_10093(attach);
        class_2350 side = attach.method_10153();
        class_243 hitPos = new class_243(
                neighbour.method_10263() + 0.5 + side.method_10148() * 0.5,
                neighbour.method_10264() + 0.5 + side.method_10164() * 0.5,
                neighbour.method_10260() + 0.5 + side.method_10165() * 0.5);

        // 4. 抬手之前先把准星压到那一面上。差得太远就先不发交互 ——
        // 调用方是每隔几 tick 试一次的，下一轮视角就更接近了。
        // 极效率模式例外：放置也无视准星，直接构造合法命中发出去（代价是面朝向
        // 可能与实际视角不符，服务端对放置的朝向校验比破坏宽松）。
        if (ConfigManager.get().aimMode != AutoFarmConfig.AIM_EXTREME) {
            aimAt(player, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350);
            if (!isAimedAt(player, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350, PLACE_AIM_TOLERANCE)) {
                return false;
            }
        }

        class_3965 hit = new class_3965(hitPos, side, neighbour, false);
        client.field_1761.method_2896(player, class_1268.field_5808, hit);
        player.method_6104(class_1268.field_5808);
        return true;
    }

    /**
     * 右键一个方块（开箱子、拉杆这类）。
     *
     * <p>和 {@link #placeWith} 走同一个入口 {@code interactBlock}，
     * 区别是不需要挑邻居、也不需要换手 —— 直接朝着方块中心发一次交互。
     * 客户端上的 {@code onUse} 会立刻返回成功，所以就算手里拿着方块也不会误放。
     *
     * @return 有没有真的发出这次交互
     */
    public static boolean useBlock(class_310 client, class_2338 pos) {
        class_746 player = client == null ? null : client.field_1724;
        if (player == null || client.field_1761 == null || pos == null) {
            return false;
        }
        class_243 center = class_243.method_24953(pos);
        class_2350 side = faceTowards(player, pos);
        // 极效率模式：右键也无视准星，直接朝方块中心发交互。
        if (ConfigManager.get().aimMode != AutoFarmConfig.AIM_EXTREME) {
            aimAt(player, center.field_1352, center.field_1351, center.field_1350);
            if (!isAimedAt(player, center.field_1352, center.field_1351, center.field_1350, PLACE_AIM_TOLERANCE)) {
                return false;
            }
        }
        client.field_1761.method_2896(player, class_1268.field_5808,
                new class_3965(center, side, pos, false));
        player.method_6104(class_1268.field_5808);
        return true;
    }

    /** 视线离目标超过这个距离就没必要再按交互键了（原版够得着是 4.5 格） */
    public static boolean isWithinReach(class_746 player, class_2338 pos, double reach) {
        return player != null && pos != null
                && player.method_33571().method_1025(class_243.method_24953(pos)) <= reach * reach;
    }
}
