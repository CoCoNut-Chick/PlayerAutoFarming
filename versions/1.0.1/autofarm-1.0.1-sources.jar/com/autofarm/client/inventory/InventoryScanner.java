package com.autofarm.client.inventory;

import com.autofarm.client.config.AutoFarmConfig;
import com.autofarm.client.scan.CropRegistry;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2682;
import net.minecraft.class_310;
import net.minecraft.class_4174;
import net.minecraft.class_746;

/**
 * 「我现在身上有什么」的快速体检。
 *
 * <h2>为什么只看快捷栏</h2>
 * Minecraft 里放置方块用的是<b>主手</b>，而主手拿的东西由快捷栏（前 9 格）决定。
 * 背包深处的方块必须先搬到快捷栏才用得上，中间要开背包、点格子，
 * 对一个「边走路边干活」的自动化流程来说太重了。
 *
 * <p>所以这里的约定是：<b>想让它拿来垫脚的方块，请放进快捷栏</b>。
 * 这样既能自动选中（改 {@code selectedSlot} 就行，不用开界面），也不会误动你背包里
 * 精心整理好的东西。挖掘工具同理 —— 见 {@link #bestTool}：
 * 挖之前会先在快捷栏里挑一把最合适的换到手上，挑不到比空手更好的就保持不动。
 */
public final class InventoryScanner {

    /** 玩家背包的总格数：快捷栏 9 + 主栏 27 */
    public static final int INVENTORY_SLOTS = 36;

    private InventoryScanner() {
    }

    /**
     * 一把候选工具：在第几格、对这个方块多快、是不是「正确工具」。
     *
     * @param slot     快捷栏槽位（0~8）
     * @param speed    对目标方块的挖掘速度倍数（原版 {@code getMiningSpeedMultiplier}）
     * @param suitable 是不是挖这种方块该用的工具（决定掉落物和 30 / 100 的除数）
     */
    public record ToolChoice(int slot, float speed, boolean suitable) {
    }

    /**
     * 在快捷栏里挑一把「对目标方块最合适」的工具。
     *
     * <p>打分用的是原版破坏速度公式的核心：{@code 速度 / (30 或 100)}。
     * 除数取 30 表示「这是挖这种方块该用的工具」（掉落物正常，而且快三倍多），
     * 否则取 100。硬度是同一个方块共有的属性，比较时约得掉，所以这里不用管。
     *
     * <p><b>基准是「现在手上这把」</b>，只有确实更快才换。所以快捷栏里放把镐子，
     * 遇到石头它会自己换过去；全是没用的东西时，它不会乱动你的手。
     *
     * @return 最优选择；玩家或方块状态为空时返回 null
     */
    public static ToolChoice bestTool(class_746 player, class_2680 state) {
        if (player == null || state == null) {
            return null;
        }
        class_1661 inventory = player.method_31548();
        int hotbar = class_1661.method_7368();
        int selected = inventory.field_7545;

        // 基准：现在手上这把（空手就是速度 1、非正确工具）
        class_1799 held = inventory.method_5438(selected);
        float heldSpeed = held.method_7960() ? 1.0f : held.method_7924(state);
        boolean heldSuitable = !held.method_7960() && held.method_7951(state);
        ToolChoice best = new ToolChoice(selected, heldSpeed, heldSuitable);
        float bestScore = score(heldSpeed, heldSuitable);

        for (int slot = 0; slot < hotbar; slot++) {
            if (slot == selected) {
                continue;
            }
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }
            float speed = stack.method_7924(state);
            boolean suitable = stack.method_7951(state);
            float current = score(speed, suitable);
            // 必须「确实更快」才换手，同分时保持不动，免得两把一样的镐子之间来回跳
            if (current > bestScore + 1.0e-4f) {
                bestScore = current;
                best = new ToolChoice(slot, speed, suitable);
            }
        }
        return best;
    }

    /**
     * 挖某个方块之前，该把快捷栏切到第几格。
     *
     * @return <b>-1</b> 表示不用换（现在手上这把就是最优的，或者没有更好的）
     */
    public static int findBestToolSlot(class_746 player, class_2680 state) {
        ToolChoice best = bestTool(player, state);
        if (best == null) {
            return -1;
        }
        return best.slot() == player.method_31548().field_7545 ? -1 : best.slot();
    }

    /**
     * 手里的工具快用坏了 → 从背包里换一把更好的（附加功能，默认关闭）。
     *
     * <p>判据只有两条，都很保守：
     * <ol>
     *   <li>手上拿的确实是<b>有耐久的东西</b>（不是方块、不是空手）；</li>
     *   <li>它的剩余耐久已经低于 {@code thresholdPercent}% —— 也就是快见底了。</li>
     * </ol>
     * 满足之后，去背包里找<b>同一种物品</b>、而且剩余耐久<b>更多</b>的那一把换成主手。
     * 找不到就什么也不做 —— 绝不会用一把破的换掉你手上好的。
     *
     * <p>换手走的是 {@link #swapToHotbar}，也就是原版「按数字键换位」那条路，
     * 全程不打开任何界面。和新工具之间不留空窗：调用方应当在它返回 {@code true} 时
     * 跳过本 tick 的动作，下一 tick 再用新手继续。
     *
     * @param thresholdPercent 剩余耐久低于百分之几就该换（1~50）
     * @return 有没有真的换了手
     */
    public static boolean replaceWornTool(class_310 client, class_746 player,
                                          int thresholdPercent) {
        if (client == null || player == null) {
            return false;
        }
        class_1661 inventory = player.method_31548();
        int selected = inventory.field_7545;
        class_1799 held = inventory.method_5438(selected);
        if (held.method_7960() || held.method_7936() <= 0) {
            return false; // 手上不是工具，不掺和
        }
        int maxDamage = held.method_7936();
        int remaining = maxDamage - held.method_7919();
        int threshold = Math.max(1, maxDamage * thresholdPercent / 100);
        if (remaining > threshold) {
            return false; // 还够用
        }

        // 找同种物品里剩余耐久最多的那一把。基准是「手上这把」，所以只有确实更好才换
        int bestSlot = -1;
        int bestRemaining = remaining;
        for (int slot = 0; slot < INVENTORY_SLOTS; slot++) {
            if (slot == selected) {
                continue;
            }
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960() || stack.method_7936() <= 0 || !stack.method_31574(held.method_7909())) {
                continue;
            }
            int rest = stack.method_7936() - stack.method_7919();
            if (rest > bestRemaining) {
                bestRemaining = rest;
                bestSlot = slot;
            }
        }
        if (bestSlot < 0) {
            return false;
        }
        return swapToHotbar(client, player, bestSlot, selected);
    }

    /**
     * 快捷栏里「回饱食度最多」的那一格食物。
     *
     * <p>比的是 {@link class_4174#method_19230()}，也就是物品栏里显示的那半个鸡腿数，
     * <b>不是</b>饱和度。理由很实际：决定「能不能疾跑」的是饥饿值本身，
     * 所以一口气回最多的那个，才是最短时间内恢复赶路效率的选择。
     *
     * <p>并列时取靠前的槽位（第一个遇到的就是最好的），不会在两个一样的食物之间乱跳。
     *
     * @return 没有食物时返回 -1
     */
    public static int findBestFoodSlot(class_746 player) {
        if (player == null) {
            return -1;
        }
        class_1661 inventory = player.method_31548();
        int hotbar = class_1661.method_7368();
        int best = -1;
        int bestHunger = 0;

        for (int slot = 0; slot < hotbar; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960() || !stack.method_19267()) {
                continue;
            }
            class_4174 food = stack.method_7909().method_19264();
            if (food == null) {
                continue;
            }
            if (food.method_19230() > bestHunger) {
                bestHunger = food.method_19230();
                best = slot;
            }
        }
        return best;
    }

    /**
     * 快捷栏里能种出 {@code cropBlock} 这种作物的那一格。
     *
     * <p>做法是<b>反查</b>：找一个「放下去正好变成这种作物方块」的物品，
     * 也就是 {@code BlockItem.getBlock() == cropBlock}。不维护「小麦配小麦种子」
     * 这种对照表，好处是模组作物也能自动适配。
     *
     * <p>几个原版的例子可以印证这个判定是对的：
     * 小麦种子的 {@code getBlock()} 是小麦方块、胡萝卜物品对应胡萝卜方块、
     * 西瓜种子对应西瓜茎 —— 全是同一个方块实例，所以 {@code ==} 比得中。
     *
     * @return 没有种子时返回 -1
     */
    public static int findSeedSlot(class_746 player, class_2248 cropBlock) {
        return findSeedSlot(player, cropBlock, -1);
    }

    /**
     * 和上一个一样，但会<b>优先看某个快捷栏格</b>。
     *
     * <p>优先的那一格就是面板上的「默认种子槽位」：它只是一个偏好，不是强制 ——
     * 那一格没有该作物种子时，照样会把整个快捷栏扫一遍。
     *
     * @param preferredHotbar 想优先用的快捷栏格（0~8）；不关心就传 -1
     */
    public static int findSeedSlot(class_746 player, class_2248 cropBlock, int preferredHotbar) {
        if (player == null || cropBlock == null) {
            return -1;
        }
        class_1661 inventory = player.method_31548();
        int hotbar = class_1661.method_7368();

        if (preferredHotbar >= 0 && preferredHotbar < hotbar
                && matchesSeed(inventory.method_5438(preferredHotbar), cropBlock)) {
            return preferredHotbar;
        }
        for (int slot = 0; slot < hotbar; slot++) {
            if (matchesSeed(inventory.method_5438(slot), cropBlock)) {
                return slot;
            }
        }
        return -1;
    }

    /**
     * <b>深搜整个背包</b>（快捷栏 9 格 + 主背包 27 格）找这种作物的种子。
     *
     * <p>它是「快捷栏里没有种子」之后的第二道防线。顺序上先快捷栏、再主背包，
     * 所以顺手也能当「手边有没有」用。
     *
     * <p>为什么要单独有一个：原版放置只用主手，所以种子必须先进快捷栏。
     * 以前这里只找快捷栏，快捷栏用完就判「没种子」——哪怕背包里还躺着好几组，
     * 于是白白跑一趟补给点。现在先深搜一遍，找得到就把它换到手上继续种。
     *
     * @return 整个背包里都没有时返回 -1
     */
    public static int findSeedSlotDeep(class_746 player, class_2248 cropBlock) {
        if (player == null || cropBlock == null) {
            return -1;
        }
        class_1661 inventory = player.method_31548();
        for (int slot = 0; slot < INVENTORY_SLOTS; slot++) {
            if (matchesSeed(inventory.method_5438(slot), cropBlock)) {
                return slot;
            }
        }
        return -1;
    }

    /**
     * 把背包第 {@code invIndex} 格的物品<b>换到</b>快捷栏第 {@code hotbarIndex} 格。
     *
     * <p>走的是原版那条路：{@code clickSlot} + {@code SlotActionType.SWAP}，
     * 也就是真人「鼠标悬停在某格、按一下数字键 1~9」做的那件事。服务端收到的
     * 是一个普通的换位包，没有任何非常规之处。
     *
     * <p>用的是<b>玩家自己的物品栏</b>（{@code playerScreenHandler}），
     * 所以不需要打开任何界面 —— 收割途中正好也没有界面开着。如果这时候你
     * 已经打开了别的界面（背包、箱子），就<b>不动手</b>，免得点和你想的不是同一个容器。
     *
     * <p>注意它会「交换」：目标快捷栏格里原本的东西会被挪到 {@code invIndex} 那一格，
     * 不会凭空消失。
     *
     * @return 有没有真的发出这次交换
     */
    public static boolean swapToHotbar(class_310 client, class_746 player,
                                       int invIndex, int hotbarIndex) {
        if (client == null || client.field_1761 == null || player == null) {
            return false;
        }
        int hotbar = class_1661.method_7368();
        if (invIndex < 0 || invIndex >= INVENTORY_SLOTS
                || hotbarIndex < 0 || hotbarIndex >= hotbar) {
            return false;
        }
        if (invIndex == hotbarIndex) {
            return true;
        }
        // 只认「玩家自己的物品栏」：这时候 currentScreenHandler 必须是 PlayerScreenHandler
        class_1703 handler = player.field_7512;
        if (!(handler instanceof class_1723)) {
            return false;
        }
        int source = playerSlotId(handler, invIndex);
        if (source < 0) {
            return false;
        }
        client.field_1761.method_2906(handler.field_7763, source, hotbarIndex,
                class_1713.field_7791, player);
        return true;
    }

    /** 物品栏里第 {@code invIndex} 格，在某个界面处理器里对应的槽位号；找不到返回 -1 */
    public static int playerSlotId(class_1703 handler, int invIndex) {
        if (handler == null) {
            return -1;
        }
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871 instanceof class_1661 && slot.method_34266() == invIndex) {
                return slot.field_7874;
            }
        }
        return -1;
    }

    /** 这一栈是不是「放下去能长出 {@code cropBlock}」的东西 */
    private static boolean matchesSeed(class_1799 stack, class_2248 cropBlock) {
        return stack != null && !stack.method_7960()
                && stack.method_7909() instanceof class_1747 blockItem
                && blockItem.method_7711() == cropBlock;
    }

    /**
     * 「手边最值得拿去补种空耕地」的那一种作物。
     *
     * <p>和 {@link #findSeedSlot} 是配套的两个方向：那个是「已知要种小麦 → 找小麦种子」，
     * 这个是「不知道要种什么 → 挑一种出来」。用在空地补种上：空着的耕地没告诉你
     * 该长什么，只能从手边有的种子里选。
     *
     * <p>挑选顺序：
     * <ol>
     *   <li><b>玩家指定的作物</b>（面板上的「空地补种作物」）—— 手边正好有就用它；</li>
     *   <li>否则挑<b>数量最多</b>的那种 —— 最不容易种两下就断货。</li>
     * </ol>
     * 统计用的是<b>快捷栏 + 主背包</b>的总数（反正后面 {@code findSeed} 会负责把它
     * 换到快捷栏），但并列时按扫描顺序取先遇到的那个（走 {@link java.util.LinkedHashMap}），
     * 所以结果稳定，不会每 tick 换一种作物种。
     *
     * @param preferred 玩家指定的作物方块；没指定传 null
     * @return 该种的作物方块；手边一个能种的都没有时返回 null
     */
    public static class_2248 choosePlantCrop(class_746 player, class_2248 preferred) {
        if (player == null) {
            return null;
        }
        class_1661 inventory = player.method_31548();
        // LinkedHashMap：保留「背包里先遇到」的顺序，并列时结果才是确定的
        Map<class_2248, Integer> counts = new LinkedHashMap<>();
        for (int slot = 0; slot < INVENTORY_SLOTS; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (!isPlantable(stack)) {
                continue;
            }
            class_2248 crop = ((class_1747) stack.method_7909()).method_7711();
            counts.merge(crop, stack.method_7947(), Integer::sum);
        }
        if (counts.isEmpty()) {
            return null;
        }
        if (preferred != null && counts.containsKey(preferred)) {
            return preferred;
        }
        class_2248 best = null;
        int bestCount = 0;
        for (Map.Entry<class_2248, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > bestCount) {
                bestCount = entry.getValue();
                best = entry.getKey();
            }
        }
        return best;
    }

    /**
     * 这个物品放下去会不会长成作物 —— 也就是<b>它算不算补种用的东西</b>。
     *
     * <p>两种作物都算：
     * <ul>
     *   <li><b>真正的种子</b>（小麦种子、甜菜种子……）—— 只能种，不能吃；</li>
     *   <li><b>「非产生种子类农作物」</b>（胡萝卜、土豆）—— 收获物<b>本身就是</b>补种材料，
     *       既能吃又能种，没有单独的种子物品。</li>
     * </ul>
     * 这个区分在储存时很关键：交给 {@link ItemCategory} 去分档。
     */
    public static boolean isPlantable(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        return stack.method_7909() instanceof class_1747 blockItem
                && CropRegistry.isCropBlock(blockItem.method_7711());
    }

    /**
     * 往箱子里存东西时，这种物品<b>最多留几栈</b>。
     *
     * <p>返回值分三种：
     * <ul>
     *   <li><b>-1</b> —— 一栈都不存，全留身上；</li>
     *   <li><b>0</b> —— 全存；</li>
     *   <li><b>n</b> —— 留 n 栈，多的存。</li>
     * </ul>
     *
     * <p>具体哪一类是哪一种，由玩家在「存放策略」子面板里逐类设置
     * （{@link com.autofarm.client.config.AutoFarmConfig#keepFor}）；
     * 归类本身交给 {@link ItemCategory#classify}，判的是「能不能种 / 能不能吃 /
     * 是不是方块 / 有没有耐久」这些原版机制，所以模组作物也照样能落进对应的档。
     *
     * @param config 当前配置，里面存着七类各自的策略
     */
    public static int depositKeepBudget(class_1799 stack, AutoFarmConfig config) {
        ItemCategory category = ItemCategory.classify(stack);
        if (category == null || config == null) {
            return ItemCategory.KEEP_ALL;
        }
        return config.keepFor(category);
    }

    /**
     * 背包里还有没有「能存进箱子的东西」——一个都没有就别白跑一趟补给点了。
     *
     * <p>判定和真正的搬运用的是同一套（{@link #depositKeepBudget}）：
     * 胡萝卜、土豆这种要在「超过要留的组数」之后才算能存，所以只带着一组胡萝卜时
     * 这里会老老实实回答「没东西可存」，不会让它空跑。
     */
    public static boolean hasDepositableItems(class_746 player, AutoFarmConfig config) {
        if (player == null) {
            return false;
        }
        class_1661 inventory = player.method_31548();
        Map<class_1792, Integer> seen = new HashMap<>();
        // 先快捷栏后主背包：和实际搬运时的顺序一致，「留下的那几栈」才会留在手边
        for (int slot = 0; slot < INVENTORY_SLOTS; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }
            int budget = depositKeepBudget(stack, config);
            if (budget < 0) {
                continue;
            }
            int already = seen.getOrDefault(stack.method_7909(), 0);
            if (already >= budget) {
                return true;
            }
            seen.merge(stack.method_7909(), 1, Integer::sum);
        }
        return false;
    }

    /**
     * 背包里（快捷栏 + 主背包）一共有多少「能补种的东西」。
     *
     * <p>两个用法：
     * <ul>
     *   <li>指定 {@code cropBlock} 时只数这一种作物的种子 —— 也就是「这种菜还够种几次」，
     *       HUD 上显示的就是它，快见底时你会先看出来；</li>
     *   <li>{@code cropBlock} 为 null 时数所有能种的东西（手上没有具体作物目标时用）。</li>
     * </ul>
     *
     * <p>数的是<b>物品个数</b>而不是栈数：还够种 12 次比「还剩 1 栈」直观得多。
     */
    public static int countSeeds(class_746 player, class_2248 cropBlock) {
        if (player == null) {
            return 0;
        }
        class_1661 inventory = player.method_31548();
        int total = 0;
        for (int slot = 0; slot < INVENTORY_SLOTS; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }
            if (cropBlock != null ? matchesSeed(stack, cropBlock) : isPlantable(stack)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    /** 背包里还剩几个空格 */
    public static int countFreeSlots(class_746 player) {        if (player == null) {
            return 0;
        }
        class_1661 inventory = player.method_31548();
        int free = 0;
        for (int slot = 0; slot < INVENTORY_SLOTS; slot++) {
            if (inventory.method_5438(slot).method_7960()) {
                free++;
            }
        }
        return free;
    }

    /** 背包快满了（空格 ≤ {@code reserve}）——该去补给点存东西了 */
    public static boolean isNearlyFull(class_746 player, int reserve) {
        return countFreeSlots(player) <= reserve;
    }

    /**
     * 单个候选的评分：正确工具除数 30，否则 100
     */
    private static float score(float speed, boolean suitable) {
        return speed / (suitable ? 30.0f : 100.0f);
    }

    /**
     * 快捷栏里一共有多少个「能拿来垫脚的方块」。
     *
     * <p>寻路时用它当作「一路上最多能垫几块」的上限。
     */
    public static int countPlaceableInHotbar(class_746 player) {
        if (player == null) {
            return 0;
        }
        class_1661 inventory = player.method_31548();
        int hotbar = class_1661.method_7368();
        int total = 0;
        for (int slot = 0; slot < hotbar; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (isUsableAsFloor(stack)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    /**
     * 找快捷栏里第一个能用的方块槽位。
     *
     * <p>优先「手上正拿着的那一格」，这样如果玩家已经拿着石头，
     * 就不会莫名其妙把手里的东西换掉。
     *
     * @return 没有可用方块时返回 -1
     */
    public static int findPlaceableHotbarSlot(class_746 player) {
        if (player == null) {
            return -1;
        }
        class_1661 inventory = player.method_31548();
        int hotbar = class_1661.method_7368();

        int selected = inventory.field_7545;
        if (selected >= 0 && selected < hotbar && isUsableAsFloor(inventory.method_5438(selected))) {
            return selected;
        }
        for (int slot = 0; slot < hotbar; slot++) {
            if (isUsableAsFloor(inventory.method_5438(slot))) {
                return slot;
            }
        }
        return -1;
    }

    /**
     * 这个物品能不能拿来垫脚。
     *
     * <p>两个条件：得是个「放下去会变成方块」的物品，且那个方块要能踩得住
     * （有碰撞箱、不是水或岩浆）。用默认状态查碰撞箱，不维护白名单，
     * 模组方块也能自动适配。
     */
    private static boolean isUsableAsFloor(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (!(stack.method_7909() instanceof class_1747 blockItem)) {
            return false;
        }
        class_2680 state = blockItem.method_7711().method_9564();
        if (!state.method_26227().method_15769()) {
            return false;
        }
        class_2248 block = state.method_26204();
        if (block == net.minecraft.class_2246.field_10124) {
            return false;
        }
        // 空世界上下文足够判断「这个方块本身是不是实心的」，和放在哪里无关
        return state.method_26212(class_2682.field_12294, class_2338.field_10980);
    }
}
