package com.autofarm.client.path;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;

/**
 * 「这一格能不能站人」以及「这两点能不能直着走过去」的判断。
 *
 * <p>{@link PathFinder} 的 A* 要在一个「能走 / 不能走」的格子图上搜索，
 * 这一层就是那个图的地基：把 Minecraft 的方块世界翻译成布尔值。
 *
 * <h2>怎么判断一格能不能站</h2>
 * 不是看方块「是不是空气」——那样会把草、火把、地毯、半砖全判错。
 * 这里用的是<b>碰撞箱</b>：{@code getCollisionShape().isEmpty()}。
 * 凡是玩家能穿过去的（草、花、火把、水、告示牌……）碰撞箱都是空的，
 * 自动就算「能走」，不写白名单，模组方块也能自适应。
 *
 * <p>另外两个条件：
 * <ul>
 *   <li><b>头部那一格也要空</b>——玩家高 1.8 格，脚下空了头顶撞墙照样钻不过去；</li>
 *   <li><b>脚下必须有东西踩着</b>——否则 A* 会规划出「悬空行走」的路线，
 *       角色一走上去就直接掉下去。</li>
 * </ul>
 */
public final class BlockNavigator {

    /** 玩家碰撞箱高 1.8 格，站立时脚部 + 头部两格都要空出来 */
    private static final int BODY_HEIGHT = 2;

    /** 直线可达检查的采样步长（格）。够密，不会漏掉一格宽的柱子 */
    private static final double SAMPLE_STEP = 0.2;

    /**
     * 复用的临时坐标。
     *
     * <p>这些方法每秒会被调用几十万次（A* 展开节点时），每次都 new 一个
     * {@code BlockPos} 会给垃圾回收添不少麻烦，所以借一个可变对象周转。
     * 全部调用都发生在客户端主线程，不存在并发问题。
     */
    private static final class_2338.class_2339 CURSOR = new class_2338.class_2339();

    private BlockNavigator() {
    }

    // ================= 基本判定 =================

    /** 这一格对玩家来说「是空的」（没有碰撞箱） */
    public static boolean isPassableAt(class_1922 world, int x, int y, int z) {
        if (world == null) {
            return false;
        }
        if (y < world.method_31607() || y >= world.method_31600()) {
            return false;
        }
        // 未加载的区块一律当成「走不通」，否则会把 A* 引到一片虚空里
        if (world instanceof class_638 clientWorld
                && !clientWorld.method_8393(x >> 4, z >> 4)) {
            return false;
        }

        CURSOR.method_10103(x, y, z);
        class_2680 state = world.method_8320(CURSOR);
        if (state.method_26215()) {
            return true;
        }
        return state.method_26220(world, CURSOR).method_1110();
    }

    /** 脚站在 (x, y, z) 这一格上是否成立 */
    public static boolean canStand(class_1922 world, int x, int y, int z) {
        for (int i = 0; i < BODY_HEIGHT; i++) {
            if (!isPassableAt(world, x, y + i, z)) {
                return false;
            }
        }
        return !isPassableAt(world, x, y - 1, z);
    }

    public static boolean canStand(class_1922 world, class_2338 pos) {
        return pos != null && canStand(world, pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    // ================= 找落脚点 =================

    /**
     * 在 (x, z) 这一列上找离 {@code refY} 最近的、能站人的高度。
     *
     * <p>优先「同一层」，然后上下交替往外扩。这样在台阶旁边不会给出一个
     * 「明明要爬上去」的格子，路走起来才自然。
     *
     * @return 站不住的列返回 null
     */
    public static class_2338 findFloor(class_1922 world, int x, int z, int refY, int maxDown, int maxUp) {
        if (canStand(world, x, refY, z)) {
            return new class_2338(x, refY, z);
        }
        int limit = Math.max(maxDown, maxUp);
        for (int offset = 1; offset <= limit; offset++) {
            if (offset <= maxDown && canStand(world, x, refY - offset, z)) {
                return new class_2338(x, refY - offset, z);
            }
            if (offset <= maxUp && canStand(world, x, refY + offset, z)) {
                return new class_2338(x, refY + offset, z);
            }
        }
        return null;
    }

    // ================= 观察点 =================

    /** 水平方向的四个邻居，顺序决定了「优先站在哪一侧」 */
    private static final int[][] HORIZONTAL = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

    /**
     * 找一个「站在上面能看到 target」的落脚点。
     *
     * <p>为什么需要它：作物方块（小麦、胡萝卜、甘蔗……）的碰撞箱是空的，
     * 所以 {@link #canStand} 会认为<b>作物自己那一格就能站</b>——照直走的话，
     * 角色会走进作物里，脚和作物重叠。那样不但看着别扭，
     * 挖它的时候视角要垂直朝下，服务端看到的姿势非常不正常。
     *
     * <p>所以收割的目标不再是「作物那一格」，而是「站在旁边能看着它的一格」。
     * 优先级：同层四邻 → 上一层四邻 → 下一层四邻（甘蔗这类两格高的作物要站在下层）。
     * 优先选「视线不被挡住」的候选；实在都没有就退回第一个能站的，
     * 让它走近了再挖，总比放弃这一棵好。
     *
     * @return 旁边一格都站不住时返回 null
     */
    public static class_2338 findViewSpot(class_1922 world, class_2338 target) {
        if (world == null || target == null) {
            return null;
        }
        class_2338 fallback = null;
        for (int dy : new int[]{0, 1, -1}) {
            for (int[] direction : HORIZONTAL) {
                int x = target.method_10263() + direction[0];
                int y = target.method_10264() + dy;
                int z = target.method_10260() + direction[1];
                if (!canStand(world, x, y, z)) {
                    continue;
                }
                class_2338 candidate = new class_2338(x, y, z);
                if (fallback == null) {
                    fallback = candidate;
                }
                if (hasLineOfSight(world, candidate, target)) {
                    return candidate;
                }
            }
        }
        return fallback;
    }

    /**
     * 从 {@code from} 这一格的「眼睛高度」能不能看到 {@code target} 的中心。
     *
     * <p>沿直线采样，一旦采样点落进目标方块就认为通了（停在目标方块上，
     * 不再往后查）—— 这样「目标本身不是空气」也不会被误判成挡住。
     */
    public static boolean hasLineOfSight(class_1922 world, class_2338 from, class_2338 target) {
        if (world == null || from == null || target == null) {
            return false;
        }
        double ax = from.method_10263() + 0.5;
        double ay = from.method_10264() + 1.62;
        double az = from.method_10260() + 0.5;
        double bx = target.method_10263() + 0.5;
        double by = target.method_10264() + 0.5;
        double bz = target.method_10260() + 0.5;

        double dx = bx - ax;
        double dy = by - ay;
        double dz = bz - az;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = Math.max(1, (int) Math.ceil(distance / SAMPLE_STEP));

        for (int i = 1; i < steps; i++) {
            double t = (double) i / steps;
            int x = (int) Math.floor(ax + dx * t);
            int y = (int) Math.floor(ay + dy * t);
            int z = (int) Math.floor(az + dz * t);
            if (x == target.method_10263() && y == target.method_10264() && z == target.method_10260()) {
                return true;
            }
            if (!isPassableAt(world, x, y, z)) {
                return false;
            }
        }
        return true;
    }

    // ================= 直线可达 =================

    /**
     * 从 from 到 to 能不能「直着走过去」（一路上都有地方落脚）。
     *
     * <p>用密集采样近似：每 {@value #SAMPLE_STEP} 格采一个点，看落点附近
     * （本层或上下各一层）有没有能站的格子。
     *
     * <p>它比 A* 便宜一两个数量级，而「同一片农田里两点之间没有障碍」正是
     * 最常遇到的情况，所以先用它兜一道：它说能走就直着走，
     * 只有它说不行才去跑 A*。这一道挡掉了绝大部分寻路开销。
     */
    public static boolean hasStraightPath(class_1922 world, class_2338 from, class_2338 to) {
        double ax = from.method_10263() + 0.5;
        double az = from.method_10260() + 0.5;
        double bx = to.method_10263() + 0.5;
        double bz = to.method_10260() + 0.5;
        double distance = Math.sqrt((bx - ax) * (bx - ax) + (bz - az) * (bz - az));
        int steps = Math.max(1, (int) Math.ceil(distance / SAMPLE_STEP));

        for (int i = 1; i < steps; i++) {
            double t = (double) i / steps;
            int x = (int) Math.floor(ax + (bx - ax) * t);
            int z = (int) Math.floor(az + (bz - az) * t);
            double y = from.method_10264() + (to.method_10264() - (double) from.method_10264()) * t;
            int rounded = (int) Math.round(y);

            // 本层优先，不行再看上下各一层：直线插值出来的高度不一定正好落在台阶上
            boolean ok = false;
            for (int dy = 0; dy <= 1 && !ok; dy++) {
                ok = canStand(world, x, rounded + dy, z)
                        || canStand(world, x, rounded - dy, z);
            }
            if (!ok) {
                return false;
            }
        }
        return true;
    }
}
