package com.autofarm.client.gui;

import java.util.function.IntSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

/**
 * 一个画着「调色板」的小方块按钮，点它进入高亮样式的次级面板。
 *
 * <p>图标可以用代码画出来，不需要额外的贴图资源。
 * 板身用<b>当前的描边颜色</b>填充，所以不用打开面板也能一眼看出现在选的是什么色。
 */
public class PaletteIconButton extends class_4185 {

    /** 画几像素的方块。设计上是 10×10，外面留 4 像素的边距 */
    private static final int ICON = 10;

    /** 每次画的时候现取，这样草稿一改图标就跟着变 */
    private final IntSupplier colorSupplier;

    public PaletteIconButton(int x, int y, int size, IntSupplier colorSupplier, class_4241 onPress) {
        super(x, y, size, size, class_2561.method_43473(), onPress, field_40754);
        this.colorSupplier = colorSupplier;
        method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.highlight.customize")));
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        // 先让超类把原版按钮底板画出来，保证和旁边按钮风格一致
        super.method_48579(context, mouseX, mouseY, delta);

        int ix = method_46426() + (method_25368() - ICON) / 2;
        int iy = method_46427() + (method_25364() - ICON) / 2;

        // 板身 = 当前描边色
        context.method_25294(ix, iy, ix + ICON, iy + ICON, 0xFF101010);
        context.method_25294(ix + 1, iy + 1, ix + ICON - 1, iy + ICON - 1, 0xFF000000 | (colorSupplier.getAsInt() & 0xFFFFFF));

        // 四个颜料点，让人一眼认出这是调色板而不是普通色块
        context.method_25294(ix + 2, iy + 2, ix + 4, iy + 4, 0xFFFFFFFF);
        context.method_25294(ix + 6, iy + 2, ix + 8, iy + 4, 0xFF303030);
        context.method_25294(ix + 2, iy + 6, ix + 4, iy + 8, 0xFF303030);
        context.method_25294(ix + 6, iy + 6, ix + 8, iy + 8, 0xFFFFFFFF);
    }
}
