package com.autofarm.client.render;

import com.autofarm.client.config.AutoFarmConfig;
import com.autofarm.client.config.ConfigManager;
import com.autofarm.client.harvest.CropHarvester;
import com.autofarm.client.task.FarmTaskManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.ArrayList;
import java.util.List;

/**
 * 左上角那行常驻状态（HUD）。
 *
 * <h2>为什么需要它</h2>
 * 在这之前，「它现在在干嘛、收了多少、种子还够不够、为什么突然停了」这些信息
 * <b>只有打开控制面板才看得到</b> —— 而收割的时候你最不想做的恰好就是开界面。
 * 结果就是：它明明在正常干活，你却总想按一下快捷键确认一下；它一旦停机，
 * 你要么开面板、要么一脸问号。
 *
 * <h2>显示什么</h2>
 * <ul>
 *   <li><b>状态</b>：直接复用 {@link FarmTaskManager#getState()}，和面板里那一行同源；</li>
 *   <li><b>已收 / 种子</b>：这一轮收了多少个、手边还有多少能补种的东西
 *       （种子快见底时数字会变暖色，你会先一步看出来）；</li>
 *   <li><b>提示</b>：有异常才出现这第三行 —— 背包满、缺种子、安全停机都在这儿说，
 *       而不用开面板。</li>
 * </ul>
 *
 * <p>它是纯渲染、只读别人的状态，不参与任何决策；关掉开关
 * （{@link AutoFarmConfig#showHud}）就整块不画。
 */
public final class AutoFarmHud {

    private static final int X = 4;
    private static final int Y = 4;
    /** 行高：比字体高度多一点，读起来不挤 */
    private static final int LINE_HEIGHT = 10;
    private static final int PAD = 2;

    private static final int COLOR_TEXT = 0xFFE8E8E8;
    private static final int COLOR_HINT = 0xFFA0A0A0;
    private static final int COLOR_NOTICE = 0xFFFFC46B;
    private static final int COLOR_OFF = 0xFF808080;
    /** 半透明黑底：白字在任何地形上都看得清 */
    private static final int BACKGROUND = 0x66000000;

    /** 种子少于这个数就变暖色提醒 */
    private static final int SEED_WARN = 8;

    private AutoFarmHud() {
    }

    public static void register() {
        HudRenderCallback.EVENT.register(AutoFarmHud::render);
    }

    private static void render(class_332 context, float tickDelta) {
        class_310 client = class_310.method_1551();
        AutoFarmConfig config = ConfigManager.get();
        if (!config.showHud || client == null || client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        // 开着界面时原版本来就不画 HUD，这里也一起让路；F3 调试界面同理，
        // 不然两堆字会叠在一起
        if (client.field_1755 != null || client.field_1690.field_1842 || client.field_1690.field_1866) {
            return;
        }

        List<Line> lines = new ArrayList<>();
        if (!config.enabled) {
            // 关着的时候只留一行很淡的字，提示它还在、以及怎么开
            lines.add(new Line(class_2561.method_43471("autofarm.hud.off"), COLOR_OFF));
            draw(context, client, lines);
            return;
        }

        lines.add(new Line(class_2561.method_43469("autofarm.hud.title",
                class_2561.method_43471(FarmTaskManager.getState().getTranslationKey())), COLOR_TEXT));

        int seeds = FarmTaskManager.getSeedCount();
        // 只有「确实在靠种子补种」时才把种子少当成警告：
        // 收甜浆果这类不用种的东西时，种子数恒为 0，一直亮着暖色反而变成噪音
        boolean seedsMatter = CropHarvester.getCropBlock() != null;
        lines.add(new Line(class_2561.method_43469("autofarm.hud.stats",
                FarmTaskManager.getHarvestedCount(), seeds),
                seedsMatter && seeds <= SEED_WARN ? COLOR_NOTICE : COLOR_HINT));

        String notice = FarmTaskManager.getHarvestNotice();
        if (notice != null) {
            lines.add(new Line(class_2561.method_43471(notice), COLOR_NOTICE));
        }

        draw(context, client, lines);
    }

    private static void draw(class_332 context, class_310 client, List<Line> lines) {
        int width = 0;
        for (Line line : lines) {
            width = Math.max(width, client.field_1772.method_27525(line.text()));
        }
        int height = lines.size() * LINE_HEIGHT;

        context.method_25294(X - PAD, Y - PAD, X + width + PAD, Y + height + PAD, BACKGROUND);

        int y = Y;
        for (Line line : lines) {
            context.method_27535(client.field_1772, line.text(), X, y, line.color());
            y += LINE_HEIGHT;
        }
    }

    /** 一行字 + 它的颜色 */
    private record Line(class_2561 text, int color) {
    }
}
