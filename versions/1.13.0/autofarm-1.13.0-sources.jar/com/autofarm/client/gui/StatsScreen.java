package com.autofarm.client.gui;

import com.autofarm.client.stats.StatsManager;
import com.autofarm.client.task.FarmTaskManager;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * 统计面板（E 组）：把「本轮」和「累计」两套数字摆在一起看。
 *
 * <h2>和 HUD 的关系</h2>
 * HUD 是干活时瞄一眼用的，只给三两个数；这里是一张完整的表，包括累计统计
 * （重进游戏还在）和异常次数。没事的时候不用开它，事后想看看「这一局到底收了多少、
 * 总共干了几小时、出过多少次岔子」，来这儿一趟就清楚了。
 *
 * <h2>数据来源</h2>
 * <ul>
 *   <li><b>本轮</b> —— {@link FarmTaskManager} 的收割数 / 补种数 / 干活时长，关一次开关清零；</li>
 *   <li><b>累计</b> —— {@link StatsManager} 持久化到 {@code config/autofarm-stats.json}，
 *       重进游戏还在；</li>
 *   <li><b>异常</b> —— {@link StatsManager} 记进 {@code config/autofarm.log} 的条数。</li>
 * </ul>
 *
 * <p>底部两个操作：<b>清零累计</b>、<b>清空日志</b>。都是「把账本翻回第一页」——
 * 不影响模组行为，只影响这里显示的数字。
 */
public class StatsScreen extends class_437 {

    private static final int PANEL_W = 320;
    private static final int PAD = 12;
    private static final int BTN_H = 20;
    private static final int LINE_H = 11;
    /** 两个小节（本轮 / 累计）各自的行数 */
    private static final int SESSION_ROWS = 3;
    private static final int TOTAL_ROWS = 7;

    private static final int COLOR_PANEL = 0xF0181818;
    private static final int COLOR_EDGE = 0xFF6A6A6A;
    private static final int COLOR_TITLE = 0xFFFFFFFF;
    private static final int COLOR_HEAD = 0xFFFFC46B;
    private static final int COLOR_LABEL = 0xFFA0A0A0;
    private static final int COLOR_VALUE = 0xFFE0E0E0;

    private final class_437 parent;

    private int left;
    private int top;
    private int panelW;
    private int panelH;

    public StatsScreen(class_437 parent) {
        super(class_2561.method_43471("autofarm.stats.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.panelW = Math.min(PANEL_W, Math.max(220, this.field_22789 - 20));

        // 标题 + 两个小节标题 + (3 + 7) 行数据 + 节间留白 + 按钮
        int rows = 1 + 1 + SESSION_ROWS + 1 + TOTAL_ROWS;
        this.panelH = PAD + 14 + rows * LINE_H + 8 + BTN_H + PAD;
        this.left = (this.field_22789 - panelW) / 2;
        this.top = Math.max(4, (this.field_22790 - panelH) / 2);

        int btnY = top + panelH - PAD - BTN_H;
        int third = (panelW - PAD * 2 - 12) / 3;
        method_37063(class_4185.method_46430(class_2561.method_43471("autofarm.stats.clear"),
                        b -> StatsManager.get().clear())
                .method_46434(left + PAD, btnY, third, BTN_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("autofarm.stats.clear_log"),
                        b -> StatsManager.get().clearLog())
                .method_46434(left + PAD + third + 6, btnY, third, BTN_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("autofarm.stats.done"), b -> method_25419())
                .method_46434(left + PAD + 2 * (third + 6), btnY, third, BTN_H).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);

        context.method_25294(left, top, left + panelW, top + panelH, COLOR_PANEL);
        drawRectOutline(context, left, top, left + panelW, top + panelH, COLOR_EDGE);

        context.method_27534(this.field_22793, this.field_22785,
                left + panelW / 2, top + PAD, COLOR_TITLE);

        int y = top + PAD + 14;
        int valueX = left + PAD + 120;

        y += LINE_H; // 空一行，标题下方留白
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.stats.session").method_27692(class_124.field_1067),
                left + PAD, y, COLOR_HEAD);
        y += LINE_H;
        y = row(context, y, valueX, "autofarm.stats.harvested",
                FarmTaskManager.getHarvestedCount());
        y = row(context, y, valueX, "autofarm.stats.planted",
                FarmTaskManager.getPlantedCount());
        y = row(context, y, valueX, "autofarm.stats.work_time",
                duration(FarmTaskManager.getSessionSeconds()));

        y += LINE_H; // 两个小节之间留白
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.stats.total").method_27692(class_124.field_1067),
                left + PAD, y, COLOR_HEAD);
        y += LINE_H;
        StatsManager s = StatsManager.get();
        y = row(context, y, valueX, "autofarm.stats.harvested", s.getTotalHarvested());
        y = row(context, y, valueX, "autofarm.stats.planted", s.getTotalPlanted());
        y = row(context, y, valueX, "autofarm.stats.picked_up", s.getTotalPickedUp());
        y = row(context, y, valueX, "autofarm.stats.bone_meal", s.getTotalBoneMeal());
        y = row(context, y, valueX, "autofarm.stats.supply_runs", s.getTotalSupplyRuns());
        y = row(context, y, valueX, "autofarm.stats.work_time", duration((int) s.getTotalWorkSeconds()));
        row(context, y, valueX, "autofarm.stats.issues", s.getIssueCount());

        super.method_25394(context, mouseX, mouseY, delta);
    }

    /** 画一行「标签 …… 值」，返回下一行的 y */
    private int row(class_332 context, int y, int valueX, String labelKey, long value) {
        return drawRow(context, y, valueX, labelKey, class_2561.method_43470(Long.toString(value)));
    }

    /** 值本身已经是文本（时长这类带单位的），走这个重载 */
    private int row(class_332 context, int y, int valueX, String labelKey, String value) {
        return drawRow(context, y, valueX, labelKey, class_2561.method_43470(value));
    }

    private int drawRow(class_332 context, int y, int valueX, String labelKey, class_2561 value) {
        context.method_27535(this.field_22793, class_2561.method_43471(labelKey),
                left + PAD + 4, y, COLOR_LABEL);
        context.method_27535(this.field_22793, value, valueX, y, COLOR_VALUE);
        return y + LINE_H;
    }

    /** 秒数 → 「1h23m」「2m5s」「45s」这样的短格式 */
    private static String duration(int seconds) {
        if (seconds < 60) {
            return seconds + "s";
        }
        if (seconds < 3600) {
            return (seconds / 60) + "m" + (seconds % 60) + "s";
        }
        return (seconds / 3600) + "h" + (seconds % 3600 / 60) + "m";
    }

    /** 画一圈 1 像素的描边（DrawContext 没有现成的描边 API，用四条填充拼） */
    private static void drawRectOutline(class_332 context, int x1, int y1, int x2, int y2, int color) {
        context.method_25294(x1, y1, x2, y1 + 1, color);
        context.method_25294(x1, y2 - 1, x2, y2, color);
        context.method_25294(x1, y1 + 1, x1 + 1, y2 - 1, color);
        context.method_25294(x2 - 1, y1 + 1, x2, y2 - 1, color);
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }
}
