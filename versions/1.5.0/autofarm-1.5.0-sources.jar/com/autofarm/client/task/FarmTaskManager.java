package com.autofarm.client.task;

import com.autofarm.client.combat.KillAura;
import com.autofarm.client.compat.CameraCompat;
import com.autofarm.client.config.AutoFarmConfig;
import com.autofarm.client.config.ConfigManager;
import com.autofarm.client.container.ContainerCompat;
import com.autofarm.client.container.ContainerTransfer;
import com.autofarm.client.harvest.CropHarvester;
import com.autofarm.client.human.Humanizer;
import com.autofarm.client.human.IdleLook;
import com.autofarm.client.interact.BlockInteractor;
import com.autofarm.client.inventory.AutoEater;
import com.autofarm.client.inventory.InventoryScanner;
import com.autofarm.client.path.BlockNavigator;
import com.autofarm.client.path.PathPlanner;
import com.autofarm.client.path.PathStep;
import com.autofarm.client.path.PathWalker;
import com.autofarm.client.scan.CropFilter;
import com.autofarm.client.scan.CropRegistry;
import com.autofarm.client.scan.CropScanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1308;
import net.minecraft.class_1542;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * 自动收割任务的大脑。
 *
 * <h2>它管两条完全不同的节奏</h2>
 * <ul>
 *   <li><b>每 tick</b>：驱动角色往前走、走到作物跟前就挖掉再补种；</li>
 *   <li><b>每隔一段时间</b>：重新扫描周围，看还有哪些成熟作物没去过；
 *       手上没有路线在跑、而又有新目标时，规划一条新路线（{@link PathPlanner}）。</li>
 * </ul>
 *
 * <p>为什么非要等「手上路线走完」再重新规划：边走边重排的话，
 * 角色会因为每秒钟都在改主意而走成锯齿。走完一轮再重新看，路线才稳定。
 *
 * <h2>优先级链</h2>
 * <p>同一 tick 里可能同时有好几件事想做，所以定了严格的先后顺序 ——
 * <b>先保证角色能正常行动，再谈干活</b>：
 * <ol>
 *   <li><b>吃</b>（{@link AutoEater}）：饿到跑不动就先吃。走不动的话，
 *       去下一棵作物的时间要翻倍，所以它排在最前面，期间走路和收割都让路；</li>
 *   <li><b>补给 / 走 / 收</b>（{@link ContainerTransfer} + {@link PathWalker} +
 *       {@link CropHarvester}）：沿路线移动，到站就挖掉 + 补种。
 *       背包快满时会中断路线先去补给点存一趟（作物不会丢，下一轮还会扫到）；</li>
 *   <li><b>扫描 / 规划</b>：只有前两件事都不占着人（没在走、也没在收、没在补给）
 *       才会重新排路线。缺种子和背包满都会在这时候转成一次补给点往返。</li>
 * </ol>
 * 换句话说：<b>疾跑和进食 > 走路 > 收割 > 规划</b>。
 */
public final class FarmTaskManager {

    /**
     * 开着「穿透显示」时的扫描间隔下限（tick）。
     *
     * <p>透视模式下每一帧要额外画一堆穿过方块的描边，绘制压力明显更大，
     * 所以这里自动把扫描往后压一压，等于给它配了个更长的冷却时间。
     * 玩家自己设的间隔比这个还大时，以玩家设的为准。
     */
    private static final int THROUGH_WALLS_MIN_INTERVAL = 40;

    /** 背包空格少于等于这个数就算「快满了」，该去补给点存一趟 */
    private static final int INVENTORY_RESERVE = 1;

    /**
     * 走到掉落物所在格之后，原地停留几 tick 再放行。
     *
     * <p>「站上去」和「东西进背包」之间隔着原版的拾取判定，不是同一 tick 完成的。
     * 停这一小会儿，等它真的被吸走了再走开，否则会出现「明明去过、东西还在地上」。
     */
    private static final int PICKUP_WAIT_TICKS = 6;

    /** 掉落物离玩家近到这种程度（格）就当「抬脚就捡到了」，不再专门排进路线 */
    private static final double PICKUP_IGNORE_DISTANCE = 1.6;

    /**
     * 一趟补给「没办成」之后的冷却（tick）。
     *
     * <p>没办成包括：走不到、箱子打不开、箱子已经满了搬不动、箱子里没有要的种子。
     * 这几种情况如果不冷静一下，下一 tick 的条件依然成立，
     * 它就会「立刻再跑一趟」——变成在两个点之间来回横跳。
     */
    private static final int SUPPLY_RETRY_COOLDOWN_TICKS = 400;

    private static FarmState state = FarmState.IDLE;
    private static List<class_2338> matureCrops = Collections.emptyList();

    /**
     * 附近「空着的耕地」——上面是空气、下面是耕地的那种格子。
     *
     * <p>只有「补种空耕地」开关开着、而且自动收割也开着的时候才有内容
     * （关着时是空表，连扫都不扫）。它们和成熟作物走同一条路线、同一个执行器，
     * 区别只在到了之后干什么：那边是挖，这边是种（见 {@code CropHarvester.start}）。
     */
    private static List<class_2338> emptyFarmland = Collections.emptyList();

    private static long lastScanTick = Long.MIN_VALUE;

    /**
     * 上一 tick 看到的「自动收割」开关状态。
     *
     * <p>用它来抓「关 → 开」这个边沿：只要玩家把开关重新打开（不管是按快捷键，
     * 还是在面板里点），就清空「已处理」记忆并强制立刻重扫一次。
     * 这正是快捷键存在的意义 —— <b>让那些还没被挖掉的成熟作物重新被认出来</b>。
     */
    private static boolean lastEnabled = false;

    /**
     * 本轮已经处理过的目标（走到了、或者判定过不去放弃了）。
     *
     * <p>这个集合每轮扫描会跟当前扫描结果求交集自动瘦身：
     * 真被挖掉的、或者玩家走远后扫不到的，都会自己离开集合。
     */
    private static final Set<class_2338> handled = new HashSet<>();

    // ================= 补给点往返 =================

    /** 补给点往返走到哪一步了 */
    private enum SupplyPhase {
        /** 没在往返 */
        NONE,
        /** 正在走去补给点 */
        GOING,
        /** 人到了，正在开箱存取 */
        TRANSFERRING
    }

    private static SupplyPhase supplyPhase = SupplyPhase.NONE;
    /** 这一趟要不要存东西 */
    private static boolean supplyDeposit;
    /** 这一趟要不要取种子 */
    private static boolean supplyRefill;

    /**
     * 这一趟实际要去的容器方块。
     *
     * <p>为什么不直接用配置里的补给点坐标：面板上「记录当前位置」记的是<b>玩家脚下那一格</b>，
     * 站着记录、蹲在箱子上面记录都会偏一格。所以出发时会在补给点附近认一下
     * （见 {@link ContainerCompat#findContainer}），把真正的那口箱子记在这儿，
     * 后面开箱、走路、够不够得着全都用它。
     */
    private static class_2338 supplyContainer;

    /**
     * 「缺种子」这件事还悬着 —— 走完手上这条路线就去补给点。
     *
     * <p>不在收割当场掉头，是为了不把一条已经规划好的路线打断：
     * 剩下的几棵作物照收，收完再去补货，然后重新扫一遍继续。
     */
    private static boolean refillWanted;

    /** 具体缺哪些作物的种子（补给点只取这些，不乱搬别的东西） */
    private static final Set<class_2248> missingSeeds = new HashSet<>();

    /** 补给点相关的一句话结果，显示在面板状态区 */
    private static String supplyNotice;

    /** 上一趟补给没办成时留下的冷静期，倒计时到 0 之前不再去 */
    private static int supplyCooldown;

    // ================= 统计与播报 =================

    /**
     * 这一轮（从上次打开开关算起）收了几个。
     *
     * <p>只给 HUD 和面板看：没有它你根本不知道它到底干了多少活，
     * 只能靠盯着世界里的方块变化猜。
     */
    private static int harvestedCount;

    /** 这一轮往空耕地上种了几格（只有开了「补种空耕地」才可能不为 0） */
    private static int plantedCount;

    /** 上一次用 actionbar 播报过的「停机原因」，用来防止同一个原因反复刷屏 */
    private static String lastPauseAnnounce;

    /** 上一次播报过的「事件类」提示（补给结果、种子用完） */
    private static String lastEventAnnounce;

    // ================= 附加功能运行时状态 =================
    // 下面这几项只在「附加功能」面板里对应的开关打开时才会被读写；
    // 全关的时候它们保持不动，等于不存在。

    /**
     * 「失败目标暂时拉黑」：位置 → 解禁时刻（{@code world.getTime()}）。
     *
     * <p>失败的目标本来会被塞进 {@link #handled} 永久跳过；开了这个功能之后，
     * 它改记在定时器里，到点自动重新排进路线。
     */
    private static final Map<class_2338, Long> failedUntil = new HashMap<>();

    /**
     * 「优先拾取掉落物」：这一轮扫描认出来的、掉在地上还没进包的作物掉落物（记的是所在格）。
     *
     * <p>它和 {@link #matureCrops} 一样是「本轮的目标」，但走的是完全不同的处理：
     * 到了那一格不用挖也不用种，站上去等原版把东西吸进背包就行。
     * 关掉这个附加功能时它恒为空表，等于不存在。
     */
    private static final Set<class_2338> pickupTargets = new HashSet<>();

    /** 正在掉落物格上等拾取时的倒计时；换目标时重新计时 */
    private static int pickupWaitTicks;

    /** 正在等待拾取的那一格（换目标时用来重置上面的倒计时） */
    private static class_2338 pickupWaitPos;

    /**
     * 防踢模式：已经「打量过」的目标。
     *
     * <p>犹豫只在<b>第一次</b>站到某一棵跟前时发生一次 —— 靠它把「同一个目标反复犹豫」
     * 挡掉，否则这个目标会被无限期地拖下去，永远轮不到动手。
     */
    private static class_2338 hesitatedAt;

    /** 拟人化节奏的停顿倒计时（tick）：>0 时先愣一下，不动手也不推进路线 */
    private static int humanizeDelay;

    /** 随机休息的剩余时长（tick）：>0 表示正在休息 */
    private static int restRemaining;

    /** 距离下一次休息已经连续工作了多少 tick */
    private static int workTicks;

    /** 本轮（从打开开关算起）真正干了活的 tick 数，给 HUD 详细统计用 */
    private static int sessionTicks;

    /**
     * 「危险反应延迟」的计时状态。
     *
     * <p>危险第一次出现时记下它的类型（{@link #pendingSafety}）并开始数 tick，
     * 数够 {@link AutoFarmConfig#reactionDelayTicks} 才真正停手。
     * 危险消失、或者换了一种危险，都重新计时。
     */
    private static String pendingSafety;
    private static int safetySeenTicks;

    // ================= 工作范围与作息（B 组）=================

    /**
     * 圈定工作区域：本轮回程路线的目标格。
     *
     * <p>回程走的是 {@link PathWalker} 的同一条通道，但它不是「作物目标」——
     * 走到之后不该挖也不该种，所以单独记一笔，用来在到站时把人放行。
     */
    private static class_2338 areaReturnTarget;

    /** 这一轮越界之后是否已经排过一次回程路线（排过还回不去就不再反复重排） */
    private static boolean areaReturnTried;

    /** 当前是否处在「越界返回」模式（用来抓进出边沿、复位上面两项） */
    private static boolean areaReturning;

    /** 疲劳收工：连续干活累计了多少 tick */
    private static int fatigueWorkTicks;

    /** 疲劳收工后的休息倒计时（tick）；>0 表示还在休息 */
    private static int fatigueRestRemaining;

    /** 疲劳「手动恢复」模式下已经收工、正等着玩家自己重开 */
    private static boolean fatigueStopped;

    private FarmTaskManager() {
    }

    public static FarmState getState() {
        return state;
    }

    public static int getMatureCount() {
        return matureCrops.size();
    }

    public static List<class_2338> getMatureCrops() {
        return matureCrops;
    }

    /** 附近空着的耕地（补种目标）。渲染层拿它画另一种颜色的框 */
    public static List<class_2338> getFarmlandTargets() {
        return emptyFarmland;
    }

    /** 附近空耕地的格数（面板上显示，好知道它为什么要往空地跑） */
    public static int getFarmlandCount() {
        return emptyFarmland.size();
    }

    /**
     * 当前实际生效的扫描间隔（tick）。
     *
     * <p>面板上的滑块是玩家的设定值；这里再叠一层「透视模式自动降频」，
     * 免得玩家把间隔拉到最小、又开着穿透显示，结果每帧都在刷上万格。
     */
    public static int getEffectiveScanInterval() {
        AutoFarmConfig config = ConfigManager.get();
        int configured = Math.max(2, config.scanIntervalTicks);
        return config.highlightThroughWalls
                ? Math.max(configured, THROUGH_WALLS_MIN_INTERVAL)
                : configured;
    }

    // ================= 路线信息（给面板和渲染层用） =================

    /** 角色是不是正在按路线行走 */
    public static boolean isWalking() {
        return PathWalker.isActive();
    }

    /** 当前路线上还剩多少个没到的目标 */
    public static int getRouteRemaining() {
        return PathWalker.isActive() ? PathWalker.getTotalCount() - PathWalker.getDoneCount() : 0;
    }

    /** 当前路线的目标总数 */
    public static int getRouteTotal() {
        return PathWalker.getTotalCount();
    }

    /** 从当前位置起还要走多远（格） */
    public static double getRemainingDistance() {
        return PathWalker.getRemainingDistance();
    }

    /** 还没走到的作物目标，按访问顺序。它给的是「要去哪」，不是「怎么走」 */
    public static List<class_2338> getRoute() {
        return PathWalker.getRoute();
    }

    /**
     * 当前这一段 A* 算出来的实际行走路径。
     *
     * <p>和 {@link #getRoute()} 的区别：route 是「依次要去哪些作物」的战略顺序，
     * segment 是「接下来这几步具体踩哪几个格子」的战术路线 —— 而且还带着
     * 「这一步要先挖 / 要先垫」的标记。渲染层把它画成实线。
     */
    public static List<PathStep> getActiveSegment() {
        return PathWalker.getSegment();
    }

    /** 快捷栏里能拿来垫脚的方块总数。面板上显示出来，好让玩家知道垫不垫得动 */
    public static int getHotbarBlockCount() {
        class_310 client = class_310.method_1551();
        return client == null || client.field_1724 == null
                ? 0
                : InventoryScanner.countPlaceableInHotbar(client.field_1724);
    }

    /** 这一轮已经收了多少个（HUD 用） */
    public static int getHarvestedCount() {
        return harvestedCount;
    }

    /** 这一轮往空耕地上种了多少格 */
    public static int getPlantedCount() {
        return plantedCount;
    }

    /**
     * 这一轮实际干了多少秒（「HUD 详细统计」用）。
     *
     * <p>统计的是<b>干活的时间</b>：暂停（背包满、危险、休息、开着界面）的 tick 不算，
     * 所以它反映的是真实作业时长，而不是「从打开开关到现在过了多久」。
     */
    public static int getSessionSeconds() {
        return sessionTicks / 20;
    }

    /**
     * 手边还有多少「能补种的东西」（HUD 用）。
     *
     * <p>有明确的作物目标时只数那一种作物的种子 —— 你要看的正是「这种菜还够种几次」；
     * 还没收过东西时就数背包里所有能种的东西。
     */
    public static int getSeedCount() {
        class_310 client = class_310.method_1551();
        return client == null || client.field_1724 == null
                ? 0
                : InventoryScanner.countSeeds(client.field_1724, CropHarvester.getCropBlock());
    }

    /** 玩家退出世界时清空现场 */
    public static void reset() {
        state = FarmState.IDLE;
        matureCrops = Collections.emptyList();
        emptyFarmland = Collections.emptyList();
        lastScanTick = Long.MIN_VALUE;
        lastEnabled = false;
        handled.clear();
        PathWalker.stop();
        CropHarvester.reset();
        AutoEater.reset();
        BlockInteractor.clearDriving();
        ContainerTransfer.reset();
        supplyPhase = SupplyPhase.NONE;
        supplyDeposit = false;
        supplyRefill = false;
        refillWanted = false;
        missingSeeds.clear();
        supplyNotice = null;
        supplyCooldown = 0;
        supplyContainer = null;
        harvestedCount = 0;
        plantedCount = 0;
        lastPauseAnnounce = null;
        lastEventAnnounce = null;
        // 附加功能的运行时状态也一并归零
        failedUntil.clear();
        humanizeDelay = 0;
        restRemaining = 0;
        workTicks = 0;
        sessionTicks = 0;
        pickupTargets.clear();
        pickupWaitTicks = 0;
        pickupWaitPos = null;
        hesitatedAt = null;
        pendingSafety = null;
        safetySeenTicks = 0;
        areaReturnTarget = null;
        areaReturnTried = false;
        areaReturning = false;
        fatigueWorkTicks = 0;
        fatigueRestRemaining = 0;
        fatigueStopped = false;
        Humanizer.reset();
        IdleLook.reset();
        KillAura.reset();
    }

    /**
     * 面板状态区那一行提示：优先显示补给点的结果，其次是上一棵作物的收割结果。
     *
     * <p>「没种子」「挖不动」「补给点到不了」这类跳过原因都走这里，
     * 不然你只会看到它绕开某一棵却不知道为什么。
     */
    public static String getHarvestNotice() {
        return supplyNotice != null ? supplyNotice : CropHarvester.getNotice();
    }

    /**
     * 一键开/关自动收割（快捷键调用）。
     *
     * <p>它做的不只是翻开关，还顺手做了一次「重新认一遍」：清空「已处理」记忆、
     * 把扫描时间戳归零，让下一个 tick 立刻重新扫一遍周围。
     * 所以当你发现某个成熟作物它死活不去挖时，按一下这个键（关掉再按一下打开）
     * 就能让它从头再认一次，不用重进世界。
     */
    public static void toggleEnabled(class_310 client) {
        AutoFarmConfig config = ConfigManager.get();
        config.enabled = !config.enabled;

        // 关掉 → 立刻停手，把控制权还给你
        if (!config.enabled) {
            PathWalker.stop();
            CropHarvester.reset();
            ContainerTransfer.reset();
            handled.clear();
            supplyPhase = SupplyPhase.NONE;
            supplyDeposit = false;
            supplyRefill = false;
            refillWanted = false;
            missingSeeds.clear();
            supplyContainer = null;
            failedUntil.clear();
            humanizeDelay = 0;
            restRemaining = 0;
            pickupTargets.clear();
            pickupWaitTicks = 0;
            pickupWaitPos = null;
            hesitatedAt = null;
            pendingSafety = null;
            safetySeenTicks = 0;
            Humanizer.reset();
            IdleLook.reset();
            KillAura.reset();
            state = FarmState.IDLE;
        } else {
            // 打开 → 假装「刚进入这个世界」：清空记忆、下一 tick 立刻重扫
            handled.clear();
            lastScanTick = Long.MIN_VALUE;
            supplyNotice = null;
            harvestedCount = 0;
            plantedCount = 0;
            failedUntil.clear();
            workTicks = 0;
            sessionTicks = 0;
            pendingSafety = null;
            safetySeenTicks = 0;
            // 重新开工 = 人也歇够了：疲劳计时从零开始（这也是「手动恢复」档的复位方式）
            fatigueWorkTicks = 0;
            fatigueRestRemaining = 0;
            fatigueStopped = false;
        }
        lastEnabled = config.enabled;

        ConfigManager.persist();

        if (client != null && client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43469("autofarm.message.toggled",
                    class_2561.method_43471(config.enabled ? "autofarm.on" : "autofarm.off")), true);
        }
    }

    /** 挂在客户端 tick 末尾调用 */
    public static void tick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            reset();
            return;
        }

        // 每 tick 开头先复位「我们自己正在挖」的开关；这一 tick 真动了镐子的话，
        // BlockInteractor 会再把它置起来。原版读的就是这个标记（见 MinecraftClientMixin）。
        BlockInteractor.beginTick();

        // 防踢模式：推进一次内部随机量（转向速度、瞄准微颤、疾跑节奏）。
        // 放在最前面，是为了保证「同一 tick 里不管谁读它，读到的都是同一个值」。
        Humanizer.beginTick();

        AutoFarmConfig config = ConfigManager.get();
        if (!config.enabled && !config.visualize) {
            reset();
            return;
        }

        // 「关 → 开」的边沿：清空「已处理」并强制重扫。
        // 抓边沿而不是只看当前值，是为了让「面板里点开」和「快捷键开」走同一套逻辑，
        // 都能把还没被挖掉的成熟作物重新认出来。
        if (config.enabled != lastEnabled) {
            if (config.enabled) {
                handled.clear();
                lastScanTick = Long.MIN_VALUE;
                CropHarvester.reset();
                supplyNotice = null;
                // 附加功能的计时也重来一遍，否则「休息」和「运行时长」会带着上一轮的账继续走
                failedUntil.clear();
                humanizeDelay = 0;
                restRemaining = 0;
                workTicks = 0;
                sessionTicks = 0;
                pickupTargets.clear();
                pickupWaitTicks = 0;
                pickupWaitPos = null;
                hesitatedAt = null;
                pendingSafety = null;
                safetySeenTicks = 0;
                areaReturnTarget = null;
                areaReturnTried = false;
                areaReturning = false;
                fatigueWorkTicks = 0;
                fatigueRestRemaining = 0;
                fatigueStopped = false;
                KillAura.reset();
            }
            lastEnabled = config.enabled;
        }

        // 玩家关掉「自动收割」→ 立刻停手，并把「已处理」清空，
        // 这样下次打开开关时会重新从头规划一遍
        if (!config.enabled) {
            if (PathWalker.isActive() || supplyPhase != SupplyPhase.NONE) {
                cancelSupply(null);
                PathWalker.stop();
                CropHarvester.reset();
                handled.clear();
            }
        }

        // ================================================================
        // 优先级 1 —— 吃
        // 饿到跑不动就先吃。这是所有事情的前提：走不动的话，去下一棵作物要多花一倍时间。
        // 它会接管使用键，期间走路和收割都给它让路。
        // ================================================================
        AutoEater.tick(client, config);

        if (supplyCooldown > 0) {
            supplyCooldown--;
        }

        // ================================================================
        // 背包满了，又没地方存 → 停手
        // 继续收下去，多出来的作物只会掉在地上烂掉。宁可停下来等你处理，
        // 也不做这种「收了个寂寞」的事。腾出空间（或者设好补给点）之后自动恢复。
        // ================================================================
        boolean stopForFull = config.enabled && shouldStopForFullInventory(client, config);
        // 安全条件：血量太低、或者附近有敌对生物。它比「收菜」重要 ——
        // 人被打了还低着头收菜，是最容易出事的状态。
        // 附加功能「危险反应延迟」：危险第一次出现时先愣一下再停手 ——
        // 机器会在冒出危险的同一 tick 停手，真人总要花上几百毫秒（见 applyReactionDelay）。
        String safety = config.enabled ? applyReactionDelay(config, safetyNotice(client, config)) : null;

        if (stopForFull) {
            cancelSupply(null);
            PathWalker.stop();
            CropHarvester.reset();
            supplyNotice = "autofarm.notice.inventory_full_no_supply";
            state = FarmState.PAUSED;
        } else if (safety != null) {
            cancelSupply(null);
            PathWalker.stop();
            CropHarvester.reset();
            supplyNotice = safety;
            state = FarmState.PAUSED;
        } else if (isPauseNotice(supplyNotice)) {
            // 空间腾出来了 / 危险过去了，把那句提示撤掉
            supplyNotice = null;
        }

        // 这一 tick 要不要整个人停手（背包满、安全保护、外加几个附加功能）
        boolean resting = config.enabled && updateRest(config);
        // 附加功能「仅在指定时段工作」：不在工作时段就停手（账号仍然在线，只是不干活）
        boolean offSchedule = config.enabled && config.scheduleEnabled && !insideSchedule(config);
        // 附加功能「仅白天 / 仅晴天」：环境不合适就停手，条件一恢复自动继续
        String environment = config.enabled ? environmentNotice(client, config) : null;
        // 上面这些都成立 = 「已经在停手」。疲劳计时要用到它 ——
        // 只有真正在干活的那些 tick 才该被算进「连续工作」。
        boolean alreadyPaused = stopForFull || safety != null || resting || offSchedule || environment != null;
        // 附加功能「疲劳收工」：连续干到上限就整场停下来
        boolean fatigued = config.enabled && updateFatigue(config, alreadyPaused);
        boolean paused = alreadyPaused || fatigued;

        // 一停机就播报一次（actionbar），免得你以为是模组卡了 ——
        // 同一个原因只说一次，危险过去后自动允许下次再说。
        // 休息 / 工作时段 / 环境 / 疲劳在 supplyNotice 里没有位置（那栏留给
        // 「缺种子」「箱子满了」这类事），所以它们各用自己的键，同样走「只说一次」这套。
        String pauseKey;
        if (stopForFull || safety != null) {
            pauseKey = supplyNotice;
        } else if (resting) {
            pauseKey = "autofarm.notice.paused_resting";
        } else if (offSchedule) {
            pauseKey = "autofarm.notice.paused_schedule";
        } else if (environment != null) {
            pauseKey = environment;
        } else if (fatigued) {
            pauseKey = "autofarm.notice.paused_fatigue";
        } else {
            pauseKey = null;
        }
        announcePause(client, paused ? pauseKey : null);

        // 附加功能：HUD 详细统计的「运行时长」——只数真正干活的时间，
        // 暂停（满包 / 危险 / 休息 / 开着界面）的 tick 不算，这样它更像一块秒表。
        if (config.enabled && !paused) {
            sessionTicks++;
        }

        // 防踢模式：把「这一 tick 到底有没有在干活」喂给疲劳模型 ——
        // 干得越久，动作越容易走神；歇下来（暂停、开界面）它会慢慢回落
        Humanizer.feedWorking(config.enabled && !paused);

        // 自由视角（masa 全家桶的「灵魂出窍」）：摄像机和身体分开之后，
        // 屏幕上看到的人是不动的，可世界里方块却在自己碎 —— 那太显眼了。
        // 打开这个开关就先停手，只保留描边和路线；关掉开关则照常干活
        // （渲染本来就是按摄像机算的，所以画面不会错位）。
        boolean freecamPaused = config.pauseOnFreecam && CameraCompat.isCameraDetached();

        // ================================================================
        // 附加功能「圈定工作区域」：人跑出圈了就停手、走回来
        // 排在战斗之前 —— 已经越界了，就别再追着怪往别人地里跑。
        // 判据只看「人在不在区域里」，和「目标在不在区域里」是两件事：
        // 后者在扫描那一步就把圈外的目标滤掉了（见下面 matureCrops 的过滤）。
        // ================================================================
        boolean outsideArea = config.enabled
                && config.workAreaEnabled
                && !config.insideWorkArea(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());

        // 回到圈里了：把返回状态复位，恢复正常作业
        if (!outsideArea && areaReturning) {
            areaReturning = false;
            areaReturnTried = false;
            areaReturnTarget = null;
            lastScanTick = Long.MIN_VALUE; // 立刻重扫一遍，好接着干活
        }

        if (outsideArea
                && !paused
                && client.field_1755 == null
                && !CameraCompat.isCameraDetached()) {
            if (!areaReturning) {
                // 刚出界：把手上的活全放下（这条路线本来就通不到圈外去），准备回程
                areaReturning = true;
                areaReturnTried = false;
                cancelSupply(null);
                PathWalker.stop();
                CropHarvester.reset();
                handled.clear();
                matureCrops = Collections.emptyList();
                emptyFarmland = Collections.emptyList();
                pickupTargets.clear();
            }
            runAreaReturn(client, config);
            PathWalker.setPaused(false);
            state = FarmState.RETURNING;
            announcePause(client, "autofarm.notice.out_of_area");
            IdleLook.tick(client, config, false);
            return;
        }

        // ================================================================
        // 附加功能「自动打怪」（高风险，默认关闭）
        // 排在「吃」和「安全停机」之后、「收割」之前：
        //   - 已经因低血量 / 玩家靠近 / 背包满而停手时，paused 为真，这里自然不接管，
        //     不会出现「说停手了却还在打怪」的矛盾；
        //   - 它一旦接管，这一 tick 的寻路与收割都让路（见下面的 walkPaused 与优先级 2），
        //     但<b>不丢弃</b>手上的路线 —— 目标清掉之后自动接着收。
        // ================================================================
        boolean fightingActive = config.enabled
                && config.autoAttack
                && !paused
                && client.field_1755 == null
                && !CameraCompat.isCameraDetached()
                && KillAura.tick(client, config);

        // 玩家打开任意界面（背包、聊天、ESC……）、或者已经躺下了的时候立刻挂起，
        // 否则角色会在你翻背包的时候自顾自走开。危险、背包满、战斗也走同一条「暂停」通道。
        boolean walkPaused = client.field_1755 != null
                || !client.field_1724.method_5805()
                || freecamPaused
                || paused
                || fightingActive;
        PathWalker.setPaused(walkPaused);

        // 附加功能「空闲时环顾四周」：只有在「没在动、没在收、没在补给、也没因危险停机」时，
        // 才让视角慢慢游走。危险停机时不环顾 —— 那时候「装死」比「东张西望」更安全；
        // 自由视角下也不环顾（摄像机和身体是分开的，转头只会让人看着别扭）。
        boolean viewBusy = !walkPaused && (PathWalker.isActive() || CropHarvester.isBusy());
        IdleLook.tick(client, config, config.enabled
                && !stopForFull
                && safety == null
                && !offSchedule
                && !fightingActive
                && client.field_1755 == null
                && !CameraCompat.isCameraDetached()
                && !viewBusy);

        // ================================================================
        // 优先级 2 —— 补给 / 走 / 收
        // 战斗接管时不走这一段：手在挥刀，走路和收割都让路
        // ================================================================
        if (!paused && !fightingActive) {
            if (supplyPhase != SupplyPhase.NONE) {
                if (!freecamPaused) {
                    runSupply(client, config);
                }
            } else if (PathWalker.isActive()) {
                if (!freecamPaused) {
                    if (shouldGoDeposit(client, config) && PathWalker.getHeldTarget() == null) {
                        // 背包快满了：放下手上这条路线先去存东西。
                        // 剩下的作物不会丢 —— 它们没进 handled，下一轮扫描还会被规划进来。
                        PathWalker.stop();
                    } else {
                        drive(client, config);
                    }
                }
            }
        }

        // ================================================================
        // 扫描：面板计数和高亮都靠它，所以走路时也照样扫
        // ================================================================
        long now = client.field_1687.method_8510();
        if (lastScanTick != Long.MIN_VALUE && now - lastScanTick < getEffectiveScanInterval()) {
            return;
        }
        lastScanTick = now;

        // 「补种空耕地」只在真正要干活时才去扫（关着时连这块开销都省掉）。
        // 顺便注意：成熟作物的过滤条件挂在扫描里，被筛掉的作物根本不会进列表 ——
        // 于是世界里不给它画描边、面板计数也对得上。
        boolean wantFarmland = config.enabled && config.fillEmptyFarmland;
        CropScanner.ScanResult scanned = CropScanner.scan(
                client.field_1687,
                client.field_1724.method_24515(),
                config.scanRadius,
                CropScanner.DEFAULT_DOWN,
                CropScanner.DEFAULT_UP,
                state -> CropFilter.allowsHarvest(state.method_26204(), config, client.field_1724),
                wantFarmland
        );
        matureCrops = new ArrayList<>(scanned.mature());
        emptyFarmland = wantFarmland
                ? new ArrayList<>(scanned.emptyFarmland())
                : Collections.emptyList();

        // 附加功能「圈定工作区域」：圈外的目标一律不要 —— 既防跑丢，也防踩到别人的田。
        // 过滤放在扫描之后、规划之前，而不是塞进扫描器：扫描器只管「什么值得动」，
        // 「这块地是不是我的」是工作范围的事。顺带一个好处是圈外的作物不会被画上描边。
        if (config.workAreaEnabled && config.hasWorkArea()) {
            matureCrops.removeIf(pos -> !config.insideWorkArea(
                    pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5));
            if (!emptyFarmland.isEmpty()) {
                emptyFarmland.removeIf(pos -> !config.insideWorkArea(
                        pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5));
            }
        }

        // 附加功能「优先拾取掉落物」：顺手看看田里有没有掉在外面、还没进包的作物掉落物。
        // 得到的是「在哪一格」，下一步会排进路线最前面。
        pickupTargets.clear();
        if (config.pickupDroppedItems) {
            collectPickupTargets(client, config, pickupTargets);
        }

        // 让「已处理」集合跟着扫描结果瘦身，避免玩家在同一片区域待久了无限膨胀。
        // 收掉的作物会变成空气、补种后变成幼苗，两者都不再是「成熟作物」，
        // 所以它们会自然地从 handled 里掉出去。
        // 掉落物也算「这一轮还在的目标」：如果某件东西够不到、一直留在地上，
        // 把它一起保留下来，就不会每一轮都重新去试同一件捡不到的东西。
        if (!handled.isEmpty()) {
            Set<class_2338> current = new HashSet<>(matureCrops);
            current.addAll(emptyFarmland);
            current.addAll(pickupTargets);
            handled.retainAll(current);
        }

        if (!config.enabled) {
            // 只开了「可视化」：照样扫描（这样你能单独看到它认出了哪些方块），
            // 但状态显示为「空闲」，因为它不会去动角色。
            state = FarmState.IDLE;
            return;
        }

        if (paused) {
            // 背包满 / 安全保护：这一 tick 只扫描、不动角色。
            // 状态已经在上面设成「已暂停」了，别被后面的规划覆盖掉。
            state = FarmState.PAUSED;
            return;
        }

        if (fightingActive) {
            // 附加功能「自动打怪」：这一 tick 手在挥刀，不规划新路线、也不推进收割。
            // 手上那条路线没有丢 —— 只是被 PathWalker 挂着，目标清掉后自动接着走。
            state = FarmState.ATTACKING;
            return;
        }

        if (supplyPhase != SupplyPhase.NONE || PathWalker.isActive()) {
            // 补给 / 走路 / 收割的状态是上面那一段设好的，别覆盖掉
            return;
        }

        // ---- 优先级 3：手上没路线了，看看要不要去补给点，或者新规划一条 ----

        // 3a. 背包快满了 → 先去存一趟
        if (shouldGoDeposit(client, config)
                && startSupplyRun(client, config, true, refillWanted)) {
            return;
        }

        // 3b. 缺种子 → 去取一趟
        if (refillWanted && config.refillSeeds && config.hasSupplyPoint()
                && supplyCooldown == 0
                && startSupplyRun(client, config, false, true)) {
            return;
        }

        // 附加功能「失败目标暂时拉黑」：先把已经到期的解禁掉，
        // 再把还在冷却里的目标跳过。全关时 failedUntil 恒为空，这两步都是空转。
        if (!failedUntil.isEmpty()) {
            failedUntil.entrySet().removeIf(entry -> entry.getValue() <= now);
        }

        List<class_2338> pending = new ArrayList<>();

        // 附加功能「优先拾取掉落物」：先把散在地上的作物掉落物排进路线。
        // 它排在成熟作物前面 —— 掉落物不会自己长回去，还可能被水冲走、被怪撞飞，
        // 或者干脆因为存在太久而消失，所以先把它捡回来，再谈地里的活。
        for (class_2338 pos : pickupTargets) {
            if (!handled.contains(pos)) {
                pending.add(pos);
            }
        }

        for (class_2338 pos : matureCrops) {
            if (!handled.contains(pos) && !failedUntil.containsKey(pos)) {
                pending.add(pos);
            }
        }

        // 空耕地也排进同一条路线（如果开着补种空地）。
        // 一个前提：手边得真有种子 —— 一粒都没有的话，走过去也只是站着报「没种子」，
        // 白跑一趟。那种情况直接记账「该去补给点取种子」，让上面那条补给流程接手。
        if (config.fillEmptyFarmland && !emptyFarmland.isEmpty()) {
            if (InventoryScanner.countSeeds(client.field_1724, null) > 0) {
                for (class_2338 pos : emptyFarmland) {
                    if (!handled.contains(pos) && !failedUntil.containsKey(pos)) {
                        pending.add(pos);
                    }
                }
            } else {
                refillWanted = true;
                announceEvent(client, "autofarm.notice.plant_no_seed");
            }
        }

        if (pending.isEmpty()) {
            // 这一轮都收完了。等新一批作物成熟，或者走回还没扫过的区域，才会重新规划。
            state = matureCrops.isEmpty() ? FarmState.IDLE : FarmState.SCANNING;
            return;
        }

        // 防踢模式：偶尔「偷个懒」不做 2-opt 优化 —— 真人规划路线本来就不会次次都是最优解，
        // 每次都被算出一条数学上最短的走法，反而比走岔一点更像机器
        boolean optimize = config.optimizePath && !Humanizer.skipOptimize();
        PathPlanner.Plan plan = PathPlanner.plan(
                client.field_1724.method_24515(),
                pending,
                optimize
        );
        // 掉落物是「要碰到才算数」的目标：必须走到它那一格上原版才会把它吸进背包，
        // 不能像作物那样站在旁边看着。把这类格子单独告诉执行器。
        PathWalker.setExactTargets(pickupTargets);
        PathWalker.start(plan);
        state = FarmState.MOVING;
    }

    /**
     * 把附近「掉在地上、还没进包」的农作物掉落物找出来（附加功能，默认关闭）。
     *
     * <p>三条判据，缺一不可：
     * <ol>
     *   <li>它得是<b>农作物产物</b>（见 {@link CropRegistry#isCropDrop}）——
     *       不然会把玩家自己丢的杂物也一股脑捡回来；</li>
     *   <li>它得在地上待够 {@link AutoFarmConfig#pickupDelaySeconds} 秒还没进背包 ——
     *       刚掉出来的那一小会儿，原版正把它往玩家身上吸，这时候不该算「漏捡」；</li>
     *   <li>它得离玩家有点距离 —— 就在脚边的，走过去顺手就捡了，不必当成一个专门的目标。</li>
     * </ol>
     */
    private static void collectPickupTargets(class_310 client, AutoFarmConfig config,
                                             Set<class_2338> out) {
        long minAge = Math.max(1, config.pickupDelaySeconds) * 20L; // 秒 → tick
        double ignoreSq = PICKUP_IGNORE_DISTANCE * PICKUP_IGNORE_DISTANCE;
        class_238 box = client.field_1724.method_5829().method_1014(config.scanRadius);
        for (class_1542 item : client.field_1687.method_8390(class_1542.class, box,
                e -> e.method_5805()
                        && e.method_6985() >= minAge
                        && e.method_5858(client.field_1724) > ignoreSq
                        && CropRegistry.isCropDrop(e.method_6983())
                        && config.insideWorkArea(e.method_23317(), e.method_23318(), e.method_23321()))) {
            out.add(item.method_24515().method_10062());
        }
    }

    /**
     * 走一步，或者干一步活。
     *
     * <p>这里是两个小状态机：
     * <ol>
     *   <li>人已经站到目标跟前（{@link PathWalker#isHolding()}）→ 交给收割机挖掉 + 补种；</li>
     *   <li>否则就照着 A* 算出的路线继续往前走。</li>
     * </ol>
     *
     * <p>「到站就停下来干活」这件事就是在这里落地的：{@code PathWalker}
     * 走到目标不再直接 index++ 去下一个，而是把目标交出来，活干完才放行。
     */
    private static void drive(class_310 client, AutoFarmConfig config) {
        // 附加功能「拟人化节奏」：刚干完一棵，先愣一下再去下一棵。
        // 停顿期间不推进路线、也不挥镐子 —— 真人也不会以恒定的节拍连续操作。
        if (humanizeDelay > 0) {
            humanizeDelay--;
            return;
        }

        class_2338 held = PathWalker.getHeldTarget();

        // 还没到站（没在等收割）→ 只管走路
        if (held == null) {
            PathWalker.tick(client);
            drainResolved();
            return;
        }

        // 附加功能「优先拾取掉落物」：这一趟是去捡地上的东西。
        // 到了那一格不用挖也不用种，站上去等原版把它吸进背包即可 ——
        // 但要停一小会儿再放行，否则刚站到就转身走开，东西还留在原地。
        if (pickupTargets.contains(held)) {
            if (!held.equals(pickupWaitPos)) {
                pickupWaitPos = held;
                pickupWaitTicks = PICKUP_WAIT_TICKS;
            }
            if (pickupWaitTicks > 0) {
                pickupWaitTicks--;
                state = FarmState.PICKUP;
                return;
            }
            pickupWaitPos = null;
            PathWalker.releaseTarget();
            drainResolved();
            state = PathWalker.isActive() ? FarmState.MOVING : FarmState.IDLE;
            return;
        }

        // 开关被关掉了 → 放行，别把角色吊在一个点上
        if (!config.enabled) {
            PathWalker.releaseTarget();
            drainResolved();
            return;
        }

        // 你开着界面（背包/聊天/ESC）→ 原地等你。
        // 这里刻意不「放行」：万一你只是随手翻下背包，回头这一棵还得接着收。
        if (client.field_1755 != null) {
            return;
        }

        // 吃 > 收：正在进食、或者刚吃完还没缓过来（马上还要再吃一口）就先别挥镐子
        if (AutoEater.isHandlingHunger()) {
            state = FarmState.HARVESTING;
            return;
        }

        if (!CropHarvester.isBusy()) {
            // 附加功能「工具耐久换新」：手上的工具剩余耐久见底了，先从背包换一把好的。
            // 换手要发一个换位包，所以这一 tick 先不动手，下一 tick 用新工具继续。
            if (config.autoReplaceTool
                    && InventoryScanner.replaceWornTool(client, client.field_1724, config.toolDurabilityPercent)) {
                state = FarmState.HARVESTING;
                return;
            }
            // 防踢模式：动手之前先「打量一下」这一棵。每个目标只犹豫一次 ——
            // 犹豫过就记下来，否则站在同一棵前面来回打量，永远不开工。
            boolean fresh = !held.equals(hesitatedAt);
            hesitatedAt = held;
            if (fresh && Humanizer.rollHesitate()) {
                humanizeDelay = Math.max(humanizeDelay, Humanizer.hesitateTicks());
                state = FarmState.HARVESTING;
                return;
            }

            supplyNotice = null; // 新的活开始了，上一次补给的那句话可以撤掉
            CropHarvester.start(client.field_1687, held, config);
        }
        boolean finished = CropHarvester.tick(client, config);
        state = CropHarvester.isReplanting() ? FarmState.REPLANTING : FarmState.HARVESTING;

        if (finished) {
            // 统计：真的收到了才算数（判定「这格不该动」时 wasHarvested 是 false）
            if (CropHarvester.wasHarvested()) {
                harvestedCount++;
            }
            // 空地补种单独记一笔 —— 它没「收」到任何东西，但确实干了活
            if (CropHarvester.wasPlanted()) {
                plantedCount++;
            }

            // 没种子补种 → 记下缺的是哪种，等这条路线走完就去补给点取
            if (CropHarvester.needsSeedRefill()) {
                // 第一次发现没种子时说一声 —— 这之前你可能一直以为它在正常干活
                if (!refillWanted) {
                    announceEvent(client, "autofarm.notice.out_of_seeds");
                }
                refillWanted = true;
                class_2248 crop = CropHarvester.getCropBlock();
                if (crop != null) {
                    missingSeeds.add(crop);
                }
            }

            // 立刻把它从目标列表里摘掉：否则在下一轮扫描之前，
            // 那格已经变成空气/幼苗了，世界里却还画着一个描边框。
            if (!matureCrops.isEmpty()) {
                matureCrops.remove(held);
            }
            if (!emptyFarmland.isEmpty()) {
                emptyFarmland.remove(held);
            }
            PathWalker.releaseTarget();
            drainResolved();

            // 附加功能「失败目标暂时拉黑」：这一棵没干成、而且给出了原因（挖不动、
            // 种不下去……）才拉黑。单纯「这一格已经不是成熟作物」不算失败 ——
            // 那是被别人收走了，重试也没意义。拉黑的做法是从 handled 里撤回来、
            // 记个到期时间，到点自然会重新排进路线，不用你手动关开一次。
            boolean failed = !CropHarvester.wasHarvested() && !CropHarvester.wasPlanted()
                    && CropHarvester.getNotice() != null;
            if (config.failureCooldown && failed && held != null) {
                failedUntil.put(held.method_10062(),
                        client.field_1687.method_8510() + config.failureCooldownSeconds * 20L);
                handled.remove(held);
            }

            // 附加功能「拟人化节奏」：这一次真的动了手（收了或种了），就歇一小会儿
            if (config.humanizeTiming
                    && (CropHarvester.wasHarvested() || CropHarvester.wasPlanted())) {
                humanizeDelay = 2 + ThreadLocalRandom.current().nextInt(4); // 2~5 tick
            }

            state = PathWalker.isActive() ? FarmState.MOVING : FarmState.IDLE;
        }
    }

    /** 把 PathWalker 结算掉的点收进「已处理」 */
    private static void drainResolved() {
        class_2338 pos;
        while ((pos = PathWalker.pollResolved()) != null) {
            handled.add(pos);
        }
    }

    // ================= 补给点往返 =================

    /** 「背包快满了，而且真有东西可以存」→ 该跑一趟 */
    private static boolean shouldGoDeposit(class_310 client, AutoFarmConfig config) {
        return config.depositWhenFull
                && config.hasSupplyPoint()
                && supplyCooldown == 0
                && InventoryScanner.isNearlyFull(client.field_1724, INVENTORY_RESERVE)
                && InventoryScanner.hasDepositableItems(client.field_1724, config);
    }

    /**
     * 「背包满了，可是没地方存」→ 该停手了。
     *
     * <p>判定里那个 {@link ContainerCompat#findContainer} 就是「有没有存储设备」：
     * 它按「方块实体实现了 Inventory」来认，所以箱子、木桶、陷阱箱、潜影盒，
     * 以及<b>任何照惯例实现的存储模组</b>都算数；只有「压根没设补给点」或者
     * 「设的那一格真的不是容器」才会返回 true。
     *
     * <p>注意它同时要求「真有东西可以存」：背包只剩 1 个空格、但里面全是种子和食物时，
     * 其实一格都存不掉，这时候停手反而莫名其妙。
     */
    private static boolean shouldStopForFullInventory(class_310 client, AutoFarmConfig config) {
        if (!InventoryScanner.isNearlyFull(client.field_1724, INVENTORY_RESERVE)) {
            return false;
        }
        if (!InventoryScanner.hasDepositableItems(client.field_1724, config)) {
            return false;
        }
        return ContainerCompat.findContainer(client.field_1687, supplyPos(config)) == null;
    }

    /**
     * 开始一趟补给点往返。
     *
     * <p>先找「箱子里能站人的那一格」，把它当成路线的唯一目标；
     * 人到了之后由 {@link #runSupply} 接手去开箱和搬东西。
     *
     * @return 有没有真的开始（没设补给点、附近没有容器、旁边站不住人都算失败）
     */
    private static boolean startSupplyRun(class_310 client, AutoFarmConfig config,
                                          boolean deposit, boolean refill) {
        class_2338 wanted = supplyPos(config);
        if (wanted == null) {
            return false;
        }
        // 补给点那一格（或者它附近）得真有个容器。判定按能力来 —— 见 ContainerCompat，
        // 箱子、木桶、模组容器一律认得出来。
        class_2338 container = ContainerCompat.findContainer(client.field_1687, wanted);
        if (container == null) {
            supplyNotice = "autofarm.notice.supply_not_container";
            return false;
        }
        class_2338 stand = BlockNavigator.findViewSpot(client.field_1687, container);
        if (stand == null) {
            supplyNotice = "autofarm.notice.supply_no_spot";
            return false;
        }

        supplyContainer = container;
        supplyDeposit = deposit;
        supplyRefill = refill;
        supplyPhase = SupplyPhase.GOING;
        state = FarmState.TO_SUPPLY;

        // 已经站在旁边了：不用再走，直接开箱
        if (BlockInteractor.isWithinReach(client.field_1724, container, 4.0)) {
            beginTransfer(config);
            return true;
        }

        PathPlanner.Plan plan = PathPlanner.plan(
                client.field_1724.method_24515(), List.of(stand), false);
        PathWalker.start(plan);
        if (!PathWalker.isActive()) {
            // 规划器会把「和起点重合的目标」去掉，于是在这里就是空路线 —— 说明人已经在落点上了
            beginTransfer(config);
        }
        return true;
    }

    /** 走到补给点旁边了，开始开箱存取 */
    private static void beginTransfer(AutoFarmConfig config) {
        PathWalker.stop();
        class_2338 container = currentContainer(config);
        if (container == null) {
            cancelSupply("autofarm.notice.supply_not_container");
            return;
        }
        supplyPhase = SupplyPhase.TRANSFERRING;
        state = FarmState.TRANSFERRING;
        ContainerTransfer.begin(container, supplyDeposit, supplyRefill, missingSeeds);
    }

    /**
     * 这一趟要开的那个容器。
     *
     * <p>出发时已经认过一次并记在 {@link #supplyContainer} 里了，这里优先用它；
     * 万一丢了（比如中途重进世界）就现场再认一次。
     */
    private static class_2338 currentContainer(AutoFarmConfig config) {
        if (supplyContainer != null) {
            return supplyContainer;
        }
        class_310 client = class_310.method_1551();
        return client == null ? null : ContainerCompat.findContainer(client.field_1687, supplyPos(config));
    }

    /** 每 tick 推进一步：要么在走过去，要么在开箱搬东西 */
    private static void runSupply(class_310 client, AutoFarmConfig config) {
        class_2338 container = currentContainer(config);
        if (container == null) {
            cancelSupply("autofarm.notice.supply_unreachable");
            return;
        }

        if (supplyPhase == SupplyPhase.GOING) {
            state = FarmState.TO_SUPPLY;

            // 到站了（路线走完、PathWalker 把目标交出来）→ 开箱
            if (PathWalker.getHeldTarget() != null) {
                PathWalker.releaseTarget();
                beginTransfer(config);
                return;
            }
            if (PathWalker.isActive()) {
                PathWalker.tick(client);
                drainResolved();
                return;
            }
            // 路线没了：要么人其实已经站在旁边，要么这次真的去不了
            if (BlockInteractor.isWithinReach(client.field_1724, container, 4.0)) {
                beginTransfer(config);
            } else {
                cancelSupply("autofarm.notice.supply_unreachable");
            }
            return;
        }

        // ---- 开箱存取 ----
        state = FarmState.TRANSFERRING;
        boolean didRefill = supplyRefill;
        boolean didDeposit = supplyDeposit;

        ContainerTransfer.Result result = ContainerTransfer.tick(client);
        if (result == ContainerTransfer.Result.RUNNING) {
            return;
        }

        if (result == ContainerTransfer.Result.FAILED) {
            supplyNotice = ContainerTransfer.getFailure();
        } else if (didRefill) {
            supplyNotice = ContainerTransfer.getTakenStacks() > 0
                    ? "autofarm.notice.supply_refilled"
                    : "autofarm.notice.supply_no_seed";
        } else if (didDeposit) {
            supplyNotice = "autofarm.notice.supply_deposited";
        }
        // 补给点的结果是「一趟才有一次」的事，直接播报一条就够了
        announceEvent(client, supplyNotice);

        // 「要办的事一件都没办成」（箱子满了、箱子里没种子）→ 歇一会儿再去，
        // 否则下一 tick 条件照样成立，它会立刻掉头再跑一趟，变成两个点之间横跳
        boolean achieved = result == ContainerTransfer.Result.DONE
                && (!didDeposit || ContainerTransfer.getDepositedStacks() > 0)
                && (!didRefill || ContainerTransfer.getTakenStacks() > 0);
        supplyCooldown = achieved ? 0 : SUPPLY_RETRY_COOLDOWN_TICKS;

        finishSupply();
    }

    /** 一趟存取正常结束 */
    private static void finishSupply() {
        supplyPhase = SupplyPhase.NONE;
        supplyDeposit = false;
        supplyRefill = false;
        refillWanted = false;
        missingSeeds.clear();
        supplyContainer = null;
        // 允许下一次补给再说一遍（不然「种子已取回」这种提示一局只会出现一次）
        lastEventAnnounce = null;
        lastScanTick = Long.MIN_VALUE; // 立刻重扫一遍，好接着干活
        state = FarmState.IDLE;
    }

    /** 这趟去不成（关开关、没设补给点、走不到） */
    private static void cancelSupply(String notice) {
        PathWalker.stop();
        ContainerTransfer.reset();
        supplyPhase = SupplyPhase.NONE;
        supplyDeposit = false;
        supplyRefill = false;
        refillWanted = false;
        missingSeeds.clear();
        supplyContainer = null;
        if (notice != null) {
            supplyNotice = notice;
        }
        state = FarmState.IDLE;
    }

    /** 补给点坐标，没设置返回 null */
    private static class_2338 supplyPos(AutoFarmConfig config) {
        return config.hasSupplyPoint()
                ? new class_2338(config.supplyX, config.supplyY, config.supplyZ)
                : null;
    }

    // ================= 安全保护 =================

    /**
     * 现在有没有「该马上停手」的危险。
     *
     * <p>三类条件，任意一类成立就返回对应的提示键：
     * <ol>
     *   <li><b>血量太低</b>（{@link AutoFarmConfig#lowHealthStopHearts}，单位心，0 = 关闭）。
     *       收割的时候人一直低着头，被偷袭或者掉进坑里都反应不过来 ——
     *       与其等你事后发现人没了，不如先站着不动；</li>
     *   <li><b>附近有敌对生物</b>（{@link AutoFarmConfig#pauseWhenMobsNear}）。
     *       认的是原版那套「敌对生物」标记，所以僵尸、骷髅、苦力怕、蜘蛛，
     *       以及按同样方式实现的模组怪都算数；</li>
     *   <li><b>附近有别的玩家</b>（{@link AutoFarmConfig#pauseWhenPlayerNear}，附加功能，
     *       默认关闭）—— 自动收割最容易被发现的就是「被别的玩家撞见」。</li>
     * </ol>
     *
     * <p>这两件事都<b>只是停手</b>，不会替你做任何反击或者逃跑的动作 ——
     * 它保证的是「不会一边挨打一边傻站着收菜」，不是「帮你打架」。
     *
     * @return 该停手的原因（翻译键）；没有危险返回 {@code null}
     */
    private static String safetyNotice(class_310 client, AutoFarmConfig config) {
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            return null;
        }

        if (config.lowHealthStopHearts > 0) {
            float threshold = config.lowHealthStopHearts * 2.0f; // 心 → 点（1 心 = 2 点）
            if (client.field_1724.method_6032() < threshold) {
                return "autofarm.notice.paused_low_health";
            }
        }

        // 附加功能「自动打怪」开着时，这一条让位 —— 怪由 KillAura 处理。
        // 不让位的话会出现自相矛盾的状态：它一边挥刀打怪、一边因为「附近有怪」而停手。
        if (config.pauseWhenMobsNear && !config.autoAttack) {
            class_238 box = client.field_1724.method_5829().method_1014(AutoFarmConfig.MOB_ALERT_RADIUS);
            List<class_1308> threats = client.field_1687.method_8390(class_1308.class, box,
                    mob -> mob.method_5805() && mob instanceof class_1569);
            if (!threats.isEmpty()) {
                return "autofarm.notice.paused_mobs_near";
            }
        }

        // 附加功能：附近有别的玩家时停机。凭空多出来的人形很少是好事 ——
        // 要么是来自找你的，要么是来看你「演戏」的，两种都值得先停下装挂机。
        // 判据是服务端同步过来的玩家实体，离线单人世界里永远为空，所以不碍事。
        if (config.pauseWhenPlayerNear) {
            class_238 box = client.field_1724.method_5829().method_1014(config.playerNearRadius);
            List<class_1657> others = client.field_1687.method_8390(class_1657.class, box,
                    other -> other != client.field_1724 && other.method_5805());
            if (!others.isEmpty()) {
                return "autofarm.notice.paused_player_near";
            }
        }
        return null;
    }

    /**
     * 推进「定时随机休息」的计时（附加功能，默认关闭）。
     *
     * <p>逻辑很简单：一直累计「连续工作了多久」，到点了就把人按下去休息一会儿，
     * 休息结束再重新累计。关掉这个功能时会把计时归零 —— 否则下次打开时
     * 可能「一上来就欠着几分钟」，立刻就开始休息，很莫名其妙。
     *
     * @return 这一 tick 是不是在休息
     */
    private static boolean updateRest(AutoFarmConfig config) {
        if (!config.randomRest) {
            restRemaining = 0;
            workTicks = 0;
            return false;
        }
        if (restRemaining > 0) {
            restRemaining--;
            return true;
        }
        workTicks++;
        int interval = Math.max(1, config.restIntervalMinutes) * 20 * 60; // 分钟 → tick
        if (workTicks >= interval) {
            workTicks = 0;
            restRemaining = Math.max(1, config.restDurationSeconds) * 20; // 秒 → tick
            return true;
        }
        return false;
    }

    /**
     * 给「危险提示」套一层反应延迟（附加功能，默认关闭）。
     *
     * <p>没开这个功能、或者本来就没有危险时，原样返回。
     * 开着的时候：危险第一次出现先记下类型、开始数 tick，数够
     * {@link AutoFarmConfig#reactionDelayTicks} 才真正把它当成「要停手」——
     * 在此之前返回 {@code null}，等于「还没反应过来，继续干」。
     *
     * <p>危险消失、或者换了一种危险（比如从「有怪」变成「血量低」），计时都重新开始。
     */
    private static String applyReactionDelay(AutoFarmConfig config, String safety) {
        if (!config.reactionDelay || safety == null) {
            pendingSafety = null;
            safetySeenTicks = 0;
            return safety;
        }
        if (safety.equals(pendingSafety)) {
            safetySeenTicks++;
        } else {
            pendingSafety = safety;
            safetySeenTicks = 0;
        }
        return safetySeenTicks >= Math.max(1, config.reactionDelayTicks) ? safety : null;
    }

    /**
     * 现在是不是在「允许工作的时段」内（附加功能，默认关闭）。
     *
     * <p>用<b>本机时间</b>判断：起止都是 0~23 的整点、终点不含。起止相同表示全天。
     * 起点大于终点表示跨午夜（比如 22 点到次日 6 点）。
     */
    private static boolean insideSchedule(AutoFarmConfig config) {
        int start = Math.max(0, Math.min(23, config.scheduleStartHour));
        int end = Math.max(0, Math.min(23, config.scheduleEndHour));
        if (start == end) {
            return true; // 起止相同 = 全天，等于没限制
        }
        int hour = java.time.LocalTime.now().getHour();
        return start < end ? (hour >= start && hour < end) : (hour >= start || hour < end);
    }

    /**
     * 环境偏好：现在适不适合干活（附加功能，默认关闭）。
     *
     * <p>两条独立的规矩，任意一条不满足就返回对应的提示键：
     * <ul>
     *   <li>{@link AutoFarmConfig#workDaylightOnly} —— 只白天干。判定用
     *       {@code world.isDay()}（世界时间，不是本机时间）；</li>
     *   <li>{@link AutoFarmConfig#workClearWeatherOnly} —— 只晴天干。下雨、雷暴都算「不是晴天」。</li>
     * </ul>
     * 两条都只是停手，条件一恢复自动继续，不需要你重新开开关。
     *
     * @return 该停手的原因（翻译键）；环境合适返回 {@code null}
     */
    private static String environmentNotice(class_310 client, AutoFarmConfig config) {
        if (client == null || client.field_1687 == null) {
            return null;
        }
        if (config.workDaylightOnly && !client.field_1687.method_8530()) {
            return "autofarm.notice.paused_night";
        }
        if (config.workClearWeatherOnly && client.field_1687.method_8419()) {
            return "autofarm.notice.paused_weather";
        }
        return null;
    }

    /**
     * 推进「疲劳收工」（附加功能，默认关闭）。
     *
     * <p>和 {@link #updateRest} 的区别是<b>尺度</b>：定时休息是「中途喝口水」，
     * 这个管的是整场作业 —— 连续干够 {@link AutoFarmConfig#fatigueWorkMinutes} 分钟就彻底收工，
     * 休息 {@link AutoFarmConfig#fatigueRestMinutes} 分钟再上工
     * （那一项设 0 就是「手动」：一直停着，直到你把开关关掉再打开）。
     *
     * <p>只在「这一 tick 本来就在干活」时累计：{@code alreadyPaused} 为真说明已经因为
     * 别的原因（满包、危险、定时休息、工作时段、环境）停下了，这些时间不该算进连续工作时长。
     *
     * @return 这一 tick 是不是在收工/休息
     */
    private static boolean updateFatigue(AutoFarmConfig config, boolean alreadyPaused) {
        if (!config.fatigueStop) {
            // 关掉这个功能 = 人歇够了，计时全部归零
            fatigueWorkTicks = 0;
            fatigueRestRemaining = 0;
            fatigueStopped = false;
            return false;
        }
        if (fatigueStopped) {
            return true; // 「手动恢复」档：一直停着，等玩家把开关（或总开关）关掉再打开
        }
        if (fatigueRestRemaining > 0) {
            fatigueRestRemaining--;
            if (fatigueRestRemaining == 0) {
                fatigueWorkTicks = 0; // 歇够了，重新开始计时
            }
            return true;
        }
        if (alreadyPaused) {
            return false;
        }
        fatigueWorkTicks++;
        int limit = Math.max(5, config.fatigueWorkMinutes) * 20 * 60; // 分钟 → tick
        if (fatigueWorkTicks < limit) {
            return false;
        }
        fatigueWorkTicks = 0;
        if (config.fatigueRestMinutes > 0) {
            fatigueRestRemaining = config.fatigueRestMinutes * 20 * 60;
        } else {
            fatigueStopped = true; // 手动：一直停到玩家重开
        }
        return true;
    }

    /**
     * 越界返回：把人带回工作区域（附加功能，默认关闭）。
     *
     * <p>回程走的还是 {@link PathWalker} 那条通道，但目标不是作物，所以用
     * {@link PathWalker#setExactTargets} 声明「要站到它本身那一格」，
     * 并在到站时手动放行（见 {@link #areaReturnTarget}）。
     *
     * <p>只尝试一次：路线排不出来、或者走完人还在圈外（被水冲走、被怪推出去……），
     * 就原地待命、不再反复重排 —— 否则会变成每 tick 重算一次 A* 的空转，多半还是走不通。
     * 这时候玩家自己走回去，或者关掉这个功能就行。
     */
    private static void runAreaReturn(class_310 client, AutoFarmConfig config) {
        // 正在走「回程」这条路 → 推进一步
        if (PathWalker.isActive() && areaReturnTarget != null
                && areaReturnTarget.equals(PathWalker.getCurrentTarget())) {
            PathWalker.tick(client);
            drainResolved();
            class_2338 held = PathWalker.getHeldTarget();
            if (held != null && held.equals(areaReturnTarget)) {
                PathWalker.releaseTarget();
                drainResolved();
                areaReturnTarget = null;
            }
            return;
        }
        // 手上是别的路线（越界时开着界面，被正常流程插了一条收割路线）→ 扔掉，改成回程
        if (PathWalker.isActive()) {
            PathWalker.stop();
        }
        if (areaReturnTried) {
            return;
        }
        areaReturnTried = true;

        class_2338 goal;
        if (config.workAreaMode == AutoFarmConfig.AREA_MODE_BOX) {
            // 矩形模式往两个角点的正中走 —— 那是这片区域的正中心，最稳
            goal = new class_2338(
                    (config.workAreaX + config.workAreaX2) / 2,
                    (config.workAreaY + config.workAreaY2) / 2,
                    (config.workAreaZ + config.workAreaZ2) / 2);
        } else {
            goal = new class_2338(config.workAreaX, config.workAreaY, config.workAreaZ);
        }
        // 目标那一格可能站不住人（被填了方块），退而求其次找个能看见它的落脚点
        if (!BlockNavigator.canStand(client.field_1687, goal)) {
            class_2338 spot = BlockNavigator.findViewSpot(client.field_1687, goal);
            if (spot == null) {
                return;
            }
            goal = spot;
        }

        PathWalker.setExactTargets(List.of(goal));
        PathWalker.start(PathPlanner.plan(client.field_1724.method_24515(), List.of(goal), false));
        areaReturnTarget = PathWalker.isActive() ? goal : null;
    }

    /** 这句话是不是「停机原因」——停机解除时要记得把它撤掉 */
    private static boolean isPauseNotice(String key) {
        return "autofarm.notice.inventory_full_no_supply".equals(key)
                || "autofarm.notice.paused_low_health".equals(key)
                || "autofarm.notice.paused_mobs_near".equals(key)
                || "autofarm.notice.paused_player_near".equals(key);
    }

    // ================= actionbar 播报 =================

    /**
     * 停机播报：同一个原因只说一次，危险过去（{@code key} 传 null）后自动解锁。
     *
     * <p>为什么要防重：停机条件每 tick 都成立，不拦一下就会变成一条刷屏的提示。
     */
    private static void announcePause(class_310 client, String key) {
        if (key == null) {
            lastPauseAnnounce = null;
            return;
        }
        if (key.equals(lastPauseAnnounce)) {
            return;
        }
        lastPauseAnnounce = key;
        sendActionBar(client, key);
    }

    /** 事件播报：补给结果、种子用完这类「一个事件一次」的提示 */
    private static void announceEvent(class_310 client, String key) {
        if (key == null || key.equals(lastEventAnnounce)) {
            return;
        }
        lastEventAnnounce = key;
        sendActionBar(client, key);
    }

    /** 在快捷栏上方飘一行字（{@code overlay = true} 就是 actionbar） */
    private static void sendActionBar(class_310 client, String translationKey) {
        if (client != null && client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43471(translationKey), true);
        }
    }
}
