package com.autofarm.client.gui;

import com.autofarm.client.config.AutoFarmConfig;
import com.autofarm.client.scan.CropRegistry;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3965;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_7919;

/**
 * 「附加功能」次级面板：一堆<b>默认全部关闭</b>的增强项，集中放在这里。
 *
 * <h2>为什么要单开一页、而且默认全关</h2>
 * 主面板上的每一项都是「收割本身需要的东西」—— 扫描、寻路、补种、存放、安全。
 * 而这里放的是一层<b>可有可无的锦上添花</b>：有的改变动作节奏（拟人化、定时休息），
 * 有的改变安全边界（别的玩家靠近就停手），有的只是顺手多干点活
 * （工具快坏了换一把、失败的作物过会儿再试、HUD 多显示点数字）。
 *
 * <p>它们共同的风险是「玩家没要，却擅自改变了行为」。所以默认**一个都不开**：
 * 不碰它们，模组的行为和以前一模一样。想用哪个再单独打开。
 *
 * <h2>十二段</h2>
 * <ol>
 *   <li><b>战斗（高风险）</b> —— 自动打怪、目标范围、攻击间隔（输入框）、攻击距离、
 *       暴力模式与暴力程度。默认关闭、警示配色、开启与调高参数都要过风险确认屏，
 *       而且必须先打开主面板的「自动收割」总开关；</li>
 *   <li><b>安全与隐蔽</b> —— 玩家接近停机、拟人化节奏、定时随机休息；</li>
 *   <li><b>防踢模式</b> —— 一整套「把机器味抹掉」的措施，带四档强度；</li>
 *   <li><b>行为真实感</b> —— 危险反应延迟、空闲时环顾四周、仅在指定时段工作；</li>
 *   <li><b>工作范围</b> —— 圈定自己那块地（圆形或两点矩形），区域外的目标不碰，
 *       人走出区域会自动走回来；</li>
 *   <li><b>环境与作息</b> —— 仅白天 / 仅晴天，以及「连续工作到上限就收工」的疲劳档；</li>
 *   <li><b>生存自保</b> —— 危险撤退、受击反制、环境自救、掉线重连；</li>
 *   <li><b>工具维护</b> —— 工具耐久自动换新；</li>
 *   <li><b>容错与统计</b> —— 失败目标暂时拉黑、HUD 详细统计；</li>
 *   <li><b>掉落物</b> —— 优先拾取散落在田里的作物掉落物；</li>
 *   <li><b>瓜类与自定义作物</b> —— 瓜茎识别（收割茎旁自然长出的瓜）+ 自定义方块名单
 *       （非矿透）。</li>
 *   <li><b>资源自给</b> —— 骨粉催熟，以及骨粉 / 备用工具从补给点自取。</li>
 * </ol>
 * 每个「功能开关」下面跟着的参数行（半径、周期、阈值……）都用循环按钮调，
 * 点一下换一档，不用滑块 —— 和主面板的「默认种子槽位」一个习惯。
 *
 * <h2>和主面板的关系</h2>
 * 老规矩：它编辑的是主面板递进来的<b>同一个草稿</b>。点「完成」回主面板，
 * 最终由主面板的「保存并关闭」落盘；点「取消」或 Esc 只把这里的十几项
 * 恢复成进来之前的样子，不碰草稿里的其他设置。
 */
public class ExtrasScreen extends ScrollPanelScreen {

    // ---------------- 内容区布局（相对内容区顶部） ----------------
    /** 分区内第一行相对分区顶部的 y（让开标题那一行） */
    private static final int ROW_FIRST = 18;
    /** 相邻两行的间距 */
    private static final int ROW_GAP = 20;
    /** 两个分区之间的留白 */
    private static final int SECTION_GAP = 6;
    /** 参数行的左缩进，视觉上表示「从属于上一行」 */
    private static final int INDENT = 8;
    /** 高风险分区专用的警示色：标题与开关文字都用它 */
    private static final int COLOR_DANGER = 0xFFFF5555;

    /** 攻击间隔行的左侧标签宽度 / 输入框宽度 —— 右侧那段留给「范围提示」文字 */
    private static final int INTERVAL_LABEL_W = 60;
    private static final int INTERVAL_FIELD_W = 56;

    /** 战斗分区：6 行（打怪 / 间隔 / 距离 / 目标 / 暴力 / 暴力程度）+ 底部两行警示 */
    private static final int COMBAT_ROWS = 6;
    private static final int COMBAT_WARN_H = 26;
    private static final int SEC_COMBAT_Y = 0;
    private static final int SEC_COMBAT_H = ROW_FIRST + COMBAT_ROWS * ROW_GAP + COMBAT_WARN_H;

    private static final int STEALTH_ROWS = 6;
    private static final int SEC_STEALTH_Y = SEC_COMBAT_H + SECTION_GAP;
    private static final int SEC_STEALTH_H = ROW_FIRST + STEALTH_ROWS * ROW_GAP + 4;

    private static final int ANTIKICK_ROWS = 2;
    private static final int SEC_ANTIKICK_Y = SEC_STEALTH_Y + SEC_STEALTH_H + SECTION_GAP;
    private static final int SEC_ANTIKICK_H = ROW_FIRST + ANTIKICK_ROWS * ROW_GAP + 4;

    private static final int BEHAVIOR_ROWS = 6;
    private static final int SEC_BEHAVIOR_Y = SEC_ANTIKICK_Y + SEC_ANTIKICK_H + SECTION_GAP;
    private static final int SEC_BEHAVIOR_H = ROW_FIRST + BEHAVIOR_ROWS * ROW_GAP + 4;

    /**
     * 工作范围：开关、方式、参数（圆形 = 半径 + 记录中心；矩形 = 记录 A + 记录 B），
     * 最后一行留给一句自绘说明。两种方式的参数行共占同样两行，用显隐切换。
     */
    private static final int WORKAREA_ROWS = 5;
    private static final int SEC_WORKAREA_Y = SEC_BEHAVIOR_Y + SEC_BEHAVIOR_H + SECTION_GAP;
    private static final int SEC_WORKAREA_H = ROW_FIRST + WORKAREA_ROWS * ROW_GAP + 4;

    /** 环境与作息：仅白天、仅晴天、疲劳收工 + 两个参数行 */
    private static final int ENV_ROWS = 5;
    private static final int SEC_ENV_Y = SEC_WORKAREA_Y + SEC_WORKAREA_H + SECTION_GAP;
    private static final int SEC_ENV_H = ROW_FIRST + ENV_ROWS * ROW_GAP + 4;

    /**
     * 生存自保（C 组）：危险撤退（开关 + 血量 + 距离）、受击反制（开关 + 时长）、
     * 环境自救（开关）、掉线重连（开关 + 延迟 + 次数）—— 共 9 行。
     */
    private static final int SURVIVAL_ROWS = 9;
    private static final int SEC_SURVIVAL_Y = SEC_ENV_Y + SEC_ENV_H + SECTION_GAP;
    private static final int SEC_SURVIVAL_H = ROW_FIRST + SURVIVAL_ROWS * ROW_GAP + 4;

    private static final int TOOL_ROWS = 2;
    private static final int SEC_TOOL_Y = SEC_SURVIVAL_Y + SEC_SURVIVAL_H + SECTION_GAP;
    private static final int SEC_TOOL_H = ROW_FIRST + TOOL_ROWS * ROW_GAP + 4;

    private static final int MISC_ROWS = 3;
    private static final int SEC_MISC_Y = SEC_TOOL_Y + SEC_TOOL_H + SECTION_GAP;
    private static final int SEC_MISC_H = ROW_FIRST + MISC_ROWS * ROW_GAP + 4;

    private static final int PICKUP_ROWS = 2;
    private static final int SEC_PICKUP_Y = SEC_MISC_Y + SEC_MISC_H + SECTION_GAP;
    private static final int SEC_PICKUP_H = ROW_FIRST + PICKUP_ROWS * ROW_GAP + 4;

    /**
     * 瓜类与自定义作物：瓜茎识别开关、添加注视方块、自定义方块列表 —— 3 行控件，
     * 最后一行留给一句「非矿透」的自绘说明（见 renderContent）。
     */
    private static final int GOURD_ROWS = 4;
    private static final int SEC_GOURD_Y = SEC_PICKUP_Y + SEC_PICKUP_H + SECTION_GAP;
    private static final int SEC_GOURD_H = ROW_FIRST + GOURD_ROWS * ROW_GAP + 4;

    /**
     * 资源自给（D 组）：骨粉催熟（开关 + 单株上限）、耗材自给（开关 + 骨粉下限）、
     * 备用工具自给（开关）—— 共 5 行。两个参数行都是各自开关的子项，靠
     * {@link #relayout()} 里的 visible 切换。
     */
    private static final int SUPPLY_ROWS = 5;
    private static final int SEC_SUPPLY_Y = SEC_GOURD_Y + SEC_GOURD_H + SECTION_GAP;
    private static final int SEC_SUPPLY_H = ROW_FIRST + SUPPLY_ROWS * ROW_GAP + 4;

    /** 最底下那句「默认全关」的总说明 */
    private static final int NOTE_Y = SEC_SUPPLY_Y + SEC_SUPPLY_H + 8;
    private static final int NOTE_H = 24;

    // ---------------- 循环档位（都含出厂默认值，见 AutoFarmConfig） ----------------
    private static final int[] RADIUS_CHOICES = {8, 12, 16, 24, 32};
    private static final int[] REST_INTERVAL_CHOICES = {5, 10, 15, 20, 30};
    private static final int[] REST_DURATION_CHOICES = {10, 20, 30, 60};
    private static final int[] DURABILITY_CHOICES = {5, 10, 15, 20, 30};
    private static final int[] COOLDOWN_CHOICES = {5, 10, 15, 30, 60};
    private static final int[] PICKUP_DELAY_CHOICES = {1, 2, 3, 5};
    /** 战斗：攻击距离（格）。超过原版 3.0 的档位要先过风险确认屏才生效 */
    private static final double[] ATTACK_RANGE_CHOICES = {2.5, 2.9, 3.5, 4.5, 6.0};
    /** 战斗：暴力程度档位（和 AutoFarmConfig 的 VIOLENCE_* 常量一致） */
    private static final int[] VIOLENCE_CHOICES = {0, 1, 2};
    /** 防踢档位：0 = 关闭、1 = 轻度、2 = 中度、3 = 强力（和 Humanizer 的常量一致） */
    private static final int[] ANTIKICK_LEVEL_CHOICES = {0, 1, 2, 3};
    /** 行为真实感：反应延迟时长（tick，1 秒 = 20 tick） */
    private static final int[] REACTION_CHOICES = {4, 10, 20, 30};
    /** 工作时段：0~23 整点（循环按钮在这 24 档之间轮换） */
    private static final int[] HOUR_CHOICES = buildHours();
    /** 工作范围：范围方式的档位（0 = 圆形、1 = 两点矩形，和 AutoFarmConfig 的常量一致） */
    private static final int[] AREA_MODE_CHOICES = {0, 1};
    /** 工作范围：半径档位（格） */
    private static final int[] WORK_AREA_RADIUS_CHOICES = {8, 12, 16, 24, 32, 48};
    /** 疲劳收工：连续工作上限的档位（分钟） */
    private static final int[] FATIGUE_WORK_CHOICES = {15, 30, 60, 120, 240};
    /** 疲劳收工：休息时长的档位（分钟）；0 = 手动恢复 */
    private static final int[] FATIGUE_REST_CHOICES = {0, 5, 10, 15, 30, 60};
    /** 生存自保：撤退血量门槛（心） */
    private static final int[] RETREAT_HEALTH_CHOICES = {3, 4, 5, 6, 8, 10};
    /** 生存自保：撤退距离（格） */
    private static final int[] RETREAT_DISTANCE_CHOICES = {8, 12, 16, 24, 32};
    /** 生存自保：受击反制时长（秒） */
    private static final int[] HIT_REACTION_CHOICES = {1, 2, 3, 5};
    /** 生存自保：掉线后重连延迟（秒） */
    private static final int[] RECONNECT_DELAY_CHOICES = {5, 10, 20, 30, 60};
    /** 生存自保：最多重连次数；0 = 不限 */
    private static final int[] RECONNECT_ATTEMPT_CHOICES = {0, 3, 5, 10, 20};
    /** 资源自给：同一株作物最多撒几次骨粉 */
    private static final int[] BONE_MEAL_LIMIT_CHOICES = {1, 2, 4, 6, 10};
    /** 资源自给：骨粉少于多少个就去补给点补一趟 */
    private static final int[] BONE_MEAL_THRESHOLD_CHOICES = {8, 16, 32, 64};

    private static int[] buildHours() {
        int[] hours = new int[24];
        for (int i = 0; i < hours.length; i++) {
            hours[i] = i;
        }
        return hours;
    }

    private final AutoFarmConfig draft;
    /** 进来时的快照，「取消」时用它还原附加功能这几项 */
    private final AutoFarmConfig old;

    private class_4185 combatButton;
    private class_342 attackIntervalField;
    private class_4185 attackRangeButton;
    private class_4185 attackTargetButton;
    private class_4185 violentButton;
    private class_4185 violenceLevelButton;
    private class_4185 pausePlayerButton;
    private class_4185 radiusButton;
    private class_4185 humanizeButton;
    private class_4185 randomRestButton;
    private class_4185 restIntervalButton;
    private class_4185 restDurationButton;
    private class_4185 replaceToolButton;
    private class_4185 durabilityButton;
    private class_4185 failureCooldownButton;
    private class_4185 cooldownButton;
    private class_4185 verboseHudButton;
    private class_4185 pickupDropsButton;
    private class_4185 pickupDelayButton;
    private class_4185 antiKickButton;
    private class_4185 antiKickLevelButton;
    private class_4185 reactionDelayButton;
    private class_4185 reactionTimeButton;
    private class_4185 idleLookButton;
    private class_4185 scheduleButton;
    private class_4185 scheduleStartButton;
    private class_4185 scheduleEndButton;
    private class_4185 workAreaButton;
    private class_4185 workAreaModeButton;
    private class_4185 workAreaRadiusButton;
    private class_4185 workAreaCenterButton;
    private class_4185 workAreaCornerAButton;
    private class_4185 workAreaCornerBButton;
    private class_4185 daylightButton;
    private class_4185 weatherButton;
    private class_4185 fatigueButton;
    private class_4185 fatigueWorkButton;
    private class_4185 fatigueRestButton;
    private class_4185 retreatButton;
    private class_4185 retreatHealthButton;
    private class_4185 retreatDistanceButton;
    private class_4185 hitReactionButton;
    private class_4185 hitReactionTimeButton;
    private class_4185 selfRescueButton;
    private class_4185 reconnectButton;
    private class_4185 reconnectDelayButton;
    private class_4185 reconnectAttemptsButton;
    private class_4185 melonHarvestButton;
    private class_4185 addCustomBlockButton;
    private class_4185 customBlocksButton;
    private class_4185 boneMealBoostButton;
    private class_4185 boneMealLimitButton;
    private class_4185 autoSuppliesButton;
    private class_4185 boneMealThresholdButton;
    private class_4185 autoFetchToolButton;

    public ExtrasScreen(class_437 parent, AutoFarmConfig sharedDraft) {
        super(parent, class_2561.method_43471("autofarm.extras.title"));
        this.draft = sharedDraft;
        this.old = sharedDraft.copy();
    }

    @Override
    protected int contentHeight() {
        return NOTE_Y + NOTE_H;
    }

    // ================= 建控件 =================

    @Override
    protected void buildContent() {
        int fullW = contentWidth;
        int subX = contentX + INDENT;
        int subW = contentWidth - INDENT;

        // ---- 战斗（高风险）----
        // 全模组唯一会「替玩家出手攻击」的一组，所以从里到外都跟别的分区不一样：
        // 标题和开关文字标红、打开要先过一道风险确认屏、暴力模式还要等主子项开了才出现。

        this.combatButton = dangerToggle("autofarm.option.auto_attack",
                draft.autoAttack, value -> draft.autoAttack = value,
                "autofarm.auto_attack.tip");
        layout(combatButton, contentX, 0, fullW);

        // 攻击间隔：一个填空（不是循环按钮）。选项名画在左边，输入框摆中间，
        // 右边留给「范围 50–5000 毫秒」那段提示 —— 见 drawCombatExtras。
        this.attackIntervalField = intervalField(contentX + INTERVAL_LABEL_W);
        addScrolling(attackIntervalField);

        // 攻击距离：循环按钮，但超过原版 3.0 的档位要先过风险确认屏（onRangeClicked）
        this.attackRangeButton = class_4185.method_46430(attackRangeLabel(), b -> onRangeClicked())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        attackRangeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_range.tip")));
        addScrolling(attackRangeButton);

        this.attackTargetButton = class_4185.method_46430(attackTargetLabel(), b -> {
            draft.attackHostileOnly = !draft.attackHostileOnly;
            b.method_25355(attackTargetLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        attackTargetButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_target.tip")));
        addScrolling(attackTargetButton);

        // 二级开关：主子项关着时它整个不显示（原位留一行灰字），打开之后才「弹」出来
        this.violentButton = dangerToggle("autofarm.option.auto_attack_violent",
                draft.autoAttackViolent, value -> draft.autoAttackViolent = value,
                "autofarm.auto_attack_violent.tip");
        layout(violentButton, subX, 0, subW);

        // 二级参数：暴力程度。只在「暴力模式」打开后才出现，提高档位要过确认屏
        this.violenceLevelButton = class_4185.method_46430(violenceLabel(), b -> onViolenceClicked())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        violenceLevelButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_violence.tip")));
        addScrolling(violenceLevelButton);

        // ---- 安全与隐蔽 ----

        this.pausePlayerButton = toggle("autofarm.option.pause_player",
                draft.pauseWhenPlayerNear, value -> draft.pauseWhenPlayerNear = value,
                "autofarm.pause_player.tip");
        layout(pausePlayerButton, contentX, 0, fullW);

        this.radiusButton = class_4185.method_46430(radiusLabel(), b -> {
            draft.playerNearRadius = nextChoice(RADIUS_CHOICES, draft.playerNearRadius);
            b.method_25355(radiusLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        radiusButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.value_radius.tip")));
        addScrolling(radiusButton);

        this.humanizeButton = toggle("autofarm.option.humanize",
                draft.humanizeTiming, value -> draft.humanizeTiming = value,
                "autofarm.humanize.tip");
        layout(humanizeButton, contentX, 0, fullW);

        this.randomRestButton = toggle("autofarm.option.random_rest",
                draft.randomRest, value -> draft.randomRest = value,
                "autofarm.random_rest.tip");
        layout(randomRestButton, contentX, 0, fullW);

        this.restIntervalButton = class_4185.method_46430(restIntervalLabel(), b -> {
            draft.restIntervalMinutes = nextChoice(REST_INTERVAL_CHOICES, draft.restIntervalMinutes);
            b.method_25355(restIntervalLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        restIntervalButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.rest_interval.tip")));
        addScrolling(restIntervalButton);

        this.restDurationButton = class_4185.method_46430(restDurationLabel(), b -> {
            draft.restDurationSeconds = nextChoice(REST_DURATION_CHOICES, draft.restDurationSeconds);
            b.method_25355(restDurationLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        restDurationButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.rest_duration.tip")));
        addScrolling(restDurationButton);

        // ---- 防踢模式 ----

        this.antiKickButton = toggle("autofarm.option.antikick",
                draft.antiKickMode, value -> draft.antiKickMode = value,
                "autofarm.antikick.tip");
        layout(antiKickButton, contentX, 0, fullW);

        this.antiKickLevelButton = class_4185.method_46430(antiKickLevelLabel(), b -> {
            draft.antiKickLevel = nextChoice(ANTIKICK_LEVEL_CHOICES, draft.antiKickLevel);
            b.method_25355(antiKickLevelLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        antiKickLevelButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.antikick_level.tip")));
        addScrolling(antiKickLevelButton);

        // ---- 行为真实感 ----

        this.reactionDelayButton = toggle("autofarm.option.reaction_delay",
                draft.reactionDelay, value -> draft.reactionDelay = value,
                "autofarm.reaction_delay.tip");
        layout(reactionDelayButton, contentX, 0, fullW);

        this.reactionTimeButton = class_4185.method_46430(reactionTimeLabel(), b -> {
            draft.reactionDelayTicks = nextChoice(REACTION_CHOICES, draft.reactionDelayTicks);
            b.method_25355(reactionTimeLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        reactionTimeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.reaction_time.tip")));
        addScrolling(reactionTimeButton);

        this.idleLookButton = toggle("autofarm.option.idle_look",
                draft.idleLookAround, value -> draft.idleLookAround = value,
                "autofarm.idle_look.tip");
        layout(idleLookButton, contentX, 0, fullW);

        this.scheduleButton = toggle("autofarm.option.schedule",
                draft.scheduleEnabled, value -> draft.scheduleEnabled = value,
                "autofarm.schedule.tip");
        layout(scheduleButton, contentX, 0, fullW);

        this.scheduleStartButton = class_4185.method_46430(scheduleStartLabel(), b -> {
            draft.scheduleStartHour = nextChoice(HOUR_CHOICES, draft.scheduleStartHour);
            b.method_25355(scheduleStartLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        scheduleStartButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.schedule_start.tip")));
        addScrolling(scheduleStartButton);

        this.scheduleEndButton = class_4185.method_46430(scheduleEndLabel(), b -> {
            draft.scheduleEndHour = nextChoice(HOUR_CHOICES, draft.scheduleEndHour);
            b.method_25355(scheduleEndLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        scheduleEndButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.schedule_end.tip")));
        addScrolling(scheduleEndButton);

        // ---- 工作范围 ----
        // 两种圈法：圆形（中心 + 半径）和两点矩形（角点 A + 角点 B）。
        // 两种方式的参数行共用同样两行，靠 relayout() 里的 visible 切换 ——
        // 这样分区的行数不随方式变，滚动手感稳定。

        this.workAreaButton = toggle("autofarm.option.work_area",
                draft.workAreaEnabled, value -> draft.workAreaEnabled = value,
                "autofarm.work_area.tip");
        layout(workAreaButton, contentX, 0, fullW);

        this.workAreaModeButton = class_4185.method_46430(workAreaModeLabel(), b -> {
            draft.workAreaMode = nextChoice(AREA_MODE_CHOICES, draft.workAreaMode);
            // 换方式要重建整页：半径行和角点行的显隐跟着变，标签也得重算
            rebuild();
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaModeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area_mode.tip")));
        addScrolling(workAreaModeButton);

        this.workAreaRadiusButton = class_4185.method_46430(workAreaRadiusLabel(), b -> {
            draft.workAreaRadius = nextChoice(WORK_AREA_RADIUS_CHOICES, draft.workAreaRadius);
            b.method_25355(workAreaRadiusLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaRadiusButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area_radius.tip")));
        addScrolling(workAreaRadiusButton);

        this.workAreaCenterButton = class_4185.method_46430(workAreaCenterLabel(), b -> {
            recordCurrentPos(false);
            b.method_25355(workAreaCenterLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaCenterButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area.record.tip")));
        addScrolling(workAreaCenterButton);

        this.workAreaCornerAButton = class_4185.method_46430(workAreaCornerALabel(), b -> {
            recordCurrentPos(false);
            b.method_25355(workAreaCornerALabel());
            if (workAreaCornerBButton != null) {
                workAreaCornerBButton.method_25355(workAreaCornerBLabel());
            }
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaCornerAButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area.corner_a.tip")));
        addScrolling(workAreaCornerAButton);

        this.workAreaCornerBButton = class_4185.method_46430(workAreaCornerBLabel(), b -> {
            recordCurrentPos(true);
            b.method_25355(workAreaCornerBLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        workAreaCornerBButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.work_area.corner_b.tip")));
        addScrolling(workAreaCornerBButton);

        // ---- 环境与作息 ----

        this.daylightButton = toggle("autofarm.option.daylight",
                draft.workDaylightOnly, value -> draft.workDaylightOnly = value,
                "autofarm.daylight.tip");
        layout(daylightButton, contentX, 0, fullW);

        this.weatherButton = toggle("autofarm.option.clear_weather",
                draft.workClearWeatherOnly, value -> draft.workClearWeatherOnly = value,
                "autofarm.clear_weather.tip");
        layout(weatherButton, contentX, 0, fullW);

        this.fatigueButton = toggle("autofarm.option.fatigue",
                draft.fatigueStop, value -> draft.fatigueStop = value,
                "autofarm.fatigue.tip");
        layout(fatigueButton, contentX, 0, fullW);

        this.fatigueWorkButton = class_4185.method_46430(fatigueWorkLabel(), b -> {
            draft.fatigueWorkMinutes = nextChoice(FATIGUE_WORK_CHOICES, draft.fatigueWorkMinutes);
            b.method_25355(fatigueWorkLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        fatigueWorkButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.fatigue_work.tip")));
        addScrolling(fatigueWorkButton);

        this.fatigueRestButton = class_4185.method_46430(fatigueRestLabel(), b -> {
            draft.fatigueRestMinutes = nextChoice(FATIGUE_REST_CHOICES, draft.fatigueRestMinutes);
            b.method_25355(fatigueRestLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        fatigueRestButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.fatigue_rest.tip")));
        addScrolling(fatigueRestButton);

        // ---- 生存自保（C 组）----
        // 这一组管的是「别把号玩没了」：危险撤退、受击反制、环境自救、掉线重连。

        this.retreatButton = toggle("autofarm.option.retreat",
                draft.retreatEnabled, value -> draft.retreatEnabled = value,
                "autofarm.retreat.tip");
        layout(retreatButton, contentX, 0, fullW);

        this.retreatHealthButton = class_4185.method_46430(retreatHealthLabel(), b -> {
            draft.retreatHealthHearts = nextChoice(RETREAT_HEALTH_CHOICES, draft.retreatHealthHearts);
            b.method_25355(retreatHealthLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        retreatHealthButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.retreat_health.tip")));
        addScrolling(retreatHealthButton);

        this.retreatDistanceButton = class_4185.method_46430(retreatDistanceLabel(), b -> {
            draft.retreatDistance = nextChoice(RETREAT_DISTANCE_CHOICES, draft.retreatDistance);
            b.method_25355(retreatDistanceLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        retreatDistanceButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.retreat_distance.tip")));
        addScrolling(retreatDistanceButton);

        this.hitReactionButton = toggle("autofarm.option.hit_reaction",
                draft.hitReactionEnabled, value -> draft.hitReactionEnabled = value,
                "autofarm.hit_reaction.tip");
        layout(hitReactionButton, contentX, 0, fullW);

        this.hitReactionTimeButton = class_4185.method_46430(hitReactionTimeLabel(), b -> {
            draft.hitReactionSeconds = nextChoice(HIT_REACTION_CHOICES, draft.hitReactionSeconds);
            b.method_25355(hitReactionTimeLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        hitReactionTimeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.hit_reaction_time.tip")));
        addScrolling(hitReactionTimeButton);

        this.selfRescueButton = toggle("autofarm.option.self_rescue",
                draft.selfRescueEnabled, value -> draft.selfRescueEnabled = value,
                "autofarm.self_rescue.tip");
        layout(selfRescueButton, contentX, 0, fullW);

        this.reconnectButton = toggle("autofarm.option.auto_reconnect",
                draft.autoReconnectEnabled, value -> draft.autoReconnectEnabled = value,
                "autofarm.auto_reconnect.tip");
        layout(reconnectButton, contentX, 0, fullW);

        this.reconnectDelayButton = class_4185.method_46430(reconnectDelayLabel(), b -> {
            draft.reconnectDelaySeconds = nextChoice(RECONNECT_DELAY_CHOICES, draft.reconnectDelaySeconds);
            b.method_25355(reconnectDelayLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        reconnectDelayButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.reconnect_delay.tip")));
        addScrolling(reconnectDelayButton);

        this.reconnectAttemptsButton = class_4185.method_46430(reconnectAttemptsLabel(), b -> {
            draft.reconnectMaxAttempts = nextChoice(RECONNECT_ATTEMPT_CHOICES, draft.reconnectMaxAttempts);
            b.method_25355(reconnectAttemptsLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        reconnectAttemptsButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.reconnect_attempts.tip")));
        addScrolling(reconnectAttemptsButton);

        // ---- 工具维护 ----

        this.replaceToolButton = toggle("autofarm.option.replace_tool",
                draft.autoReplaceTool, value -> draft.autoReplaceTool = value,
                "autofarm.replace_tool.tip");
        layout(replaceToolButton, contentX, 0, fullW);

        this.durabilityButton = class_4185.method_46430(durabilityLabel(), b -> {
            draft.toolDurabilityPercent = nextChoice(DURABILITY_CHOICES, draft.toolDurabilityPercent);
            b.method_25355(durabilityLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        durabilityButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.durability.tip")));
        addScrolling(durabilityButton);

        // ---- 容错与统计 ----

        this.failureCooldownButton = toggle("autofarm.option.failure_cooldown",
                draft.failureCooldown, value -> draft.failureCooldown = value,
                "autofarm.failure_cooldown.tip");
        layout(failureCooldownButton, contentX, 0, fullW);

        this.cooldownButton = class_4185.method_46430(cooldownLabel(), b -> {
            draft.failureCooldownSeconds = nextChoice(COOLDOWN_CHOICES, draft.failureCooldownSeconds);
            b.method_25355(cooldownLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        cooldownButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.cooldown.tip")));
        addScrolling(cooldownButton);

        this.verboseHudButton = toggle("autofarm.option.verbose_hud",
                draft.verboseHud, value -> draft.verboseHud = value,
                "autofarm.verbose_hud.tip");
        layout(verboseHudButton, contentX, 0, fullW);

        // ---- 掉落物 ----

        this.pickupDropsButton = toggle("autofarm.option.pickup_drops",
                draft.pickupDroppedItems, value -> draft.pickupDroppedItems = value,
                "autofarm.pickup_drops.tip");
        layout(pickupDropsButton, contentX, 0, fullW);

        this.pickupDelayButton = class_4185.method_46430(pickupDelayLabel(), b -> {
            draft.pickupDelaySeconds = nextChoice(PICKUP_DELAY_CHOICES, draft.pickupDelaySeconds);
            b.method_25355(pickupDelayLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        pickupDelayButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.pickup_delay.tip")));
        addScrolling(pickupDelayButton);

        // ---- 瓜类与自定义作物 ----
        // 瓜茎识别单独一个开关；自定义方块是「名单非空即生效」，没有布尔开关。
        // 「添加」要过一道提醒屏（别加非作物方块、本功能不是矿透）。

        this.melonHarvestButton = toggle("autofarm.option.melon_harvest",
                draft.melonHarvest, value -> draft.melonHarvest = value,
                "autofarm.melon_harvest.tip");
        layout(melonHarvestButton, contentX, 0, fullW);

        this.addCustomBlockButton = class_4185.method_46430(
                        class_2561.method_43471("autofarm.option.add_custom_block"),
                        b -> addLookedBlock())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        addCustomBlockButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.add_custom_block.tip")));
        addScrolling(addCustomBlockButton);

        this.customBlocksButton = class_4185.method_46430(customBlocksLabel(), b -> clearCustomBlocks())
                .method_46434(subX, 0, subW, ROW_H).method_46431();
        customBlocksButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.custom_blocks.tip")));
        addScrolling(customBlocksButton);

        // ---- 资源自给 ----
        // 让模组把骨粉、备用工具这两样也自己接上：骨粉催熟 / 耗材自给 / 备用工具自给。
        // 两个参数行分别是各自开关的子项，靠 relayout() 切换显隐。

        this.boneMealBoostButton = toggle("autofarm.option.bone_meal",
                draft.boneMealBoost, value -> draft.boneMealBoost = value,
                "autofarm.bone_meal.tip");
        layout(boneMealBoostButton, contentX, 0, fullW);

        this.boneMealLimitButton = class_4185.method_46430(boneMealLimitLabel(), b -> {
            draft.boneMealLimit = nextChoice(BONE_MEAL_LIMIT_CHOICES, draft.boneMealLimit);
            b.method_25355(boneMealLimitLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        boneMealLimitButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.bone_meal_limit.tip")));
        addScrolling(boneMealLimitButton);

        this.autoSuppliesButton = toggle("autofarm.option.auto_supplies",
                draft.autoFetchSupplies, value -> draft.autoFetchSupplies = value,
                "autofarm.auto_supplies.tip");
        layout(autoSuppliesButton, contentX, 0, fullW);

        this.boneMealThresholdButton = class_4185.method_46430(boneMealThresholdLabel(), b -> {
            draft.boneMealThreshold = nextChoice(BONE_MEAL_THRESHOLD_CHOICES, draft.boneMealThreshold);
            b.method_25355(boneMealThresholdLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        boneMealThresholdButton.method_47400(class_7919.method_47407(
                class_2561.method_43471("autofarm.bone_meal_threshold.tip")));
        addScrolling(boneMealThresholdButton);

        this.autoFetchToolButton = toggle("autofarm.option.auto_fetch_tool",
                draft.autoFetchTool, value -> draft.autoFetchTool = value,
                "autofarm.auto_fetch_tool.tip");
        layout(autoFetchToolButton, contentX, 0, fullW);

        // ---- 页脚 ----
        int btnW = (contentWidth - 8) / 3;
        addFooter(
                class_4185.method_46430(class_2561.method_43471("autofarm.extras.reset"), b -> resetAllOff())
                        .method_46434(contentX, 0, btnW, ROW_H).method_46431(),
                class_4185.method_46430(class_2561.method_43471("autofarm.button.cancel"), b -> onCancel())
                        .method_46434(contentX + btnW + 4, 0, btnW, ROW_H).method_46431(),
                class_4185.method_46430(class_2561.method_43471("autofarm.highlight.done"), b -> backToParent())
                        .method_46434(contentX + 2 * (btnW + 4), 0, btnW, ROW_H).method_46431()
        );
    }

    /** 一个开关按钮的样板：点一下翻转，标签跟着变 */
    private class_4185 toggle(String optionKey, boolean value,
                                java.util.function.Consumer<Boolean> setter, String tipKey) {
        class_4185 button = class_4185.method_46430(toggleLabel(optionKey, value), b -> {
            boolean next = !currentToggle(optionKey);
            setter.accept(next);
            b.method_25355(toggleLabel(optionKey, next));
        }).method_46434(contentX, 0, contentWidth, ROW_H).method_46431();
        button.method_47400(class_7919.method_47407(class_2561.method_43471(tipKey)));
        return button;
    }

    /**
     * 高风险开关：文字标红，而且「打开」这一步被拆成两次 ——
     * 点开关只负责弹风险确认屏，真正写回草稿要等那边点过「确认」。
     * 「关闭」不设门槛：关掉一个危险功能不需要再被劝一次。
     */
    private class_4185 dangerToggle(String optionKey, boolean value,
                                      java.util.function.Consumer<Boolean> setter, String tipKey) {
        class_4185 button = class_4185.method_46430(dangerLabel(optionKey, value), b -> {
            if (currentToggle(optionKey)) {
                setter.accept(false);
                // 自动打怪关掉时，它的二级项（暴力模式 / 暴力程度）也一并收掉，
                // 免得留下一个「主子项关着、暴力标记还亮着」的状态
                if ("autofarm.option.auto_attack".equals(optionKey)) {
                    draft.autoAttackViolent = false;
                    draft.attackViolence = AutoFarmConfig.VIOLENCE_LIGHT;
                }
                b.method_25355(dangerLabel(optionKey, false));
                return;
            }
            // 「自动打怪」不能脱离「自动收割」总开关单独开启 —— 否则就成了纯粹的作弊，
            // 与这个模组的定位不符（关掉则永远允许，不设门槛）。
            if ("autofarm.option.auto_attack".equals(optionKey) && !draft.enabled) {
                toast("autofarm.combat.warn.master_off");
                return;
            }
            // 打开：先不落实，交给确认屏；确认之后那边会重建这一页
            openDangerConfirm(setter);
        }).method_46434(contentX, 0, contentWidth, ROW_H).method_46431();
        button.method_47400(class_7919.method_47407(class_2561.method_43471(tipKey)));
        return button;
    }

    /** 攻击间隔的填空：只收数字，改动实时写进草稿，越界由 clamp() 兜底 */
    private class_342 intervalField(int x) {
        class_342 field = new class_342(this.field_22793, x, 0,
                INTERVAL_FIELD_W, ROW_H, class_2561.method_43473());
        field.method_1880(4);
        field.method_1890(s -> s.isEmpty() || s.matches("\\d{1,4}"));
        field.method_1852(Integer.toString(draft.attackIntervalMs));
        field.method_1863(text -> {
            if (text == null || text.isEmpty()) {
                return; // 清空时保持原值，等下一个合法数字
            }
            try {
                draft.attackIntervalMs = Integer.parseInt(text);
            } catch (NumberFormatException ignored) {
                // 理论上进不来（上面已经限定了只收数字），保险起见吞掉
            }
        });
        field.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_interval.tip")));
        return field;
    }

    /** 攻击距离：循环下一档；超过原版交互距离时先弹风险确认屏，确认后才写回 */
    private void onRangeClicked() {
        double next = nextChoice(ATTACK_RANGE_CHOICES, draft.attackRange);
        if (next > AutoFarmConfig.ATTACK_RANGE_VANILLA) {
            confirmThen("autofarm.danger.range.subtitle", () -> {
                draft.attackRange = next;
                rebuild();
            }, "autofarm.danger.range.body1", "autofarm.danger.range.body2");
            return;
        }
        draft.attackRange = next;
        attackRangeButton.method_25355(attackRangeLabel());
    }

    /** 暴力程度：循环下一档；提高档位时先弹确认屏（降低不需要） */
    private void onViolenceClicked() {
        int next = nextChoice(VIOLENCE_CHOICES, draft.attackViolence);
        if (next > draft.attackViolence) {
            confirmThen("autofarm.danger.violence.subtitle", () -> {
                draft.attackViolence = next;
                rebuild();
            }, "autofarm.danger.violence.body1", "autofarm.danger.violence.body2");
            return;
        }
        draft.attackViolence = next;
        violenceLevelButton.method_25355(violenceLabel());
    }

    /** 弹一块自定义文案的风险确认屏；点确认后执行 apply（通常顺带重建本页） */
    private void confirmThen(String subtitleKey, Runnable apply, String... bodyKeys) {
        if (this.field_22787 == null) {
            return;
        }
        this.field_22787.method_1507(new DangerConfirmScreen(this, apply,
                "autofarm.danger.title", subtitleKey, bodyKeys));
    }

    /** 重建本页（草稿原样带过去）。用于标签文字变了、或者某几行要显隐切换的时候 */
    private void rebuild() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(new ExtrasScreen(this.parent, draft));
        }
    }

    /**
     * 战斗分区底部的警示行（最多显示两条）。
     *
     * <p>三条触发条件：总开关没开（这时打怪根本不会生效）、出手间隔过低、
     * 攻击距离超过原版。它们都画成红色，作为「风险确认屏」之外的持续提醒 ——
     * 确认屏只在你动手改参数时出现，而这几行只要参数处在危险区间就一直亮着。
     */
    private List<class_2561> combatWarnings() {
        List<class_2561> out = new ArrayList<>();
        if (!draft.enabled) {
            out.add(class_2561.method_43471("autofarm.combat.warn.master_off"));
        }
        if (draft.autoAttack) {
            if (draft.attackIntervalMs < AutoFarmConfig.ATTACK_INTERVAL_SAFE_MS) {
                out.add(class_2561.method_43471("autofarm.combat.warn.interval_low"));
            }
            if (draft.attackRange > AutoFarmConfig.ATTACK_RANGE_VANILLA) {
                out.add(class_2561.method_43471("autofarm.combat.warn.range_far"));
            }
        }
        return out;
    }

    /** 弹出风险确认屏；确认后写回草稿并重建本页（暴力行的显隐要跟着变） */
    private void openDangerConfirm(java.util.function.Consumer<Boolean> setter) {
        if (this.field_22787 == null) {
            return;
        }
        this.field_22787.method_1507(new DangerConfirmScreen(this, () -> {
            setter.accept(true);
            this.field_22787.method_1507(new ExtrasScreen(this.parent, draft));
        }));
    }

    /** 高风险分区的小标题：用警示色而不是通用标题色 */
    private void drawDangerHeader(class_332 context, int originY, int relY) {
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.extras.section.combat"),
                contentX + 6, originY + relY + 4, COLOR_DANGER);
    }

    /**
     * 战斗分区里那几段「不属于按钮」的自绘内容：
     * 攻击间隔左侧的选项名与右侧的范围提示、暴力行未解锁时的灰字、
     * 以及底部的红色警示行。
     */
    private void drawCombatExtras(class_332 context, int originY) {
        int combat = originY + SEC_COMBAT_Y;

        // 攻击间隔：左边写选项名（输入框摆在中段，见 buildContent），右边写范围提示
        int intervalRow = combat + ROW_FIRST + ROW_GAP;
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.option.attack_interval"),
                contentX + 4, intervalRow + 5, COLOR_DANGER);
        context.method_27535(this.field_22793,
                class_2561.method_43469("autofarm.attack_interval.hint",
                        AutoFarmConfig.ATTACK_INTERVAL_MIN_MS, AutoFarmConfig.ATTACK_INTERVAL_MAX_MS),
                contentX + INTERVAL_LABEL_W + INTERVAL_FIELD_W + 8, intervalRow + 5, COLOR_HINT);

        // 暴力开关 / 暴力程度没解锁：把接下来两行的位置留给一句灰字说明
        if (!draft.autoAttack) {
            context.method_27535(this.field_22793,
                    class_2561.method_43471("autofarm.extras.violent_locked"),
                    contentX + INDENT + 4, combat + ROW_FIRST + 4 * ROW_GAP + 5, COLOR_HINT);
        }

        // 底部警示：总开关没开 / 参数进入危险区间时标红（最多两条）
        List<class_2561> warnings = combatWarnings();
        int warnY = combat + ROW_FIRST + COMBAT_ROWS * ROW_GAP + 2;
        for (int i = 0; i < warnings.size() && i < 2; i++) {
            context.method_27535(this.field_22793, warnings.get(i),
                    contentX + 4, warnY + i * 11, COLOR_DANGER);
        }
    }

    /** 「选项：开/关」，但选项名染成红色 */
    private static class_2561 dangerLabel(String optionKey, boolean value) {
        return class_2561.method_43469("autofarm.toggle",
                class_2561.method_43471(optionKey).method_27692(class_124.field_1061),
                class_2561.method_43471(value ? "autofarm.on" : "autofarm.off"));
    }

    /** 从 draft 里读回当前开关值 —— 用来做「翻转」，保证和草稿永远一致 */
    private boolean currentToggle(String optionKey) {
        return switch (optionKey) {
            case "autofarm.option.auto_attack" -> draft.autoAttack;
            case "autofarm.option.auto_attack_violent" -> draft.autoAttackViolent;
            case "autofarm.option.pause_player" -> draft.pauseWhenPlayerNear;
            case "autofarm.option.humanize" -> draft.humanizeTiming;
            case "autofarm.option.random_rest" -> draft.randomRest;
            case "autofarm.option.replace_tool" -> draft.autoReplaceTool;
            case "autofarm.option.failure_cooldown" -> draft.failureCooldown;
            case "autofarm.option.verbose_hud" -> draft.verboseHud;
            case "autofarm.option.pickup_drops" -> draft.pickupDroppedItems;
            case "autofarm.option.antikick" -> draft.antiKickMode;
            case "autofarm.option.reaction_delay" -> draft.reactionDelay;
            case "autofarm.option.idle_look" -> draft.idleLookAround;
            case "autofarm.option.schedule" -> draft.scheduleEnabled;
            case "autofarm.option.work_area" -> draft.workAreaEnabled;
            case "autofarm.option.daylight" -> draft.workDaylightOnly;
            case "autofarm.option.clear_weather" -> draft.workClearWeatherOnly;
            case "autofarm.option.fatigue" -> draft.fatigueStop;
            case "autofarm.option.retreat" -> draft.retreatEnabled;
            case "autofarm.option.hit_reaction" -> draft.hitReactionEnabled;
            case "autofarm.option.self_rescue" -> draft.selfRescueEnabled;
            case "autofarm.option.auto_reconnect" -> draft.autoReconnectEnabled;
            case "autofarm.option.melon_harvest" -> draft.melonHarvest;
            case "autofarm.option.bone_meal" -> draft.boneMealBoost;
            case "autofarm.option.auto_supplies" -> draft.autoFetchSupplies;
            case "autofarm.option.auto_fetch_tool" -> draft.autoFetchTool;
            default -> false;
        };
    }

    private void layout(class_4185 widget, int x, int y, int width) {
        widget.method_46421(x);
        widget.method_46419(y);
        widget.method_25358(width);
        addScrolling(widget);
    }

    /**
     * 覆写：在通用的「滚出可视区就隐藏」之上，再叠一条本页自己的规则 ——
     * 暴力模式是二级开关，主子项关着时它整个不该出现（原位留一行灰字说明）。
     */
    @Override
    protected void relayout() {
        super.relayout();
        if (violentButton != null) {
            violentButton.field_22764 = violentButton.field_22764 && draft.autoAttack;
        }
        // 暴力程度是「暴力模式」的子项：暴力模式没开时它也不该出现
        if (violenceLevelButton != null) {
            violenceLevelButton.field_22764 = violenceLevelButton.field_22764
                    && draft.autoAttack && draft.autoAttackViolent;
        }
        // 工作范围的两种圈法共用同样两行：圆形显示「半径 / 记录中心」，
        // 矩形显示「记录角点 A / 记录角点 B」，同一时刻只让一套露出来
        boolean box = draft.workAreaMode == AutoFarmConfig.AREA_MODE_BOX;
        if (workAreaRadiusButton != null) {
            workAreaRadiusButton.field_22764 = workAreaRadiusButton.field_22764 && !box;
        }
        if (workAreaCenterButton != null) {
            workAreaCenterButton.field_22764 = workAreaCenterButton.field_22764 && !box;
        }
        if (workAreaCornerAButton != null) {
            workAreaCornerAButton.field_22764 = workAreaCornerAButton.field_22764 && box;
        }
        if (workAreaCornerBButton != null) {
            workAreaCornerBButton.field_22764 = workAreaCornerBButton.field_22764 && box;
        }
        // 资源自给的两个参数行同样是子项：主子项关着时它们不该出现
        if (boneMealLimitButton != null) {
            boneMealLimitButton.field_22764 = boneMealLimitButton.field_22764 && draft.boneMealBoost;
        }
        if (boneMealThresholdButton != null) {
            boneMealThresholdButton.field_22764 = boneMealThresholdButton.field_22764
                    && draft.autoFetchSupplies;
        }
    }

    @Override
    protected void positionContent(int originY) {
        int combat = originY + SEC_COMBAT_Y;
        setRowY(combatButton, combat + ROW_FIRST);
        setRowY(attackIntervalField, combat + ROW_FIRST + ROW_GAP);
        setRowY(attackRangeButton, combat + ROW_FIRST + 2 * ROW_GAP);
        setRowY(attackTargetButton, combat + ROW_FIRST + 3 * ROW_GAP);
        setRowY(violentButton, combat + ROW_FIRST + 4 * ROW_GAP);
        setRowY(violenceLevelButton, combat + ROW_FIRST + 5 * ROW_GAP);

        int stealth = originY + SEC_STEALTH_Y;
        setRowY(pausePlayerButton, stealth + ROW_FIRST);
        setRowY(radiusButton, stealth + ROW_FIRST + ROW_GAP);
        setRowY(humanizeButton, stealth + ROW_FIRST + 2 * ROW_GAP);
        setRowY(randomRestButton, stealth + ROW_FIRST + 3 * ROW_GAP);
        setRowY(restIntervalButton, stealth + ROW_FIRST + 4 * ROW_GAP);
        setRowY(restDurationButton, stealth + ROW_FIRST + 5 * ROW_GAP);

        int antiKick = originY + SEC_ANTIKICK_Y;
        setRowY(antiKickButton, antiKick + ROW_FIRST);
        setRowY(antiKickLevelButton, antiKick + ROW_FIRST + ROW_GAP);

        int behavior = originY + SEC_BEHAVIOR_Y;
        setRowY(reactionDelayButton, behavior + ROW_FIRST);
        setRowY(reactionTimeButton, behavior + ROW_FIRST + ROW_GAP);
        setRowY(idleLookButton, behavior + ROW_FIRST + 2 * ROW_GAP);
        setRowY(scheduleButton, behavior + ROW_FIRST + 3 * ROW_GAP);
        setRowY(scheduleStartButton, behavior + ROW_FIRST + 4 * ROW_GAP);
        setRowY(scheduleEndButton, behavior + ROW_FIRST + 5 * ROW_GAP);

        int work = originY + SEC_WORKAREA_Y;
        setRowY(workAreaButton, work + ROW_FIRST);
        setRowY(workAreaModeButton, work + ROW_FIRST + ROW_GAP);
        // 第 3 行：圆形 = 半径，矩形 = 角点 A（同一行，用 visible 二选一）
        setRowY(workAreaRadiusButton, work + ROW_FIRST + 2 * ROW_GAP);
        setRowY(workAreaCornerAButton, work + ROW_FIRST + 2 * ROW_GAP);
        // 第 4 行：圆形 = 记录中心，矩形 = 角点 B
        setRowY(workAreaCenterButton, work + ROW_FIRST + 3 * ROW_GAP);
        setRowY(workAreaCornerBButton, work + ROW_FIRST + 3 * ROW_GAP);

        int env = originY + SEC_ENV_Y;
        setRowY(daylightButton, env + ROW_FIRST);
        setRowY(weatherButton, env + ROW_FIRST + ROW_GAP);
        setRowY(fatigueButton, env + ROW_FIRST + 2 * ROW_GAP);
        setRowY(fatigueWorkButton, env + ROW_FIRST + 3 * ROW_GAP);
        setRowY(fatigueRestButton, env + ROW_FIRST + 4 * ROW_GAP);

        int survival = originY + SEC_SURVIVAL_Y;
        setRowY(retreatButton, survival + ROW_FIRST);
        setRowY(retreatHealthButton, survival + ROW_FIRST + ROW_GAP);
        setRowY(retreatDistanceButton, survival + ROW_FIRST + 2 * ROW_GAP);
        setRowY(hitReactionButton, survival + ROW_FIRST + 3 * ROW_GAP);
        setRowY(hitReactionTimeButton, survival + ROW_FIRST + 4 * ROW_GAP);
        setRowY(selfRescueButton, survival + ROW_FIRST + 5 * ROW_GAP);
        setRowY(reconnectButton, survival + ROW_FIRST + 6 * ROW_GAP);
        setRowY(reconnectDelayButton, survival + ROW_FIRST + 7 * ROW_GAP);
        setRowY(reconnectAttemptsButton, survival + ROW_FIRST + 8 * ROW_GAP);

        int tool = originY + SEC_TOOL_Y;
        setRowY(replaceToolButton, tool + ROW_FIRST);
        setRowY(durabilityButton, tool + ROW_FIRST + ROW_GAP);

        int misc = originY + SEC_MISC_Y;
        setRowY(failureCooldownButton, misc + ROW_FIRST);
        setRowY(cooldownButton, misc + ROW_FIRST + ROW_GAP);
        setRowY(verboseHudButton, misc + ROW_FIRST + 2 * ROW_GAP);

        int pickup = originY + SEC_PICKUP_Y;
        setRowY(pickupDropsButton, pickup + ROW_FIRST);
        setRowY(pickupDelayButton, pickup + ROW_FIRST + ROW_GAP);

        int gourd = originY + SEC_GOURD_Y;
        setRowY(melonHarvestButton, gourd + ROW_FIRST);
        setRowY(addCustomBlockButton, gourd + ROW_FIRST + ROW_GAP);
        setRowY(customBlocksButton, gourd + ROW_FIRST + 2 * ROW_GAP);

        int supply = originY + SEC_SUPPLY_Y;
        setRowY(boneMealBoostButton, supply + ROW_FIRST);
        setRowY(boneMealLimitButton, supply + ROW_FIRST + ROW_GAP);
        setRowY(autoSuppliesButton, supply + ROW_FIRST + 2 * ROW_GAP);
        setRowY(boneMealThresholdButton, supply + ROW_FIRST + 3 * ROW_GAP);
        setRowY(autoFetchToolButton, supply + ROW_FIRST + 4 * ROW_GAP);
    }

    // ================= 自绘 =================

    @Override
    protected void renderContent(class_332 context, int originY, int mouseX, int mouseY, float delta) {
        drawSection(context, originY, SEC_COMBAT_Y, SEC_COMBAT_H);
        drawDangerHeader(context, originY, SEC_COMBAT_Y);
        drawCombatExtras(context, originY);

        drawSection(context, originY, SEC_STEALTH_Y, SEC_STEALTH_H);
        drawHeader(context, originY, SEC_STEALTH_Y, "autofarm.extras.section.stealth");

        drawSection(context, originY, SEC_ANTIKICK_Y, SEC_ANTIKICK_H);
        drawHeader(context, originY, SEC_ANTIKICK_Y, "autofarm.extras.section.antikick");

        drawSection(context, originY, SEC_BEHAVIOR_Y, SEC_BEHAVIOR_H);
        drawHeader(context, originY, SEC_BEHAVIOR_Y, "autofarm.extras.section.behavior");

        drawSection(context, originY, SEC_WORKAREA_Y, SEC_WORKAREA_H);
        drawHeader(context, originY, SEC_WORKAREA_Y, "autofarm.extras.section.workarea");
        // 最后一行自绘一句说明：区域外的目标不收、人走出去会自动返回
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.work_area.hint"),
                contentX + INDENT + 4, originY + SEC_WORKAREA_Y + ROW_FIRST + 4 * ROW_GAP + 5, COLOR_HINT);

        drawSection(context, originY, SEC_ENV_Y, SEC_ENV_H);
        drawHeader(context, originY, SEC_ENV_Y, "autofarm.extras.section.environment");

        drawSection(context, originY, SEC_SURVIVAL_Y, SEC_SURVIVAL_H);
        drawHeader(context, originY, SEC_SURVIVAL_Y, "autofarm.extras.section.survival");

        drawSection(context, originY, SEC_TOOL_Y, SEC_TOOL_H);
        drawHeader(context, originY, SEC_TOOL_Y, "autofarm.extras.section.tool");

        drawSection(context, originY, SEC_MISC_Y, SEC_MISC_H);
        drawHeader(context, originY, SEC_MISC_Y, "autofarm.extras.section.misc");

        drawSection(context, originY, SEC_PICKUP_Y, SEC_PICKUP_H);
        drawHeader(context, originY, SEC_PICKUP_Y, "autofarm.extras.section.pickup");

        drawSection(context, originY, SEC_GOURD_Y, SEC_GOURD_H);
        drawHeader(context, originY, SEC_GOURD_Y, "autofarm.extras.section.gourd");
        // 最后一行自绘一句说明：只认茎旁的瓜和手动添加的方块，不是透视矿物的矿透
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.gourd.hint"),
                contentX + INDENT + 4, originY + SEC_GOURD_Y + ROW_FIRST + 3 * ROW_GAP + 5, COLOR_HINT);

        drawSection(context, originY, SEC_SUPPLY_Y, SEC_SUPPLY_H);
        drawHeader(context, originY, SEC_SUPPLY_Y, "autofarm.extras.section.supply");

        // 最底下那句总说明：强调「默认全关」，让第一次进来的人放心
        int shown = 0;
        for (class_5481 line : this.field_22793.method_1728(
                class_2561.method_43471("autofarm.extras.note"), contentWidth - 8)) {
            if (shown >= 2) {
                break;
            }
            context.method_35720(this.field_22793, line,
                    contentX + 4, originY + NOTE_Y + shown * 11, COLOR_HINT);
            shown++;
        }
    }

    // ================= 行为 =================

    /** 「恢复默认」＝把附加功能全部关掉（出厂就是全关） */
    private void resetAllOff() {
        draft.autoAttack = false;
        draft.autoAttackViolent = false;
        draft.attackViolence = AutoFarmConfig.VIOLENCE_LIGHT;
        draft.attackIntervalMs = 800;
        draft.attackRange = 2.9;
        draft.attackHostileOnly = true;
        draft.pauseWhenPlayerNear = false;
        draft.playerNearRadius = 16;
        draft.antiKickMode = false;
        draft.antiKickLevel = 2;
        draft.reactionDelay = false;
        draft.reactionDelayTicks = 10;
        draft.idleLookAround = false;
        draft.scheduleEnabled = false;
        draft.scheduleStartHour = 8;
        draft.scheduleEndHour = 23;
        // 工作范围：只把开关和参数复原，坐标留着 —— 那是玩家亲手记的，不该被「全部关闭」抹掉
        draft.workAreaEnabled = false;
        draft.workAreaMode = AutoFarmConfig.AREA_MODE_RADIUS;
        draft.workAreaRadius = 24;
        draft.workDaylightOnly = false;
        draft.workClearWeatherOnly = false;
        draft.fatigueStop = false;
        draft.fatigueWorkMinutes = 60;
        draft.fatigueRestMinutes = 15;
        draft.retreatEnabled = false;
        draft.retreatHealthHearts = 6;
        draft.retreatDistance = 16;
        draft.hitReactionEnabled = false;
        draft.hitReactionSeconds = 2;
        draft.selfRescueEnabled = false;
        draft.autoReconnectEnabled = false;
        draft.reconnectDelaySeconds = 10;
        draft.reconnectMaxAttempts = 3;
        draft.humanizeTiming = false;
        draft.randomRest = false;
        draft.restIntervalMinutes = 10;
        draft.restDurationSeconds = 20;
        draft.autoReplaceTool = false;
        draft.toolDurabilityPercent = 10;
        draft.failureCooldown = false;
        draft.failureCooldownSeconds = 15;
        draft.verboseHud = false;
        draft.pickupDroppedItems = false;
        draft.pickupDelaySeconds = 1;
        draft.melonHarvest = false;
        draft.customHarvestBlocks = new ArrayList<>();
        draft.boneMealBoost = false;
        draft.boneMealLimit = 4;
        draft.autoFetchSupplies = false;
        draft.boneMealThreshold = 16;
        draft.autoFetchTool = false;
        // 标签文字要跟着变，直接重建整页最省事
        rebuild();
    }

    @Override
    protected void onCancel() {
        // 只还原附加功能这几项，草稿里的其他设置（扫描半径、存放策略……）保持不动
        draft.autoAttack = old.autoAttack;
        draft.autoAttackViolent = old.autoAttackViolent;
        draft.attackViolence = old.attackViolence;
        draft.attackIntervalMs = old.attackIntervalMs;
        draft.attackRange = old.attackRange;
        draft.attackHostileOnly = old.attackHostileOnly;
        draft.pauseWhenPlayerNear = old.pauseWhenPlayerNear;
        draft.playerNearRadius = old.playerNearRadius;
        draft.antiKickMode = old.antiKickMode;
        draft.antiKickLevel = old.antiKickLevel;
        draft.reactionDelay = old.reactionDelay;
        draft.reactionDelayTicks = old.reactionDelayTicks;
        draft.idleLookAround = old.idleLookAround;
        draft.scheduleEnabled = old.scheduleEnabled;
        draft.scheduleStartHour = old.scheduleStartHour;
        draft.scheduleEndHour = old.scheduleEndHour;
        draft.workAreaEnabled = old.workAreaEnabled;
        draft.workAreaMode = old.workAreaMode;
        draft.workAreaX = old.workAreaX;
        draft.workAreaY = old.workAreaY;
        draft.workAreaZ = old.workAreaZ;
        draft.workAreaRadius = old.workAreaRadius;
        draft.workAreaX2 = old.workAreaX2;
        draft.workAreaY2 = old.workAreaY2;
        draft.workAreaZ2 = old.workAreaZ2;
        draft.workDaylightOnly = old.workDaylightOnly;
        draft.workClearWeatherOnly = old.workClearWeatherOnly;
        draft.fatigueStop = old.fatigueStop;
        draft.fatigueWorkMinutes = old.fatigueWorkMinutes;
        draft.fatigueRestMinutes = old.fatigueRestMinutes;
        draft.retreatEnabled = old.retreatEnabled;
        draft.retreatHealthHearts = old.retreatHealthHearts;
        draft.retreatDistance = old.retreatDistance;
        draft.hitReactionEnabled = old.hitReactionEnabled;
        draft.hitReactionSeconds = old.hitReactionSeconds;
        draft.selfRescueEnabled = old.selfRescueEnabled;
        draft.autoReconnectEnabled = old.autoReconnectEnabled;
        draft.reconnectDelaySeconds = old.reconnectDelaySeconds;
        draft.reconnectMaxAttempts = old.reconnectMaxAttempts;
        draft.humanizeTiming = old.humanizeTiming;
        draft.randomRest = old.randomRest;
        draft.restIntervalMinutes = old.restIntervalMinutes;
        draft.restDurationSeconds = old.restDurationSeconds;
        draft.autoReplaceTool = old.autoReplaceTool;
        draft.toolDurabilityPercent = old.toolDurabilityPercent;
        draft.failureCooldown = old.failureCooldown;
        draft.failureCooldownSeconds = old.failureCooldownSeconds;
        draft.verboseHud = old.verboseHud;
        draft.pickupDroppedItems = old.pickupDroppedItems;
        draft.pickupDelaySeconds = old.pickupDelaySeconds;
        draft.melonHarvest = old.melonHarvest;
        draft.customHarvestBlocks = new ArrayList<>(old.customHarvestBlocks);
        draft.boneMealBoost = old.boneMealBoost;
        draft.boneMealLimit = old.boneMealLimit;
        draft.autoFetchSupplies = old.autoFetchSupplies;
        draft.boneMealThreshold = old.boneMealThreshold;
        draft.autoFetchTool = old.autoFetchTool;
        backToParent();
    }

    // ================= 文案 =================

    private static int nextChoice(int[] choices, int current) {
        for (int i = 0; i < choices.length; i++) {
            if (choices[i] == current) {
                return choices[(i + 1) % choices.length];
            }
        }
        return choices[0];
    }

    /** 小数版的循环取下一档（攻击距离用）。比较带一点容差，免得浮点误差选不中 */
    private static double nextChoice(double[] choices, double current) {
        for (int i = 0; i < choices.length; i++) {
            if (Math.abs(choices[i] - current) < 1e-6) {
                return choices[(i + 1) % choices.length];
            }
        }
        return choices[0];
    }

    /** 「选项：值」的通用拼法 */
    private static class_2561 optionLabel(String optionKey, class_2561 value) {
        return class_2561.method_43469("autofarm.toggle", class_2561.method_43471(optionKey), value);
    }

    private class_2561 radiusLabel() {
        return optionLabel("autofarm.option.player_radius",
                class_2561.method_43469("autofarm.value.blocks", draft.playerNearRadius));
    }

    private class_2561 restIntervalLabel() {
        return optionLabel("autofarm.option.rest_interval",
                class_2561.method_43469("autofarm.value.minutes", draft.restIntervalMinutes));
    }

    private class_2561 restDurationLabel() {
        return optionLabel("autofarm.option.rest_duration",
                class_2561.method_43469("autofarm.value.seconds", draft.restDurationSeconds));
    }

    private class_2561 durabilityLabel() {
        return optionLabel("autofarm.option.tool_threshold",
                class_2561.method_43469("autofarm.value.percent", draft.toolDurabilityPercent));
    }

    private class_2561 cooldownLabel() {
        return optionLabel("autofarm.option.cooldown_seconds",
                class_2561.method_43469("autofarm.value.seconds", draft.failureCooldownSeconds));
    }

    private class_2561 pickupDelayLabel() {
        return optionLabel("autofarm.option.pickup_delay",
                class_2561.method_43469("autofarm.value.seconds", draft.pickupDelaySeconds));
    }

    private class_2561 attackRangeLabel() {
        return optionLabel("autofarm.option.attack_range",
                class_2561.method_43469("autofarm.value.blocks", String.format("%.1f", draft.attackRange)));
    }

    private class_2561 attackTargetLabel() {
        return optionLabel("autofarm.option.attack_target",
                class_2561.method_43471(draft.attackHostileOnly
                        ? "autofarm.attack_target.hostile"
                        : "autofarm.attack_target.all"));
    }

    private class_2561 violenceLabel() {
        return optionLabel("autofarm.option.attack_violence",
                class_2561.method_43471("autofarm.attack_violence.level." + violenceKey(draft.attackViolence)));
    }

    /** 暴力程度档位 → 语言键后缀。认不出来的一律当「轻度」显示 */
    private static String violenceKey(int level) {
        return switch (level) {
            case 1 -> "medium";
            case 2 -> "lifesaver";
            default -> "light";
        };
    }

    private class_2561 antiKickLevelLabel() {
        return optionLabel("autofarm.option.antikick_level",
                class_2561.method_43471("autofarm.antikick.level." + levelKey(draft.antiKickLevel)));
    }

    private class_2561 reactionTimeLabel() {
        return optionLabel("autofarm.option.reaction_time",
                class_2561.method_43469("autofarm.value.seconds",
                        String.format("%.1f", draft.reactionDelayTicks / 20.0)));
    }

    private class_2561 scheduleStartLabel() {
        return optionLabel("autofarm.option.schedule_start", hourText(draft.scheduleStartHour));
    }

    private class_2561 scheduleEndLabel() {
        return optionLabel("autofarm.option.schedule_end", hourText(draft.scheduleEndHour));
    }

    private static class_2561 hourText(int hour) {
        return class_2561.method_43469("autofarm.value.hour", String.format("%02d", hour));
    }

    private class_2561 workAreaModeLabel() {
        return optionLabel("autofarm.option.work_area_mode",
                class_2561.method_43471(draft.workAreaMode == AutoFarmConfig.AREA_MODE_BOX
                        ? "autofarm.area_mode.box"
                        : "autofarm.area_mode.radius"));
    }

    private class_2561 workAreaRadiusLabel() {
        return optionLabel("autofarm.option.work_area_radius",
                class_2561.method_43469("autofarm.value.blocks", draft.workAreaRadius));
    }

    private class_2561 workAreaCenterLabel() {
        return class_2561.method_43469("autofarm.work_area.record_center", coordText(draft.workAreaText()));
    }

    private class_2561 workAreaCornerALabel() {
        return class_2561.method_43469("autofarm.work_area.record_a", coordText(draft.workAreaText()));
    }

    private class_2561 workAreaCornerBLabel() {
        return class_2561.method_43469("autofarm.work_area.record_b", coordText(draft.workAreaSecondText()));
    }

    /** 坐标文本：没记过就显示「未设置」 */
    private static class_2561 coordText(String text) {
        return text == null ? class_2561.method_43471("autofarm.work_area.none") : class_2561.method_43470(text);
    }

    private class_2561 fatigueWorkLabel() {
        return optionLabel("autofarm.option.fatigue_work",
                class_2561.method_43469("autofarm.value.minutes", draft.fatigueWorkMinutes));
    }

    private class_2561 fatigueRestLabel() {
        return optionLabel("autofarm.option.fatigue_rest",
                draft.fatigueRestMinutes <= 0
                        ? class_2561.method_43471("autofarm.fatigue_rest.manual")
                        : class_2561.method_43469("autofarm.value.minutes", draft.fatigueRestMinutes));
    }

    private class_2561 retreatHealthLabel() {
        return optionLabel("autofarm.option.retreat_health",
                class_2561.method_43469("autofarm.value.hearts", draft.retreatHealthHearts));
    }

    private class_2561 retreatDistanceLabel() {
        return optionLabel("autofarm.option.retreat_distance",
                class_2561.method_43469("autofarm.value.blocks", draft.retreatDistance));
    }

    private class_2561 hitReactionTimeLabel() {
        return optionLabel("autofarm.option.hit_reaction_time",
                class_2561.method_43469("autofarm.value.seconds", draft.hitReactionSeconds));
    }

    private class_2561 reconnectDelayLabel() {
        return optionLabel("autofarm.option.reconnect_delay",
                class_2561.method_43469("autofarm.value.seconds", draft.reconnectDelaySeconds));
    }

    private class_2561 reconnectAttemptsLabel() {
        return optionLabel("autofarm.option.reconnect_attempts",
                draft.reconnectMaxAttempts <= 0
                        ? class_2561.method_43471("autofarm.reconnect_attempts.unlimited")
                        : class_2561.method_43469("autofarm.value.count", draft.reconnectMaxAttempts));
    }

    /** 自定义方块名单那一行的标签：显示「已添加 N 个」 */
    private class_2561 customBlocksLabel() {
        int n = draft.customHarvestBlocks == null ? 0 : draft.customHarvestBlocks.size();
        return optionLabel("autofarm.option.custom_blocks",
                class_2561.method_43469("autofarm.value.count", n));
    }

    /** 骨粉催熟：同一株最多撒几次 */
    private class_2561 boneMealLimitLabel() {
        return optionLabel("autofarm.option.bone_meal_limit",
                class_2561.method_43469("autofarm.value.count", draft.boneMealLimit));
    }

    /** 耗材自给：骨粉低于多少个就去补给点补一趟 */
    private class_2561 boneMealThresholdLabel() {
        return optionLabel("autofarm.option.bone_meal_threshold",
                class_2561.method_43469("autofarm.value.count", draft.boneMealThreshold));
    }

    /** 把准星指向的那个方块加进自定义名单；加之前先弹一道提醒屏 */
    private void addLookedBlock() {
        if (this.field_22787 == null || this.field_22787.field_1687 == null) {
            return;
        }
        class_239 hit = this.field_22787.field_1765;
        if (hit == null || hit.method_17783() != class_239.class_240.field_1332) {
            toast("autofarm.custom_block.no_target");
            return;
        }
        class_2680 state = this.field_22787.field_1687.method_8320(((class_3965) hit).method_17777());
        class_2248 block = state.method_26204();
        if (block == class_2246.field_10124) {
            toast("autofarm.custom_block.no_target");
            return;
        }
        String id = CropRegistry.idOf(block);
        if (id == null) {
            toast("autofarm.custom_block.no_target");
            return;
        }
        if (draft.customHarvestBlocks == null) {
            draft.customHarvestBlocks = new ArrayList<>();
        }
        if (draft.customHarvestBlocks.contains(id)) {
            toast("autofarm.custom_block.duplicate");
            return;
        }
        // 加之前提醒一句：只加农作物类方块，别加石头矿物（否则挖下来无法按作物存放）；
        // 本功能也不是矿透。确认之后才真的写进名单。
        confirmThen("autofarm.custom_block.warn.subtitle", () -> {
            draft.customHarvestBlocks.add(id);
            rebuild();
        }, "autofarm.custom_block.warn.body1",
                "autofarm.custom_block.warn.body2", "autofarm.custom_block.warn.body3");
    }

    /** 清空自定义名单；清空前也弹一道确认屏，免得误触一键清空 */
    private void clearCustomBlocks() {
        if (draft.customHarvestBlocks == null || draft.customHarvestBlocks.isEmpty()) {
            toast("autofarm.custom_block.empty");
            return;
        }
        confirmThen("autofarm.custom_block.clear.subtitle", () -> {
            draft.customHarvestBlocks.clear();
            rebuild();
        }, "autofarm.custom_block.clear.body1");
    }

    /** 把玩家当前所在的那一格记成工作区域的一个点（圆形 = 中心，矩形 = 角点） */
    private void recordCurrentPos(boolean second) {
        if (this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }
        class_2338 pos = this.field_22787.field_1724.method_24515();
        if (second) {
            draft.setWorkAreaSecond(pos.method_10263(), pos.method_10264(), pos.method_10260());
        } else {
            draft.setWorkArea(pos.method_10263(), pos.method_10264(), pos.method_10260());
        }
    }

    /** 档位数字 → 语言键后缀。认不出来的档位一律当「关闭」显示 */
    private static String levelKey(int level) {
        return switch (level) {
            case 1 -> "light";
            case 2 -> "medium";
            case 3 -> "high";
            default -> "off";
        };
    }
}
