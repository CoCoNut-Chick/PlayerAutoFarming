package com.autofarm.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5250;

/**
 * 「固定标题 + 可滚动内容 + 固定页脚」三段式面板的公共骨架。
 *
 * <p>为什么需要它：Minecraft 的「界面尺寸（GUI Scale）」调高之后，逻辑分辨率会变小
 * （1080p 在 scale 4 下只有 270 像素高），任何写死高度的面板都会被切掉底部的按钮。
 * 让面板高度自适应 + 内容可滚动，用户就不必再去拉窗口大小了。
 *
 * <p>子类只需要回答三个问题：
 * <ol>
 *   <li>{@link #contentHeight()} 内容总共多高</li>
 *   <li>{@link #buildContent()} 有哪些控件（用 {@link #addScrolling} / {@link #addFooter} 注册）</li>
 *   <li>{@link #positionContent(int)} 每个控件摆在内容的第几行</li>
 * </ol>
 * 再加一个 {@link #renderContent} 画自绘部分（分区底板、标题、说明文字）。
 */
public abstract class ScrollPanelScreen extends class_437 {

    // ---------------- 几何常量 ----------------
    /** 理想宽度；屏幕不够宽时自动收窄 */
    protected static final int PREF_PANEL_W = 320;
    /** 标题区高度（固定不动） */
    protected static final int TITLE_H = 26;
    /** 底部按钮区高度（固定不动） */
    protected static final int FOOTER_H = 30;
    /** 面板左右内边距 */
    protected static final int PAD = 12;
    /** 标准行高 */
    protected static final int ROW_H = 18;
    /** 顶部 tab 栏高度（相对内容区顶部）。两个面板共用同一套排版 */
    protected static final int TAB_BAR_H = 24;

    private static final int MIN_PANEL_H = 96;
    /** 一格滚轮滚多少像素 */
    private static final int SCROLL_STEP = 18;
    /** 滚动条的可抓取宽度（画出来只有一半宽，但点得中） */
    private static final int SCROLLBAR_GRAB_W = 8;

    // ---------------- 配色 ----------------
    protected static final int COLOR_PANEL = 0xC8101010;
    protected static final int COLOR_SECTION = 0x30FFFFFF;
    protected static final int COLOR_TITLE = 0xFFFFFFFF;
    protected static final int COLOR_HEADER = 0xFFFFCC66;
    protected static final int COLOR_TEXT = 0xFFE0E0E0;
    protected static final int COLOR_HINT = 0xFF909090;
    /** 提示/警告用的暖色（比如「没种子，跳过了补种」） */
    protected static final int COLOR_NOTICE = 0xFFFFB020;
    /** 开关「已开启」用的绿 */
    protected static final int COLOR_ON = 0xFF55FF55;
    /** 高风险开关用的红 */
    protected static final int COLOR_DANGER = 0xFFFF5555;

    private static final int COLOR_DIVIDER = 0x30FFFFFF;
    private static final int COLOR_FADE = 0x50000000;
    private static final int COLOR_BAR_BG = 0x40000000;
    private static final int COLOR_BAR = 0x80FFFFFF;

    protected final class_437 parent;

    private final List<class_339> scrollingWidgets = new ArrayList<>();
    private final List<class_339> footerWidgets = new ArrayList<>();

    // ---------------- 运行时几何（init 时算好，子类可直接用） ----------------
    protected int left;
    protected int top;
    protected int panelW;
    protected int panelH;
    /** 内容区左边界（= left + PAD） */
    protected int contentX;
    /** 内容区宽度（= panelW - 2 * PAD） */
    protected int contentWidth;
    /** 可视内容区的上边界（屏幕坐标） */
    protected int contentTop;
    /** 可视内容区的下边界（屏幕坐标） */
    protected int contentBottom;
    /** 固定页脚的上边界 */
    protected int footerTop;

    protected int scroll;
    protected int maxScroll;

    // ---------------- 滚动条运行时几何（每帧算一次，拖拽时复用） ----------------
    private int sbTrackTop;
    private int sbTrackH;
    private int sbThumbTop;
    private int sbThumbH;
    /** 正按着滑块拖 */
    private boolean draggingScrollbar;
    /** 按下时鼠标相对滑块顶端的偏移，拖的时候保持不变 */
    private int dragGrabOffset;

    protected ScrollPanelScreen(class_437 parent, class_2561 title) {
        super(title);
        this.parent = parent;
    }

    /** 可滚动内容的总高度 */
    protected abstract int contentHeight();

    /** 建控件。几何量（contentX / contentWidth）在这里已经算好了 */
    protected abstract void buildContent();

    /**
     * 把控件摆到该摆的位置。
     *
     * @param originY 内容区顶部在屏幕上的实际 y（已经扣掉了滚动偏移），
     *                所以「内容相对第 N 行」的位置就是 {@code originY + N}
     */
    protected abstract void positionContent(int originY);

    /** 画跟着内容一起滚动的自绘部分 */
    protected abstract void renderContent(class_332 context, int originY,
                                          int mouseX, int mouseY, float delta);

    @Override
    protected final void method_25426() {
        // ---- 自适应尺寸：装不下就收窄、变矮，剩下的交给滚动 ----
        int availW = Math.max(150, this.field_22789 - PAD);
        int availH = Math.max(MIN_PANEL_H, this.field_22790 - 6);
        this.panelW = Math.min(PREF_PANEL_W, availW);
        this.panelH = Math.min(TITLE_H + contentHeight() + FOOTER_H, availH);
        this.left = (this.field_22789 - panelW) / 2;
        this.top = Math.max(2, (this.field_22790 - panelH) / 2);

        this.contentTop = top + TITLE_H;
        this.contentBottom = top + panelH - FOOTER_H;
        this.footerTop = contentBottom;
        this.contentX = left + PAD;
        this.contentWidth = panelW - PAD * 2;
        this.maxScroll = Math.max(0, contentHeight() - (contentBottom - contentTop));
        this.scroll = clampInt(scroll, 0, maxScroll);

        this.scrollingWidgets.clear();
        this.footerWidgets.clear();

        buildContent();

        int footerY = footerTop + 6;
        for (class_339 w : footerWidgets) {
            w.method_46419(footerY);
        }
        relayout();
    }

    /** 注册一个「跟着内容一起滚」的控件 */
    protected void addScrolling(class_339 widget) {
        scrollingWidgets.add(widget);
        method_37063(widget);
    }

    /** 注册一个「固定在面板底部」的控件 */
    protected void addFooter(class_339... widgets) {
        for (class_339 w : widgets) {
            footerWidgets.add(w);
            method_37063(w);
        }
    }

    /**
     * 重新摆放所有滚动控件，并把完全滚出可视区的控件隐藏掉。
     * 隐藏这一步是必须的：否则它们虽然看不见，点击区域却还留在面板外面。
     */
    protected void relayout() {
        positionContent(contentTop - scroll);
        for (class_339 w : scrollingWidgets) {
            // 1.20.1 的 ClickableWidget 只有 public 字段 visible，没有 setVisible()
            w.field_22764 = w.method_46427() + w.method_25364() > contentTop && w.method_46427() < contentBottom;
        }
    }

    protected static void setRowY(class_339 widget, int y) {
        if (widget != null) {
            widget.method_46419(y);
        }
    }

    // ================= 渲染 =================

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);

        // 面板底板
        context.method_25294(left, top, left + panelW, top + panelH, COLOR_PANEL);

        int originY = contentTop - scroll;

        // ---- 内容区：开裁剪，滚出可视区的部分不会被画出来 ----
        context.method_44379(left + 1, contentTop, left + panelW - 1, contentBottom);

        renderContent(context, originY, mouseX, mouseY, delta);

        // 这里千万不能调 super.render()：它会遍历所有 drawable，
        // 把固定页脚的按钮也画进来，然后被上面的裁剪一起切掉。
        for (class_339 w : scrollingWidgets) {
            if (w.field_22764) {
                w.method_25394(context, mouseX, mouseY, delta);
            }
        }

        context.method_44380();

        // ---- 固定部分 ----
        context.method_27534(this.field_22793, this.field_22785,
                left + panelW / 2, top + 8, COLOR_TITLE);

        context.method_25294(left + 1, footerTop, left + panelW - 1, footerTop + 1, COLOR_DIVIDER);
        for (class_339 w : footerWidgets) {
            w.method_25394(context, mouseX, mouseY, delta);
        }

        // 可视区上下边缘压一条暗色，暗示「上面/下面还有内容」
        if (scroll > 0) {
            context.method_25294(left + 1, contentTop, left + panelW - 1, contentTop + 3, COLOR_FADE);
        }
        if (scroll < maxScroll) {
            context.method_25294(left + 1, contentBottom - 3, left + panelW - 1, contentBottom, COLOR_FADE);
        }

        renderScrollbar(context, overScrollbar(mouseX, mouseY) || draggingScrollbar);
    }

    /** 画一块分区底板。relY / relH 都是「相对内容区顶部」的坐标 */
    protected void drawSection(class_332 context, int originY, int relY, int relH) {
        context.method_25294(contentX, originY + relY, contentX + contentWidth, originY + relY + relH, COLOR_SECTION);
    }

    /** 画分区小标题 */
    protected void drawHeader(class_332 context, int originY, int relY, String key) {
        context.method_27535(this.field_22793, class_2561.method_43471(key),
                contentX + 6, originY + relY + 4, COLOR_HEADER);
    }

    /** 画一个矩形线框（用 4 条 1 像素的填充拼出来，DrawContext 没有现成的描边 API） */
    protected static void drawRectOutline(class_332 context, int x1, int y1, int x2, int y2, int color) {
        context.method_25294(x1, y1, x2, y1 + 1, color);
        context.method_25294(x1, y2 - 1, x2, y2, color);
        context.method_25294(x1, y1 + 1, x1 + 1, y2 - 1, color);
        context.method_25294(x2 - 1, y1 + 1, x2, y2 - 1, color);
    }

    /**
     * 滚动条：轨道 + 滑块。滑块可以<b>用鼠标按住拖</b>，也可以点轨道直接跳。
     *
     * <p>几何量顺便存进字段，鼠标事件里直接复用（不用再算一遍，也不会和画出来的位置错开）。
     */
    private void renderScrollbar(class_332 context, boolean hovered) {
        if (maxScroll <= 0) {
            sbThumbH = 0;
            sbThumbTop = 0;
            sbTrackH = 0;
            sbTrackTop = 0;
            return;
        }
        int viewH = contentBottom - contentTop;
        sbTrackTop = contentTop + 2;
        sbTrackH = viewH - 4;
        sbThumbH = Math.max(18, (int) ((long) sbTrackH * viewH / contentHeight()));
        sbThumbTop = sbTrackTop + (int) ((long) (sbTrackH - sbThumbH) * scroll / maxScroll);

        int barX = left + panelW - 5;
        context.method_25294(barX, sbTrackTop, barX + 3, sbTrackTop + sbTrackH, COLOR_BAR_BG);
        // 悬停或拖拽时滑块加宽、变亮 —— 一眼看出「这东西能拖」
        boolean active = hovered || draggingScrollbar;
        int thumbColor = active ? 0xE0FFFFFF : COLOR_BAR;
        int thumbLeft = active ? barX - 1 : barX;
        int thumbRight = active ? barX + 5 : barX + 3;
        context.method_25294(thumbLeft, sbThumbTop, thumbRight, sbThumbTop + sbThumbH, thumbColor);
    }

    /** 鼠标是不是落在滚动条那条竖带上（放宽到 {@value #SCROLLBAR_GRAB_W} 像素，好抓） */
    private boolean overScrollbar(double mouseX, double mouseY) {
        return maxScroll > 0
                && mouseX >= left + panelW - SCROLLBAR_GRAB_W
                && mouseX <= left + panelW
                && mouseY >= sbTrackTop
                && mouseY <= sbTrackTop + sbTrackH;
    }

    /** 把滑块挪到某个 y（把「抓取点」对齐鼠标），并据此换算滚动量 */
    private void dragScrollbarTo(double mouseY) {
        int span = sbTrackH - sbThumbH;
        if (span <= 0) {
            return;
        }
        int thumbTop = clampInt((int) mouseY - dragGrabOffset, sbTrackTop, sbTrackTop + span);
        int next = clampInt((int) Math.round((double) (thumbTop - sbTrackTop) * maxScroll / span),
                0, maxScroll);
        if (next != scroll) {
            scroll = next;
            relayout();
        }
    }

    // ================= 输入 =================

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (maxScroll > 0
                && mouseX >= left && mouseX <= left + panelW
                && mouseY >= contentTop && mouseY <= contentBottom) {
            int next = clampInt(scroll - (int) Math.round(amount * SCROLL_STEP), 0, maxScroll);
            if (next != scroll) {
                scroll = next;
                relayout();
            }
            return true;
        }
        return super.method_25401(mouseX, mouseY, amount);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // 先看是不是按住滚动条拖
        if (button == 0 && overScrollbar(mouseX, mouseY)) {
            if (mouseY >= sbThumbTop && mouseY < sbThumbTop + sbThumbH) {
                // 按在滑块上：记住抓取点，拖的时候保持这个相对位置
                dragGrabOffset = (int) mouseY - sbThumbTop;
            } else {
                // 点轨道空白：滑块中心跳过来，然后接着拖
                dragGrabOffset = sbThumbH / 2;
                dragScrollbarTo(mouseY);
            }
            draggingScrollbar = true;
            return true;
        }
        // 标题条那条带子上可能压着「只露出一半」的控件，直接不让点，免得误触
        if (mouseY < contentTop) {
            return false;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingScrollbar) {
            dragScrollbarTo(mouseY);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (draggingScrollbar && button == 0) {
            draggingScrollbar = false;
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    // ================= 行为 =================

    /** 取消 / 按 Esc：回上层界面。子类可以覆写来丢弃草稿 */
    protected void onCancel() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    /** 「完成 / 保存」之后回上层界面 */
    protected void backToParent() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public void method_25419() {
        onCancel();
    }

    /** 左上角弹一条动作栏提示 */
    protected void toast(String translationKey) {
        if (this.field_22787 != null && this.field_22787.field_1724 != null) {
            this.field_22787.field_1724.method_7353(class_2561.method_43471(translationKey), true);
        }
    }

    /**
     * 开关按钮的文案：<b>开着 → 绿色</b>，关着 → 保持默认色。
     *
     * <p>整块面板里一眼扫过去，绿色的就是「已经开了」的项 —— 不必逐个去读「开 / 关」两个字。
     */
    protected static class_2561 toggleLabel(String optionKey, boolean value) {
        class_5250 key = class_2561.method_43471(optionKey);
        if (value) {
            key = key.method_27692(class_124.field_1060);
        }
        return class_2561.method_43469("autofarm.toggle", key,
                class_2561.method_43471(value ? "autofarm.on" : "autofarm.off"));
    }

    /**
     * 高风险开关的文案：<b>开着 → 绿色</b>（和其他开关一致，方便一眼看「开了没」），
     * <b>关着 → 红色</b> —— 红色在这里是个「别随手打开」的记号：
     * 这类开关（自动打怪、暴力模式…）出厂就<i>不推荐开启</i>，红色提醒你它是危险功能。
     */
    protected static class_2561 dangerToggleLabel(String optionKey, boolean value) {
        class_5250 key = class_2561.method_43471(optionKey)
                .method_27692(value ? class_124.field_1060 : class_124.field_1061);
        return class_2561.method_43469("autofarm.toggle", key,
                class_2561.method_43471(value ? "autofarm.on" : "autofarm.off"));
    }

    /**
     * 画顶部 tab 栏的「选中」标记：底下一条高亮横线。
     *
     * <p>两个面板共用同一套观感 —— 当前所在的大类下面画一条金线，其余保持素净。
     */
    protected void drawTabMarker(class_332 context, class_4185[] buttons, int currentTab) {
        for (int i = 0; i < buttons.length; i++) {
            class_4185 btn = buttons[i];
            if (btn == null || i != currentTab) {
                continue;
            }
            context.method_25294(btn.method_46426(), btn.method_46427() + btn.method_25364() - 1,
                    btn.method_46426() + btn.method_25368(), btn.method_46427() + btn.method_25364(), COLOR_HEADER);
        }
    }

    protected static int clampInt(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
