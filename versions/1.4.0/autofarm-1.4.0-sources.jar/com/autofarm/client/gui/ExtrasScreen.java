package com.autofarm.client.gui;

import com.autofarm.client.config.AutoFarmConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_7919;

/**
 * 「附加功能」次级面板：一堆<b>默认全部关闭</b>的增强项，集中放在这里。
 *
 * <h2>为什么要单开一页、而且默认全关</h2>
 * 主面板上的每一项都是「收割本身需要的东西」—— 扫描、寻路、补种、存放、安全。
 * 而这里放的是一层<b>可有可无的锦上添花</b>：有的改变动作节奏（拟人化、定时休息），
 * 有的改变安全边界（别的玩家靠近就停手），有的只是顺手多干点活
 * （工具快坏了换一把、失败的作物过会儿再试、HUD 多显示点数字）。
 *
 * <p>它们共同的风险是「玩家没要，却擅自改变了行为」。所以默认**一个都不开**：
 * 不碰它们，模组的行为和以前一模一样。想用哪个再单独打开。
 *
 * <h2>七段</h2>
 * <ol>
 *   <li><b>战斗（高风险）</b> —— 自动打怪，默认关闭、警示配色、开启要过确认屏；</li>
 *   <li><b>安全与隐蔽</b> —— 玩家接近停机、拟人化节奏、定时随机休息；</li>
 *   <li><b>防踢模式</b> —— 一整套「把机器味抹掉」的措施，带四档强度；</li>
 *   <li><b>行为真实感</b> —— 危险反应延迟、空闲时环顾四周、仅在指定时段工作；</li>
 *   <li><b>工具维护</b> —— 工具耐久自动换新；</li>
 *   <li><b>容错与统计</b> —— 失败目标暂时拉黑、HUD 详细统计；</li>
 *   <li><b>掉落物</b> —— 优先拾取散落在田里的作物掉落物。</li>
 * </ol>
 * 每个「功能开关」下面跟着的参数行（半径、周期、阈值……）都用循环按钮调，
 * 点一下换一档，不用滑块 —— 和主面板的「默认种子槽位」一个习惯。
 *
 * <h2>和主面板的关系</h2>
 * 老规矩：它编辑的是主面板递进来的<b>同一个草稿</b>。点「完成」回主面板，
 * 最终由主面板的「保存并关闭」落盘；点「取消」或 Esc 只把这里的十几项
 * 恢复成进来之前的样子，不碰草稿里的其他设置。
 */
public class ExtrasScreen extends ScrollPanelScreen {

    // ---------------- 内容区布局（相对内容区顶部） ----------------
    /** 分区内第一行相对分区顶部的 y（让开标题那一行） */
    private static final int ROW_FIRST = 18;
    /** 相邻两行的间距 */
    private static final int ROW_GAP = 20;
    /** 两个分区之间的留白 */
    private static final int SECTION_GAP = 6;
    /** 参数行的左缩进，视觉上表示「从属于上一行」 */
    private static final int INDENT = 8;
    /** 高风险分区专用的警示色：标题与开关文字都用它 */
    private static final int COLOR_DANGER = 0xFFFF5555;

    private static final int COMBAT_ROWS = 4;
    private static final int SEC_COMBAT_Y = 0;
    private static final int SEC_COMBAT_H = ROW_FIRST + COMBAT_ROWS * ROW_GAP + 4;

    private static final int STEALTH_ROWS = 6;
    private static final int SEC_STEALTH_Y = SEC_COMBAT_H + SECTION_GAP;
    private static final int SEC_STEALTH_H = ROW_FIRST + STEALTH_ROWS * ROW_GAP + 4;

    private static final int ANTIKICK_ROWS = 2;
    private static final int SEC_ANTIKICK_Y = SEC_STEALTH_Y + SEC_STEALTH_H + SECTION_GAP;
    private static final int SEC_ANTIKICK_H = ROW_FIRST + ANTIKICK_ROWS * ROW_GAP + 4;

    private static final int BEHAVIOR_ROWS = 6;
    private static final int SEC_BEHAVIOR_Y = SEC_ANTIKICK_Y + SEC_ANTIKICK_H + SECTION_GAP;
    private static final int SEC_BEHAVIOR_H = ROW_FIRST + BEHAVIOR_ROWS * ROW_GAP + 4;

    private static final int TOOL_ROWS = 2;
    private static final int SEC_TOOL_Y = SEC_BEHAVIOR_Y + SEC_BEHAVIOR_H + SECTION_GAP;
    private static final int SEC_TOOL_H = ROW_FIRST + TOOL_ROWS * ROW_GAP + 4;

    private static final int MISC_ROWS = 3;
    private static final int SEC_MISC_Y = SEC_TOOL_Y + SEC_TOOL_H + SECTION_GAP;
    private static final int SEC_MISC_H = ROW_FIRST + MISC_ROWS * ROW_GAP + 4;

    private static final int PICKUP_ROWS = 2;
    private static final int SEC_PICKUP_Y = SEC_MISC_Y + SEC_MISC_H + SECTION_GAP;
    private static final int SEC_PICKUP_H = ROW_FIRST + PICKUP_ROWS * ROW_GAP + 4;

    /** 最底下那句「默认全关」的总说明 */
    private static final int NOTE_Y = SEC_PICKUP_Y + SEC_PICKUP_H + 8;
    private static final int NOTE_H = 24;

    // ---------------- 循环档位（都含出厂默认值，见 AutoFarmConfig） ----------------
    private static final int[] RADIUS_CHOICES = {8, 12, 16, 24, 32};
    private static final int[] REST_INTERVAL_CHOICES = {5, 10, 15, 20, 30};
    private static final int[] REST_DURATION_CHOICES = {10, 20, 30, 60};
    private static final int[] DURABILITY_CHOICES = {5, 10, 15, 20, 30};
    private static final int[] COOLDOWN_CHOICES = {5, 10, 15, 30, 60};
    private static final int[] PICKUP_DELAY_CHOICES = {1, 2, 3, 5};
    /** 战斗：两次出手的间隔（毫秒） */
    private static final int[] ATTACK_INTERVAL_CHOICES = {400, 600, 800, 1200};
    /** 防踢档位：0 = 关闭、1 = 轻度、2 = 中度、3 = 强力（和 Humanizer 的常量一致） */
    private static final int[] ANTIKICK_LEVEL_CHOICES = {0, 1, 2, 3};
    /** 行为真实感：反应延迟时长（tick，1 秒 = 20 tick） */
    private static final int[] REACTION_CHOICES = {4, 10, 20, 30};
    /** 工作时段：0~23 整点（循环按钮在这 24 档之间轮换） */
    private static final int[] HOUR_CHOICES = buildHours();

    private static int[] buildHours() {
        int[] hours = new int[24];
        for (int i = 0; i < hours.length; i++) {
            hours[i] = i;
        }
        return hours;
    }

    private final AutoFarmConfig draft;
    /** 进来时的快照，「取消」时用它还原附加功能这几项 */
    private final AutoFarmConfig old;

    private class_4185 combatButton;
    private class_4185 attackIntervalButton;
    private class_4185 attackTargetButton;
    private class_4185 violentButton;
    private class_4185 pausePlayerButton;
    private class_4185 radiusButton;
    private class_4185 humanizeButton;
    private class_4185 randomRestButton;
    private class_4185 restIntervalButton;
    private class_4185 restDurationButton;
    private class_4185 replaceToolButton;
    private class_4185 durabilityButton;
    private class_4185 failureCooldownButton;
    private class_4185 cooldownButton;
    private class_4185 verboseHudButton;
    private class_4185 pickupDropsButton;
    private class_4185 pickupDelayButton;
    private class_4185 antiKickButton;
    private class_4185 antiKickLevelButton;
    private class_4185 reactionDelayButton;
    private class_4185 reactionTimeButton;
    private class_4185 idleLookButton;
    private class_4185 scheduleButton;
    private class_4185 scheduleStartButton;
    private class_4185 scheduleEndButton;

    public ExtrasScreen(class_437 parent, AutoFarmConfig sharedDraft) {
        super(parent, class_2561.method_43471("autofarm.extras.title"));
        this.draft = sharedDraft;
        this.old = sharedDraft.copy();
    }

    @Override
    protected int contentHeight() {
        return NOTE_Y + NOTE_H;
    }

    // ================= 建控件 =================

    @Override
    protected void buildContent() {
        int fullW = contentWidth;
        int subX = contentX + INDENT;
        int subW = contentWidth - INDENT;

        // ---- 战斗（高风险）----
        // 全模组唯一会「替玩家出手攻击」的一组，所以从里到外都跟别的分区不一样：
        // 标题和开关文字标红、打开要先过一道风险确认屏、暴力模式还要等主子项开了才出现。

        this.combatButton = dangerToggle("autofarm.option.auto_attack",
                draft.autoAttack, value -> draft.autoAttack = value,
                "autofarm.auto_attack.tip");
        layout(combatButton, contentX, 0, fullW);

        this.attackIntervalButton = class_4185.method_46430(attackIntervalLabel(), b -> {
            draft.attackIntervalMs = nextChoice(ATTACK_INTERVAL_CHOICES, draft.attackIntervalMs);
            b.method_25355(attackIntervalLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        attackIntervalButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_interval.tip")));
        addScrolling(attackIntervalButton);

        this.attackTargetButton = class_4185.method_46430(attackTargetLabel(), b -> {
            draft.attackHostileOnly = !draft.attackHostileOnly;
            b.method_25355(attackTargetLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        attackTargetButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.attack_target.tip")));
        addScrolling(attackTargetButton);

        // 二级开关：主子项关着时它整个不显示（原位留一行灰字），打开之后才「弹」出来
        this.violentButton = dangerToggle("autofarm.option.auto_attack_violent",
                draft.autoAttackViolent, value -> draft.autoAttackViolent = value,
                "autofarm.auto_attack_violent.tip");
        layout(violentButton, subX, 0, subW);

        // ---- 安全与隐蔽 ----

        this.pausePlayerButton = toggle("autofarm.option.pause_player",
                draft.pauseWhenPlayerNear, value -> draft.pauseWhenPlayerNear = value,
                "autofarm.pause_player.tip");
        layout(pausePlayerButton, contentX, 0, fullW);

        this.radiusButton = class_4185.method_46430(radiusLabel(), b -> {
            draft.playerNearRadius = nextChoice(RADIUS_CHOICES, draft.playerNearRadius);
            b.method_25355(radiusLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        radiusButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.value_radius.tip")));
        addScrolling(radiusButton);

        this.humanizeButton = toggle("autofarm.option.humanize",
                draft.humanizeTiming, value -> draft.humanizeTiming = value,
                "autofarm.humanize.tip");
        layout(humanizeButton, contentX, 0, fullW);

        this.randomRestButton = toggle("autofarm.option.random_rest",
                draft.randomRest, value -> draft.randomRest = value,
                "autofarm.random_rest.tip");
        layout(randomRestButton, contentX, 0, fullW);

        this.restIntervalButton = class_4185.method_46430(restIntervalLabel(), b -> {
            draft.restIntervalMinutes = nextChoice(REST_INTERVAL_CHOICES, draft.restIntervalMinutes);
            b.method_25355(restIntervalLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        restIntervalButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.rest_interval.tip")));
        addScrolling(restIntervalButton);

        this.restDurationButton = class_4185.method_46430(restDurationLabel(), b -> {
            draft.restDurationSeconds = nextChoice(REST_DURATION_CHOICES, draft.restDurationSeconds);
            b.method_25355(restDurationLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        restDurationButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.rest_duration.tip")));
        addScrolling(restDurationButton);

        // ---- 防踢模式 ----

        this.antiKickButton = toggle("autofarm.option.antikick",
                draft.antiKickMode, value -> draft.antiKickMode = value,
                "autofarm.antikick.tip");
        layout(antiKickButton, contentX, 0, fullW);

        this.antiKickLevelButton = class_4185.method_46430(antiKickLevelLabel(), b -> {
            draft.antiKickLevel = nextChoice(ANTIKICK_LEVEL_CHOICES, draft.antiKickLevel);
            b.method_25355(antiKickLevelLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        antiKickLevelButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.antikick_level.tip")));
        addScrolling(antiKickLevelButton);

        // ---- 行为真实感 ----

        this.reactionDelayButton = toggle("autofarm.option.reaction_delay",
                draft.reactionDelay, value -> draft.reactionDelay = value,
                "autofarm.reaction_delay.tip");
        layout(reactionDelayButton, contentX, 0, fullW);

        this.reactionTimeButton = class_4185.method_46430(reactionTimeLabel(), b -> {
            draft.reactionDelayTicks = nextChoice(REACTION_CHOICES, draft.reactionDelayTicks);
            b.method_25355(reactionTimeLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        reactionTimeButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.reaction_time.tip")));
        addScrolling(reactionTimeButton);

        this.idleLookButton = toggle("autofarm.option.idle_look",
                draft.idleLookAround, value -> draft.idleLookAround = value,
                "autofarm.idle_look.tip");
        layout(idleLookButton, contentX, 0, fullW);

        this.scheduleButton = toggle("autofarm.option.schedule",
                draft.scheduleEnabled, value -> draft.scheduleEnabled = value,
                "autofarm.schedule.tip");
        layout(scheduleButton, contentX, 0, fullW);

        this.scheduleStartButton = class_4185.method_46430(scheduleStartLabel(), b -> {
            draft.scheduleStartHour = nextChoice(HOUR_CHOICES, draft.scheduleStartHour);
            b.method_25355(scheduleStartLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        scheduleStartButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.schedule_start.tip")));
        addScrolling(scheduleStartButton);

        this.scheduleEndButton = class_4185.method_46430(scheduleEndLabel(), b -> {
            draft.scheduleEndHour = nextChoice(HOUR_CHOICES, draft.scheduleEndHour);
            b.method_25355(scheduleEndLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        scheduleEndButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.schedule_end.tip")));
        addScrolling(scheduleEndButton);

        // ---- 工具维护 ----

        this.replaceToolButton = toggle("autofarm.option.replace_tool",
                draft.autoReplaceTool, value -> draft.autoReplaceTool = value,
                "autofarm.replace_tool.tip");
        layout(replaceToolButton, contentX, 0, fullW);

        this.durabilityButton = class_4185.method_46430(durabilityLabel(), b -> {
            draft.toolDurabilityPercent = nextChoice(DURABILITY_CHOICES, draft.toolDurabilityPercent);
            b.method_25355(durabilityLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        durabilityButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.durability.tip")));
        addScrolling(durabilityButton);

        // ---- 容错与统计 ----

        this.failureCooldownButton = toggle("autofarm.option.failure_cooldown",
                draft.failureCooldown, value -> draft.failureCooldown = value,
                "autofarm.failure_cooldown.tip");
        layout(failureCooldownButton, contentX, 0, fullW);

        this.cooldownButton = class_4185.method_46430(cooldownLabel(), b -> {
            draft.failureCooldownSeconds = nextChoice(COOLDOWN_CHOICES, draft.failureCooldownSeconds);
            b.method_25355(cooldownLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        cooldownButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.cooldown.tip")));
        addScrolling(cooldownButton);

        this.verboseHudButton = toggle("autofarm.option.verbose_hud",
                draft.verboseHud, value -> draft.verboseHud = value,
                "autofarm.verbose_hud.tip");
        layout(verboseHudButton, contentX, 0, fullW);

        // ---- 掉落物 ----

        this.pickupDropsButton = toggle("autofarm.option.pickup_drops",
                draft.pickupDroppedItems, value -> draft.pickupDroppedItems = value,
                "autofarm.pickup_drops.tip");
        layout(pickupDropsButton, contentX, 0, fullW);

        this.pickupDelayButton = class_4185.method_46430(pickupDelayLabel(), b -> {
            draft.pickupDelaySeconds = nextChoice(PICKUP_DELAY_CHOICES, draft.pickupDelaySeconds);
            b.method_25355(pickupDelayLabel());
        }).method_46434(subX, 0, subW, ROW_H).method_46431();
        pickupDelayButton.method_47400(class_7919.method_47407(class_2561.method_43471("autofarm.pickup_delay.tip")));
        addScrolling(pickupDelayButton);

        // ---- 页脚 ----
        int btnW = (contentWidth - 8) / 3;
        addFooter(
                class_4185.method_46430(class_2561.method_43471("autofarm.extras.reset"), b -> resetAllOff())
                        .method_46434(contentX, 0, btnW, ROW_H).method_46431(),
                class_4185.method_46430(class_2561.method_43471("autofarm.button.cancel"), b -> onCancel())
                        .method_46434(contentX + btnW + 4, 0, btnW, ROW_H).method_46431(),
                class_4185.method_46430(class_2561.method_43471("autofarm.highlight.done"), b -> backToParent())
                        .method_46434(contentX + 2 * (btnW + 4), 0, btnW, ROW_H).method_46431()
        );
    }

    /** 一个开关按钮的样板：点一下翻转，标签跟着变 */
    private class_4185 toggle(String optionKey, boolean value,
                                java.util.function.Consumer<Boolean> setter, String tipKey) {
        class_4185 button = class_4185.method_46430(toggleLabel(optionKey, value), b -> {
            boolean next = !currentToggle(optionKey);
            setter.accept(next);
            b.method_25355(toggleLabel(optionKey, next));
        }).method_46434(contentX, 0, contentWidth, ROW_H).method_46431();
        button.method_47400(class_7919.method_47407(class_2561.method_43471(tipKey)));
        return button;
    }

    /**
     * 高风险开关：文字标红，而且「打开」这一步被拆成两次 ——
     * 点开关只负责弹风险确认屏，真正写回草稿要等那边点过「确认」。
     * 「关闭」不设门槛：关掉一个危险功能不需要再被劝一次。
     */
    private class_4185 dangerToggle(String optionKey, boolean value,
                                      java.util.function.Consumer<Boolean> setter, String tipKey) {
        class_4185 button = class_4185.method_46430(dangerLabel(optionKey, value), b -> {
            if (currentToggle(optionKey)) {
                setter.accept(false);
                // 自动打怪关掉时，它的二级开关（暴力模式）也一并收掉，
                // 免得留下一个「主子项关着、暴力标记还亮着」的状态
                if ("autofarm.option.auto_attack".equals(optionKey)) {
                    draft.autoAttackViolent = false;
                }
                b.method_25355(dangerLabel(optionKey, false));
                return;
            }
            // 打开：先不落实，交给确认屏；确认之后那边会重建这一页
            openDangerConfirm(setter);
        }).method_46434(contentX, 0, contentWidth, ROW_H).method_46431();
        button.method_47400(class_7919.method_47407(class_2561.method_43471(tipKey)));
        return button;
    }

    /** 弹出风险确认屏；确认后写回草稿并重建本页（暴力行的显隐要跟着变） */
    private void openDangerConfirm(java.util.function.Consumer<Boolean> setter) {
        if (this.field_22787 == null) {
            return;
        }
        this.field_22787.method_1507(new DangerConfirmScreen(this, () -> {
            setter.accept(true);
            this.field_22787.method_1507(new ExtrasScreen(this.parent, draft));
        }));
    }

    /** 高风险分区的小标题：用警示色而不是通用标题色 */
    private void drawDangerHeader(class_332 context, int originY, int relY) {
        context.method_27535(this.field_22793,
                class_2561.method_43471("autofarm.extras.section.combat"),
                contentX + 6, originY + relY + 4, COLOR_DANGER);
    }

    /** 「选项：开/关」，但选项名染成红色 */
    private static class_2561 dangerLabel(String optionKey, boolean value) {
        return class_2561.method_43469("autofarm.toggle",
                class_2561.method_43471(optionKey).method_27692(class_124.field_1061),
                class_2561.method_43471(value ? "autofarm.on" : "autofarm.off"));
    }

    /** 从 draft 里读回当前开关值 —— 用来做「翻转」，保证和草稿永远一致 */
    private boolean currentToggle(String optionKey) {
        return switch (optionKey) {
            case "autofarm.option.auto_attack" -> draft.autoAttack;
            case "autofarm.option.auto_attack_violent" -> draft.autoAttackViolent;
            case "autofarm.option.pause_player" -> draft.pauseWhenPlayerNear;
            case "autofarm.option.humanize" -> draft.humanizeTiming;
            case "autofarm.option.random_rest" -> draft.randomRest;
            case "autofarm.option.replace_tool" -> draft.autoReplaceTool;
            case "autofarm.option.failure_cooldown" -> draft.failureCooldown;
            case "autofarm.option.verbose_hud" -> draft.verboseHud;
            case "autofarm.option.pickup_drops" -> draft.pickupDroppedItems;
            case "autofarm.option.antikick" -> draft.antiKickMode;
            case "autofarm.option.reaction_delay" -> draft.reactionDelay;
            case "autofarm.option.idle_look" -> draft.idleLookAround;
            case "autofarm.option.schedule" -> draft.scheduleEnabled;
            default -> false;
        };
    }

    private void layout(class_4185 widget, int x, int y, int width) {
        widget.method_46421(x);
        widget.method_46419(y);
        widget.method_25358(width);
        addScrolling(widget);
    }

    /**
     * 覆写：在通用的「滚出可视区就隐藏」之上，再叠一条本页自己的规则 ——
     * 暴力模式是二级开关，主子项关着时它整个不该出现（原位留一行灰字说明）。
     */
    @Override
    protected void relayout() {
        super.relayout();
        if (violentButton != null) {
            violentButton.field_22764 = violentButton.field_22764 && draft.autoAttack;
        }
    }

    @Override
    protected void positionContent(int originY) {
        int combat = originY + SEC_COMBAT_Y;
        setRowY(combatButton, combat + ROW_FIRST);
        setRowY(attackIntervalButton, combat + ROW_FIRST + ROW_GAP);
        setRowY(attackTargetButton, combat + ROW_FIRST + 2 * ROW_GAP);
        setRowY(violentButton, combat + ROW_FIRST + 3 * ROW_GAP);

        int stealth = originY + SEC_STEALTH_Y;
        setRowY(pausePlayerButton, stealth + ROW_FIRST);
        setRowY(radiusButton, stealth + ROW_FIRST + ROW_GAP);
        setRowY(humanizeButton, stealth + ROW_FIRST + 2 * ROW_GAP);
        setRowY(randomRestButton, stealth + ROW_FIRST + 3 * ROW_GAP);
        setRowY(restIntervalButton, stealth + ROW_FIRST + 4 * ROW_GAP);
        setRowY(restDurationButton, stealth + ROW_FIRST + 5 * ROW_GAP);

        int antiKick = originY + SEC_ANTIKICK_Y;
        setRowY(antiKickButton, antiKick + ROW_FIRST);
        setRowY(antiKickLevelButton, antiKick + ROW_FIRST + ROW_GAP);

        int behavior = originY + SEC_BEHAVIOR_Y;
        setRowY(reactionDelayButton, behavior + ROW_FIRST);
        setRowY(reactionTimeButton, behavior + ROW_FIRST + ROW_GAP);
        setRowY(idleLookButton, behavior + ROW_FIRST + 2 * ROW_GAP);
        setRowY(scheduleButton, behavior + ROW_FIRST + 3 * ROW_GAP);
        setRowY(scheduleStartButton, behavior + ROW_FIRST + 4 * ROW_GAP);
        setRowY(scheduleEndButton, behavior + ROW_FIRST + 5 * ROW_GAP);

        int tool = originY + SEC_TOOL_Y;
        setRowY(replaceToolButton, tool + ROW_FIRST);
        setRowY(durabilityButton, tool + ROW_FIRST + ROW_GAP);

        int misc = originY + SEC_MISC_Y;
        setRowY(failureCooldownButton, misc + ROW_FIRST);
        setRowY(cooldownButton, misc + ROW_FIRST + ROW_GAP);
        setRowY(verboseHudButton, misc + ROW_FIRST + 2 * ROW_GAP);

        int pickup = originY + SEC_PICKUP_Y;
        setRowY(pickupDropsButton, pickup + ROW_FIRST);
        setRowY(pickupDelayButton, pickup + ROW_FIRST + ROW_GAP);
    }

    // ================= 自绘 =================

    @Override
    protected void renderContent(class_332 context, int originY, int mouseX, int mouseY, float delta) {
        drawSection(context, originY, SEC_COMBAT_Y, SEC_COMBAT_H);
        drawDangerHeader(context, originY, SEC_COMBAT_Y);
        if (!draft.autoAttack) {
            // 暴力开关没解锁：那一行放一句灰字说明，替掉按钮的位置
            context.method_27535(this.field_22793,
                    class_2561.method_43471("autofarm.extras.violent_locked"),
                    contentX + INDENT + 4, originY + SEC_COMBAT_Y + ROW_FIRST + 3 * ROW_GAP + 5,
                    COLOR_HINT);
        }

        drawSection(context, originY, SEC_STEALTH_Y, SEC_STEALTH_H);
        drawHeader(context, originY, SEC_STEALTH_Y, "autofarm.extras.section.stealth");

        drawSection(context, originY, SEC_ANTIKICK_Y, SEC_ANTIKICK_H);
        drawHeader(context, originY, SEC_ANTIKICK_Y, "autofarm.extras.section.antikick");

        drawSection(context, originY, SEC_BEHAVIOR_Y, SEC_BEHAVIOR_H);
        drawHeader(context, originY, SEC_BEHAVIOR_Y, "autofarm.extras.section.behavior");

        drawSection(context, originY, SEC_TOOL_Y, SEC_TOOL_H);
        drawHeader(context, originY, SEC_TOOL_Y, "autofarm.extras.section.tool");

        drawSection(context, originY, SEC_MISC_Y, SEC_MISC_H);
        drawHeader(context, originY, SEC_MISC_Y, "autofarm.extras.section.misc");

        drawSection(context, originY, SEC_PICKUP_Y, SEC_PICKUP_H);
        drawHeader(context, originY, SEC_PICKUP_Y, "autofarm.extras.section.pickup");

        // 最底下那句总说明：强调「默认全关」，让第一次进来的人放心
        int shown = 0;
        for (class_5481 line : this.field_22793.method_1728(
                class_2561.method_43471("autofarm.extras.note"), contentWidth - 8)) {
            if (shown >= 2) {
                break;
            }
            context.method_35720(this.field_22793, line,
                    contentX + 4, originY + NOTE_Y + shown * 11, COLOR_HINT);
            shown++;
        }
    }

    // ================= 行为 =================

    /** 「恢复默认」＝把附加功能全部关掉（出厂就是全关） */
    private void resetAllOff() {
        draft.autoAttack = false;
        draft.autoAttackViolent = false;
        draft.attackIntervalMs = 800;
        draft.attackHostileOnly = true;
        draft.pauseWhenPlayerNear = false;
        draft.playerNearRadius = 16;
        draft.antiKickMode = false;
        draft.antiKickLevel = 2;
        draft.reactionDelay = false;
        draft.reactionDelayTicks = 10;
        draft.idleLookAround = false;
        draft.scheduleEnabled = false;
        draft.scheduleStartHour = 8;
        draft.scheduleEndHour = 23;
        draft.humanizeTiming = false;
        draft.randomRest = false;
        draft.restIntervalMinutes = 10;
        draft.restDurationSeconds = 20;
        draft.autoReplaceTool = false;
        draft.toolDurabilityPercent = 10;
        draft.failureCooldown = false;
        draft.failureCooldownSeconds = 15;
        draft.verboseHud = false;
        draft.pickupDroppedItems = false;
        draft.pickupDelaySeconds = 1;
        // 标签文字要跟着变，直接重建整页最省事
        if (this.field_22787 != null) {
            this.field_22787.method_1507(new ExtrasScreen(this.parent, draft));
        }
    }

    @Override
    protected void onCancel() {
        // 只还原附加功能这几项，草稿里的其他设置（扫描半径、存放策略……）保持不动
        draft.autoAttack = old.autoAttack;
        draft.autoAttackViolent = old.autoAttackViolent;
        draft.attackIntervalMs = old.attackIntervalMs;
        draft.attackHostileOnly = old.attackHostileOnly;
        draft.pauseWhenPlayerNear = old.pauseWhenPlayerNear;
        draft.playerNearRadius = old.playerNearRadius;
        draft.antiKickMode = old.antiKickMode;
        draft.antiKickLevel = old.antiKickLevel;
        draft.reactionDelay = old.reactionDelay;
        draft.reactionDelayTicks = old.reactionDelayTicks;
        draft.idleLookAround = old.idleLookAround;
        draft.scheduleEnabled = old.scheduleEnabled;
        draft.scheduleStartHour = old.scheduleStartHour;
        draft.scheduleEndHour = old.scheduleEndHour;
        draft.humanizeTiming = old.humanizeTiming;
        draft.randomRest = old.randomRest;
        draft.restIntervalMinutes = old.restIntervalMinutes;
        draft.restDurationSeconds = old.restDurationSeconds;
        draft.autoReplaceTool = old.autoReplaceTool;
        draft.toolDurabilityPercent = old.toolDurabilityPercent;
        draft.failureCooldown = old.failureCooldown;
        draft.failureCooldownSeconds = old.failureCooldownSeconds;
        draft.verboseHud = old.verboseHud;
        draft.pickupDroppedItems = old.pickupDroppedItems;
        draft.pickupDelaySeconds = old.pickupDelaySeconds;
        backToParent();
    }

    // ================= 文案 =================

    private static int nextChoice(int[] choices, int current) {
        for (int i = 0; i < choices.length; i++) {
            if (choices[i] == current) {
                return choices[(i + 1) % choices.length];
            }
        }
        return choices[0];
    }

    /** 「选项：值」的通用拼法 */
    private static class_2561 optionLabel(String optionKey, class_2561 value) {
        return class_2561.method_43469("autofarm.toggle", class_2561.method_43471(optionKey), value);
    }

    private class_2561 radiusLabel() {
        return optionLabel("autofarm.option.player_radius",
                class_2561.method_43469("autofarm.value.blocks", draft.playerNearRadius));
    }

    private class_2561 restIntervalLabel() {
        return optionLabel("autofarm.option.rest_interval",
                class_2561.method_43469("autofarm.value.minutes", draft.restIntervalMinutes));
    }

    private class_2561 restDurationLabel() {
        return optionLabel("autofarm.option.rest_duration",
                class_2561.method_43469("autofarm.value.seconds", draft.restDurationSeconds));
    }

    private class_2561 durabilityLabel() {
        return optionLabel("autofarm.option.tool_threshold",
                class_2561.method_43469("autofarm.value.percent", draft.toolDurabilityPercent));
    }

    private class_2561 cooldownLabel() {
        return optionLabel("autofarm.option.cooldown_seconds",
                class_2561.method_43469("autofarm.value.seconds", draft.failureCooldownSeconds));
    }

    private class_2561 pickupDelayLabel() {
        return optionLabel("autofarm.option.pickup_delay",
                class_2561.method_43469("autofarm.value.seconds", draft.pickupDelaySeconds));
    }

    private class_2561 attackIntervalLabel() {
        return optionLabel("autofarm.option.attack_interval",
                class_2561.method_43469("autofarm.value.millis", draft.attackIntervalMs));
    }

    private class_2561 attackTargetLabel() {
        return optionLabel("autofarm.option.attack_target",
                class_2561.method_43471(draft.attackHostileOnly
                        ? "autofarm.attack_target.hostile"
                        : "autofarm.attack_target.all"));
    }

    private class_2561 antiKickLevelLabel() {
        return optionLabel("autofarm.option.antikick_level",
                class_2561.method_43471("autofarm.antikick.level." + levelKey(draft.antiKickLevel)));
    }

    private class_2561 reactionTimeLabel() {
        return optionLabel("autofarm.option.reaction_time",
                class_2561.method_43469("autofarm.value.seconds",
                        String.format("%.1f", draft.reactionDelayTicks / 20.0)));
    }

    private class_2561 scheduleStartLabel() {
        return optionLabel("autofarm.option.schedule_start", hourText(draft.scheduleStartHour));
    }

    private class_2561 scheduleEndLabel() {
        return optionLabel("autofarm.option.schedule_end", hourText(draft.scheduleEndHour));
    }

    private static class_2561 hourText(int hour) {
        return class_2561.method_43469("autofarm.value.hour", String.format("%02d", hour));
    }

    /** 档位数字 → 语言键后缀。认不出来的档位一律当「关闭」显示 */
    private static String levelKey(int level) {
        return switch (level) {
            case 1 -> "light";
            case 2 -> "medium";
            case 3 -> "high";
            default -> "off";
        };
    }
}
